
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevestools.init;

import net.sprvlln.stevestools.item.IronHammerItem;
import net.sprvlln.stevestools.item.GoldHammerItem;
import net.sprvlln.stevestools.item.DiamondHammerItem;
import net.sprvlln.stevestools.StevesToolsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

public class StevesToolsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, StevesToolsMod.MODID);
	public static final RegistryObject<Item> GOLD_HAMMER = REGISTRY.register("gold_hammer", () -> new GoldHammerItem());
	public static final RegistryObject<Item> IRON_HAMMER = REGISTRY.register("iron_hammer", () -> new IronHammerItem());
	public static final RegistryObject<Item> DIAMOND_HAMMER = REGISTRY.register("diamond_hammer", () -> new DiamondHammerItem());
}
