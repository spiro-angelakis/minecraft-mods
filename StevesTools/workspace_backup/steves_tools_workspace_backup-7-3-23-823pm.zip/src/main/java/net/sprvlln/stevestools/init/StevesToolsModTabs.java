
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevestools.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class StevesToolsModTabs {
	public static CreativeModeTab TAB_STEVES_TOOLS_CREATIVE_TAB;

	public static void load() {
		TAB_STEVES_TOOLS_CREATIVE_TAB = new CreativeModeTab("tabsteves_tools_creative_tab") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(StevesToolsModItems.IRON_HAMMER.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
