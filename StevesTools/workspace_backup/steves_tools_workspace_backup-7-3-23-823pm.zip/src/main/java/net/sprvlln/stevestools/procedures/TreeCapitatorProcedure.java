package net.sprvlln.stevestools.procedures;

import net.sprvlln.stevestools.StevesToolsMod;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

public class TreeCapitatorProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
			StevesToolsMod.queueServerWork(1, () -> {
				if ((world.getBlockState(new BlockPos(x + 1, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, (x + 1), y, z);
					{
						BlockPos _pos = new BlockPos(x + 1, y, z);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x - 1, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, (x - 1), y, z);
					{
						BlockPos _pos = new BlockPos(x - 1, y, z);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x, y - 1, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, x, (y - 1), z);
					{
						BlockPos _pos = new BlockPos(x, y - 1, z);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x, y + 1, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, x, (y + 1), z);
					{
						BlockPos _pos = new BlockPos(x, y + 1, z);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x, y, z + 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, x, y, (z + 1));
					{
						BlockPos _pos = new BlockPos(x, y, z + 1);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x, y, z - 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, x, y, (z - 1));
					{
						BlockPos _pos = new BlockPos(x, y, z - 1);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x, y + 1, z + 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, x, (y + 1), (z + 1));
					{
						BlockPos _pos = new BlockPos(x, y + 1, z + 1);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x, y + 1, z - 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, x, (y + 1), (z - 1));
					{
						BlockPos _pos = new BlockPos(x, y + 1, z - 1);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x - 1, y, z + 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, (x - 1), y, (z + 1));
					{
						BlockPos _pos = new BlockPos(x - 1, y, z + 1);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x + 1, y, z - 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, (x + 1), y, (z - 1));
					{
						BlockPos _pos = new BlockPos(x + 1, y, z - 1);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x + 1, y + 1, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, (x + 1), (y + 1), z);
					{
						BlockPos _pos = new BlockPos(x + 1, y + 1, z);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x - 1, y + 1, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, (x - 1), (y + 1), z);
					{
						BlockPos _pos = new BlockPos(x - 1, y + 1, z);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x - 1, y + 1, z - 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, (x - 1), (y + 1), (z - 1));
					{
						BlockPos _pos = new BlockPos(x - 1, y + 1, z - 1);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x + 1, y + 1, z + 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, (x + 1), (y + 1), (z + 1));
					{
						BlockPos _pos = new BlockPos(x + 1, y + 1, z + 1);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x - 1, y + 1, z + 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, (x - 1), (y + 1), (z + 1));
					{
						BlockPos _pos = new BlockPos(x - 1, y + 1, z + 1);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
				if ((world.getBlockState(new BlockPos(x + 1, y + 1, z - 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
					TreeCapitatorProcedure.execute(world, (x + 1), (y + 1), (z - 1));
					{
						BlockPos _pos = new BlockPos(x + 1, y + 1, z - 1);
						Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
						world.destroyBlock(_pos, false);
					}
				}
			});
		}
	}
}
