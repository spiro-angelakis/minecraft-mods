package net.sprvlln.stevespests.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.sprvlln.stevespests.entity.RatEntity;

import net.minecraft.resources.ResourceLocation;

public class RatModel extends AnimatedGeoModel<RatEntity> {
	@Override
	public ResourceLocation getAnimationResource(RatEntity entity) {
		return new ResourceLocation("steves_pests", "animations/rat.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(RatEntity entity) {
		return new ResourceLocation("steves_pests", "geo/rat.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(RatEntity entity) {
		return new ResourceLocation("steves_pests", "textures/entities/" + entity.getTexture() + ".png");
	}

}
