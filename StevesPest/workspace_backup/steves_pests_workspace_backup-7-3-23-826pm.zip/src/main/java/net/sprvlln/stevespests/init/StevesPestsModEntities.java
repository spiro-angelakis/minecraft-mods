
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevespests.init;

import net.sprvlln.stevespests.entity.TermiteHillEntity;
import net.sprvlln.stevespests.entity.TermiteEntity;
import net.sprvlln.stevespests.entity.RatEntity;
import net.sprvlln.stevespests.StevesPestsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class StevesPestsModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, StevesPestsMod.MODID);
	public static final RegistryObject<EntityType<TermiteEntity>> TERMITE = register("termite",
			EntityType.Builder.<TermiteEntity>of(TermiteEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TermiteEntity::new)

					.sized(0.1f, 0.1f));
	public static final RegistryObject<EntityType<RatEntity>> RAT = register("rat",
			EntityType.Builder.<RatEntity>of(RatEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(RatEntity::new)

					.sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<TermiteHillEntity>> TERMITE_HILL = register("termite_hill",
			EntityType.Builder.<TermiteHillEntity>of(TermiteHillEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TermiteHillEntity::new)

					.sized(0.4f, 0.3f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			TermiteEntity.init();
			RatEntity.init();
			TermiteHillEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(TERMITE.get(), TermiteEntity.createAttributes().build());
		event.put(RAT.get(), RatEntity.createAttributes().build());
		event.put(TERMITE_HILL.get(), TermiteHillEntity.createAttributes().build());
	}
}
