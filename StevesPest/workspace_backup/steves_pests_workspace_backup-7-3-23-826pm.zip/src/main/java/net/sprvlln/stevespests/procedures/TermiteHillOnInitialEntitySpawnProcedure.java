package net.sprvlln.stevespests.procedures;

import net.sprvlln.stevespests.entity.TermiteHillEntity;

import net.minecraft.world.entity.Entity;

public class TermiteHillOnInitialEntitySpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putBoolean("canSpawn", true);
		entity.getPersistentData().putDouble("tickTime", 0);
		if (entity instanceof TermiteHillEntity) {
			((TermiteHillEntity) entity).setAnimation("spawn");
		}
	}
}
