
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevespests.init;

import net.sprvlln.stevespests.client.renderer.TermiteRenderer;
import net.sprvlln.stevespests.client.renderer.TermiteHillRenderer;
import net.sprvlln.stevespests.client.renderer.RatRenderer;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class StevesPestsModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(StevesPestsModEntities.TERMITE.get(), TermiteRenderer::new);
		event.registerEntityRenderer(StevesPestsModEntities.RAT.get(), RatRenderer::new);
		event.registerEntityRenderer(StevesPestsModEntities.TERMITE_HILL.get(), TermiteHillRenderer::new);
	}
}
