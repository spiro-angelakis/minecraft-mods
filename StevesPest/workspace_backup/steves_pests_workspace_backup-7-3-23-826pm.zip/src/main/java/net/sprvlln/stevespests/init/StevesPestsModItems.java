
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevespests.init;

import net.sprvlln.stevespests.StevesPestsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

public class StevesPestsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, StevesPestsMod.MODID);
	public static final RegistryObject<Item> TERMITE_SPAWN_EGG = REGISTRY.register("termite_spawn_egg", () -> new ForgeSpawnEggItem(StevesPestsModEntities.TERMITE, -13210, -6724096, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> RAT_SPAWN_EGG = REGISTRY.register("rat_spawn_egg", () -> new ForgeSpawnEggItem(StevesPestsModEntities.RAT, -10066330, -13421773, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> TERMITE_HILL_SPAWN_EGG = REGISTRY.register("termite_hill_spawn_egg",
			() -> new ForgeSpawnEggItem(StevesPestsModEntities.TERMITE_HILL, -13210, -6724096, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
}
