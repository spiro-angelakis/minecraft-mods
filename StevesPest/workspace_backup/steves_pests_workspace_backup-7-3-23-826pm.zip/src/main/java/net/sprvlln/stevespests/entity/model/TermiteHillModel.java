package net.sprvlln.stevespests.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.sprvlln.stevespests.entity.TermiteHillEntity;

import net.minecraft.resources.ResourceLocation;

public class TermiteHillModel extends AnimatedGeoModel<TermiteHillEntity> {
	@Override
	public ResourceLocation getAnimationResource(TermiteHillEntity entity) {
		return new ResourceLocation("steves_pests", "animations/termite_hill.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(TermiteHillEntity entity) {
		return new ResourceLocation("steves_pests", "geo/termite_hill.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(TermiteHillEntity entity) {
		return new ResourceLocation("steves_pests", "textures/entities/" + entity.getTexture() + ".png");
	}

}
