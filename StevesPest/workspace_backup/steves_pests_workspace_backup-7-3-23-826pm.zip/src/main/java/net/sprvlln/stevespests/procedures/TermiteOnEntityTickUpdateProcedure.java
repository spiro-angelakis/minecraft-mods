package net.sprvlln.stevespests.procedures;

import net.sprvlln.stevespests.entity.TermiteEntity;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;
import net.minecraft.core.BlockPos;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class TermiteOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		Vec3 nearWoodVec = new Vec3(0.0D, 0.0D, 0.0D);
		boolean isNearWood = false;
		boolean ateBlock = false;
		double checkRange = 0;
		double checkX = 0;
		double checkY = 0;
		double checkZ = 0;
		double nearbyMites = 0;
		if (entity.getPersistentData().getDouble("lifetimeLeft") >= 0) {
			if (entity.getPersistentData().getBoolean("ate") == false) {
				isNearWood = false;
				ateBlock = false;
				checkRange = 5;
				checkX = x - checkRange;
				checkY = y - checkRange;
				checkZ = z - checkRange;
				for (int index0 = 0; index0 < (int) (checkRange * 2); index0++) {
					if (isNearWood == false) {
						for (int index1 = 0; index1 < (int) (checkRange * 2); index1++) {
							if (isNearWood == false) {
								for (int index2 = 0; index2 < (int) (checkRange * 2); index2++) {
									if (isNearWood == false) {
										if ((world.getBlockState(new BlockPos(checkX, checkY, checkZ))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true
												|| (world.getBlockState(new BlockPos(checkX, checkY, checkZ))).is(BlockTags.create(new ResourceLocation("minecraft:loaves"))) == true
												|| (world.getBlockState(new BlockPos(checkX, checkY, checkZ))).is(BlockTags.create(new ResourceLocation("minecraft:planks"))) == true) {
											nearWoodVec = new Vec3(checkX, checkY, checkZ);
											isNearWood = true;
										}
										if (isNearWood == false) {
											checkZ = checkZ + 1;
										}
									} else {
										break;
									}
								}
								if (isNearWood == false) {
									checkZ = z - checkRange;
									checkX = checkX + 1;
								}
							} else {
								break;
							}
						}
						if (isNearWood == false) {
							checkZ = z - checkRange;
							checkX = x - checkRange;
							checkY = checkY + 1;
						}
					} else {
						break;
					}
				}
				if (isNearWood == true) {
					if (entity instanceof Mob _entity)
						_entity.getNavigation().moveTo((nearWoodVec.x()), (nearWoodVec.y()), (nearWoodVec.z()), 1);
					nearbyMites = 0;
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(3 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
								.collect(Collectors.toList());
						for (Entity entityiterator : _entfound) {
							if (entityiterator.getType().is(TagKey.create(Registry.ENTITY_TYPE_REGISTRY, new ResourceLocation("steves_pests:termite"))) == true) {
								nearbyMites = nearbyMites + 1;
							}
						}
					}
					if (nearbyMites >= 3) {
						if (Mth.nextInt(RandomSource.create(), 1, 10) == 1) {
							entity.setDeltaMovement(new Vec3((Mth.nextDouble(RandomSource.create(), -0.5, 0.5)), 2.5, (Mth.nextDouble(RandomSource.create(), -0.5, 0.5))));
							if (entity instanceof TermiteEntity) {
								((TermiteEntity) entity).setAnimation("jump");
							}
						}
					}
				}
				if (ateBlock == false) {
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x + 1, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
							world.destroyBlock(new BlockPos(x + 1, y, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x + 1, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:planks"))) == true) {
							world.destroyBlock(new BlockPos(x + 1, y, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x + 1, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:leaves"))) == true) {
							world.destroyBlock(new BlockPos(x + 1, y, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x + 1, y, z))).getBlock() == Blocks.CHEST) {
							{
								BlockPos _pos = new BlockPos(x + 1, y, z);
								Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
								world.destroyBlock(_pos, false);
							}
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x - 1, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
							world.destroyBlock(new BlockPos(x - 1, y, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x - 1, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:planks"))) == true) {
							world.destroyBlock(new BlockPos(x - 1, y, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x - 1, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:leaves"))) == true) {
							world.destroyBlock(new BlockPos(x - 1, y, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x - 1, y, z))).getBlock() == Blocks.CHEST) {
							{
								BlockPos _pos = new BlockPos(x - 1, y, z);
								Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
								world.destroyBlock(_pos, false);
							}
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y + 1, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
							world.destroyBlock(new BlockPos(x, y + 1, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y + 1, z))).is(BlockTags.create(new ResourceLocation("minecraft:planks"))) == true) {
							world.destroyBlock(new BlockPos(x, y + 1, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y + 1, z))).is(BlockTags.create(new ResourceLocation("minecraft:leaves"))) == true) {
							world.destroyBlock(new BlockPos(x, y + 1, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == Blocks.CHEST) {
							{
								BlockPos _pos = new BlockPos(x, y + 1, z);
								Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
								world.destroyBlock(_pos, false);
							}
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y - 1, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
							world.destroyBlock(new BlockPos(x, y - 1, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y - 1, z))).is(BlockTags.create(new ResourceLocation("minecraft:planks"))) == true) {
							world.destroyBlock(new BlockPos(x, y - 1, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y - 1, z))).is(BlockTags.create(new ResourceLocation("minecraft:leaves"))) == true) {
							world.destroyBlock(new BlockPos(x, y - 1, z), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y - 1, z))).getBlock() == Blocks.CHEST) {
							{
								BlockPos _pos = new BlockPos(x, y - 1, z);
								Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
								world.destroyBlock(_pos, false);
							}
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y, z + 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
							world.destroyBlock(new BlockPos(x, y, z + 1), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y, z + 1))).is(BlockTags.create(new ResourceLocation("minecraft:planks"))) == true) {
							world.destroyBlock(new BlockPos(x, y, z + 1), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y, z + 1))).is(BlockTags.create(new ResourceLocation("minecraft:leaves"))) == true) {
							world.destroyBlock(new BlockPos(x, y, z + 1), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y, z + 1))).getBlock() == Blocks.CHEST) {
							{
								BlockPos _pos = new BlockPos(x, y, z + 1);
								Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
								world.destroyBlock(_pos, false);
							}
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y, z - 1))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) == true) {
							world.destroyBlock(new BlockPos(x, y, z - 1), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y, z - 1))).is(BlockTags.create(new ResourceLocation("minecraft:planks"))) == true) {
							world.destroyBlock(new BlockPos(x, y, z - 1), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y, z - 1))).is(BlockTags.create(new ResourceLocation("minecraft:leaves"))) == true) {
							world.destroyBlock(new BlockPos(x, y, z - 1), false);
							ateBlock = true;
						}
					}
					if (ateBlock == false) {
						if ((world.getBlockState(new BlockPos(x, y, z - 1))).getBlock() == Blocks.CHEST) {
							{
								BlockPos _pos = new BlockPos(x, y, z - 1);
								Block.dropResources(world.getBlockState(_pos), world, new BlockPos(x, y, z), null);
								world.destroyBlock(_pos, false);
							}
							ateBlock = true;
						}
					}
					if (ateBlock == true) {
						entity.getPersistentData().putBoolean("ate", true);
						entity.getPersistentData().putDouble("lifetimeLeft", (entity.getPersistentData().getDouble("lifetimeLeft") + 170));
						if (entity instanceof TermiteEntity) {
							((TermiteEntity) entity).setAnimation("eat");
						}
					}
				}
			} else {
				if (entity.getPersistentData().getDouble("ticksSinceAte") >= 60) {
					entity.getPersistentData().putDouble("ticksSinceAte", 0);
					entity.getPersistentData().putBoolean("ate", false);
				} else {
					entity.getPersistentData().putDouble("ticksSinceAte", (entity.getPersistentData().getDouble("ticksSinceAte") + 1));
				}
			}
		} else {
		}
	}
}
