package net.sprvlln.stevespests.procedures;

public class RatOnEntityTickUpdateProcedure {
	public static void execute(double x) {
		boolean nearChest = false;
		double checkX = 0;
		double checkY = 0;
		double checkZ = 0;
		nearChest = false;
		checkX = x - 32;
	}
}
