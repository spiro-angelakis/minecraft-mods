package net.sprvlln.stevespests.entity.model;

import software.bernie.geckolib3.model.provider.data.EntityModelData;
import software.bernie.geckolib3.model.AnimatedGeoModel;
import software.bernie.geckolib3.core.processor.IBone;
import software.bernie.geckolib3.core.manager.AnimationData;
import software.bernie.geckolib3.core.event.predicate.AnimationEvent;

import net.sprvlln.stevespests.entity.TermiteEntity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.Minecraft;

public class TermiteModel extends AnimatedGeoModel<TermiteEntity> {
	@Override
	public ResourceLocation getAnimationResource(TermiteEntity entity) {
		return new ResourceLocation("steves_pests", "animations/termite2.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(TermiteEntity entity) {
		return new ResourceLocation("steves_pests", "geo/termite2.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(TermiteEntity entity) {
		return new ResourceLocation("steves_pests", "textures/entities/" + entity.getTexture() + ".png");
	}

	@Override
	public void setCustomAnimations(TermiteEntity animatable, int instanceId, AnimationEvent animationEvent) {
		super.setCustomAnimations(animatable, instanceId, animationEvent);
		IBone head = this.getAnimationProcessor().getBone("head");
		EntityModelData extraData = (EntityModelData) animationEvent.getExtraDataOfType(EntityModelData.class).get(0);
		AnimationData manager = animatable.getFactory().getOrCreateAnimationData(instanceId);
		int unpausedMultiplier = !Minecraft.getInstance().isPaused() || manager.shouldPlayWhilePaused ? 1 : 0;
		head.setRotationX(head.getRotationX() + extraData.headPitch * ((float) Math.PI / 180F) * unpausedMultiplier);
		head.setRotationY(head.getRotationY() + extraData.netHeadYaw * ((float) Math.PI / 180F) * unpausedMultiplier);
	}
}
