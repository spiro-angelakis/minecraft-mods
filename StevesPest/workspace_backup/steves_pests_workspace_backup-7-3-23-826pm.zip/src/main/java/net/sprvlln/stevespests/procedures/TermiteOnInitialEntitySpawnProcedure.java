package net.sprvlln.stevespests.procedures;

import net.minecraft.world.entity.Entity;

public class TermiteOnInitialEntitySpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putBoolean("ate", false);
		entity.getPersistentData().putDouble("ticksSinceAte", 0);
		entity.getPersistentData().putDouble("lifetimeLeft", 450);
	}
}
