
package net.sprvlln.stevesicbm.itemgroup;

import net.sprvlln.stevesicbm.item.SpudnikItemItem;
import net.sprvlln.stevesicbm.StevesicbmModElements;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

@StevesicbmModElements.ModElement.Tag
public class StevesICBMItemGroup extends StevesicbmModElements.ModElement {
	public StevesICBMItemGroup(StevesicbmModElements instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabsteves_icbm") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(SpudnikItemItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
