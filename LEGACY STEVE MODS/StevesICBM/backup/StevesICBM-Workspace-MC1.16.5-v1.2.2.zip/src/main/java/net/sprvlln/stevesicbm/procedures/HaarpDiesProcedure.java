package net.sprvlln.stevesicbm.procedures;

import net.sprvlln.stevesicbm.StevesicbmMod;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.gen.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.effect.LightningBoltEntity;
import net.minecraft.entity.EntityType;

import java.util.Map;

public class HaarpDiesProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency x for procedure HaarpDies!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency z for procedure HaarpDies!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency world for procedure HaarpDies!");
			return;
		}
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		double shockCount = 0;
		double shockX = 0;
		double shockY = 0;
		double shockZ = 0;
		double flipChance = 0;
		shockCount = (double) ((Math.random() * 30) + 30);
		for (int index0 = 0; index0 < (int) (shockCount); index0++) {
			shockX = (double) ((Math.random() * 32) + 1);
			flipChance = (double) Math.random();
			if ((flipChance > 0.5)) {
				shockX = (double) (shockX * (-1));
			}
			shockX = (double) (x + shockX);
			shockZ = (double) ((Math.random() * 32) + 1);
			flipChance = (double) Math.random();
			if ((flipChance > 0.5)) {
				shockZ = (double) (shockZ * (-1));
			}
			shockZ = (double) (z + shockZ);
			shockY = (double) (world.getHeight(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) shockX, (int) shockZ));
			if (world instanceof ServerWorld) {
				LightningBoltEntity _ent = EntityType.LIGHTNING_BOLT.create((World) world);
				_ent.moveForced(Vector3d.copyCenteredHorizontally(new BlockPos((int) shockX, (int) shockY, (int) shockZ)));
				_ent.setEffectOnly(false);
				((World) world).addEntity(_ent);
			}
		}
	}
}
