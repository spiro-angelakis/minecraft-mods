package net.sprvlln.stevesicbm.procedures;

import net.sprvlln.stevesicbm.StevesicbmMod;

import net.minecraft.entity.Entity;

import java.util.Map;

public class BoringTankOnInitialEntitySpawnProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency entity for procedure BoringTankOnInitialEntitySpawn!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.getPersistentData().putBoolean("moving", (false));
		entity.getPersistentData().putBoolean("drilling", (false));
		entity.getPersistentData().putDouble("workTick", 0);
	}
}
