
package net.sprvlln.stevesicbm.item;

import net.sprvlln.stevesicbm.itemgroup.StevesICBMItemGroup;
import net.sprvlln.stevesicbm.StevesicbmModElements;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

@StevesicbmModElements.ModElement.Tag
public class SuperComputerItem extends StevesicbmModElements.ModElement {
	@ObjectHolder("stevesicbm:super_computer")
	public static final Item block = null;
	public SuperComputerItem(StevesicbmModElements instance) {
		super(instance, 107);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(StevesICBMItemGroup.tab).maxStackSize(64).rarity(Rarity.RARE));
			setRegistryName("super_computer");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}
	}
}
