package net.sprvlln.stevesicbm.procedures;

import net.sprvlln.stevesicbm.StevesicbmMod;

import net.minecraft.entity.Entity;

import java.util.Map;

public class SpudnikUpwardOnInitialEntitySpawnProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency entity for procedure SpudnikUpwardOnInitialEntitySpawn!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.getPersistentData().putBoolean("launched", (false));
	}
}
