package net.sprvlln.stevesicbm.procedures;

import net.sprvlln.stevesicbm.particle.IcbmSmokeParticleParticle;
import net.sprvlln.stevesicbm.StevesicbmMod;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.Entity;

import java.util.Map;
import java.util.Collections;

public class SpudnikUpwardOnEntityTickUpdateProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency entity for procedure SpudnikUpwardOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency x for procedure SpudnikUpwardOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency y for procedure SpudnikUpwardOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency z for procedure SpudnikUpwardOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency world for procedure SpudnikUpwardOnEntityTickUpdate!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		double smokeChance = 0;
		if (((entity.getPersistentData().getBoolean("launched")) == (true))) {
			if (((world.getBlockState(new BlockPos((int) x, (int) (y + 3), (int) z)).isSolid()) == (true))) {
				entity.attackEntityFrom(DamageSource.GENERIC, (float) 10);
			} else {
				smokeChance = (double) Math.random();
				if ((smokeChance >= 0.3)) {
					if (world instanceof ServerWorld) {
						((ServerWorld) world).spawnParticle(IcbmSmokeParticleParticle.particle, x, (y - 16), z, (int) ((Math.random() * 3) + 1), 2,
								12, 2, 1);
					}
				}
				world.addParticle(IcbmSmokeParticleParticle.particle, x, y, z, 0, 0, 0);
				{
					Entity _ent = entity;
					_ent.setPositionAndUpdate(x, (y + 1), z);
					if (_ent instanceof ServerPlayerEntity) {
						((ServerPlayerEntity) _ent).connection.setPlayerLocation(x, (y + 1), z, _ent.rotationYaw, _ent.rotationPitch,
								Collections.emptySet());
					}
				}
				if (((entity.getPosY()) >= 300)) {
					if (!entity.world.isRemote())
						entity.remove();
				}
			}
		}
	}
}
