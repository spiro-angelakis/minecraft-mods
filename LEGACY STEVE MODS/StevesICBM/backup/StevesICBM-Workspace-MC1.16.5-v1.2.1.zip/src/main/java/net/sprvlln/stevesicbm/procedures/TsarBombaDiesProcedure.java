package net.sprvlln.stevesicbm.procedures;

import net.sprvlln.stevesicbm.StevesicbmMod;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.world.Explosion;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;
import net.minecraft.block.Blocks;

import java.util.Map;

public class TsarBombaDiesProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency x for procedure TsarBombaDies!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency y for procedure TsarBombaDies!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency z for procedure TsarBombaDies!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency world for procedure TsarBombaDies!");
			return;
		}
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		double blockX = 0;
		double blockY = 0;
		double blockZ = 0;
		double dropChance = 0;
		double blocksTillExplosion = 0;
		double breakChance = 0;
		double helpExplode = 0;
		if (world instanceof World && !world.isRemote()) {
			((World) world).playSound(null, new BlockPos((int) x, (int) y, (int) z),
					(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("stevesicbm:missile_touch_2")),
					SoundCategory.NEUTRAL, (float) 5, (float) 1);
		} else {
			((World) world).playSound(x, y, z,
					(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("stevesicbm:missile_touch_2")),
					SoundCategory.NEUTRAL, (float) 5, (float) 1, false);
		}
		blockX = (double) (x - 32);
		blockY = (double) (y - 32);
		blockZ = (double) (z - 32);
		blocksTillExplosion = (double) 1000;
		for (int index0 = 0; index0 < (int) (64); index0++) {
			for (int index1 = 0; index1 < (int) (64); index1++) {
				for (int index2 = 0; index2 < (int) (64); index2++) {
					blocksTillExplosion = (double) (blocksTillExplosion + 1);
					if ((!((world.getBlockState(new BlockPos((int) blockX, (int) blockY, (int) blockZ))).getBlock() == Blocks.BEDROCK))) {
						breakChance = (double) Math.random();
						if ((breakChance >= 0.05)) {
							world.setBlockState(new BlockPos((int) blockX, (int) blockY, (int) blockZ), Blocks.AIR.getDefaultState(), 3);
							if ((blocksTillExplosion >= 1024)) {
								dropChance = (double) Math.random();
								if ((dropChance >= 0.5)) {
									if (world instanceof World && !((World) world).isRemote) {
										((World) world).createExplosion(null, (int) blockX, (int) blockY, (int) blockZ, (float) 24,
												Explosion.Mode.DESTROY);
									}
								} else {
									helpExplode = (double) Math.random();
									if ((dropChance >= 0.5)) {
										blocksTillExplosion = (double) 512;
									} else {
										blocksTillExplosion = (double) 0;
									}
								}
							}
						}
					}
					blockZ = (double) (blockZ + 1);
				}
				blockZ = (double) (z - 32);
				blockX = (double) (blockX + 1);
			}
			blockX = (double) (x - 32);
			blockY = (double) (blockY + 1);
		}
	}
}
