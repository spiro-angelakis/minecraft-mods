package net.sprvlln.stevesicbm.procedures;

import net.sprvlln.stevesicbm.StevesicbmMod;

import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.CapabilityItemHandler;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.Direction;
import net.minecraft.util.DamageSource;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.block.Block;

import java.util.function.Function;
import java.util.concurrent.atomic.AtomicReference;
import java.util.Map;
import java.util.Comparator;

public class BoringTankOnEntityTickUpdateProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency entity for procedure BoringTankOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency x for procedure BoringTankOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency y for procedure BoringTankOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency z for procedure BoringTankOnEntityTickUpdate!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency world for procedure BoringTankOnEntityTickUpdate!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		boolean canWork = false;
		double digY = 0;
		canWork = (boolean) (true);
		if (((entity.getPersistentData().getDouble("workTick")) >= 80)) {
			if (((new Object() {
				public ItemStack getItemStack(int sltid, Entity entity) {
					AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
					entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
						_retval.set(capability.getStackInSlot(sltid).copy());
					});
					return _retval.get();
				}
			}.getItemStack((int) (0), entity)).getItem() == Items.COAL)) {
				{
					final ItemStack _setstack = new ItemStack(Items.COAL);
					final int _sltid = (int) (0);
					_setstack.setCount((int) ((((new Object() {
						public ItemStack getItemStack(int sltid, Entity entity) {
							AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
							entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
								_retval.set(capability.getStackInSlot(sltid).copy());
							});
							return _retval.get();
						}
					}.getItemStack((int) (0), entity))).getCount()) - 1));
					entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
						if (capability instanceof IItemHandlerModifiable) {
							((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
						}
					});
				}
				entity.getPersistentData().putDouble("workTick", 0);
			} else if (((new Object() {
				public ItemStack getItemStack(int sltid, Entity entity) {
					AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
					entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
						_retval.set(capability.getStackInSlot(sltid).copy());
					});
					return _retval.get();
				}
			}.getItemStack((int) (0), entity)).getItem() == Items.CHARCOAL)) {
				{
					final ItemStack _setstack = new ItemStack(Items.CHARCOAL);
					final int _sltid = (int) (0);
					_setstack.setCount((int) ((((new Object() {
						public ItemStack getItemStack(int sltid, Entity entity) {
							AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
							entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
								_retval.set(capability.getStackInSlot(sltid).copy());
							});
							return _retval.get();
						}
					}.getItemStack((int) (0), entity))).getCount()) - 1));
					entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
						if (capability instanceof IItemHandlerModifiable) {
							((IItemHandlerModifiable) capability).setStackInSlot(_sltid, _setstack);
						}
					});
				}
				entity.getPersistentData().putDouble("workTick", 0);
			} else {
				canWork = (boolean) (false);
			}
		}
		if (((entity.isBeingRidden()) == (true))) {
			if ((canWork == (false))) {
				if (((((Entity) world
						.getEntitiesWithinAABB(PlayerEntity.class,
								new AxisAlignedBB(x - (4 / 2d), y - (4 / 2d), z - (4 / 2d), x + (4 / 2d), y + (4 / 2d), z + (4 / 2d)), null)
						.stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)) != null) == (true))) {
					((Entity) world
							.getEntitiesWithinAABB(PlayerEntity.class,
									new AxisAlignedBB(x - (4 / 2d), y - (4 / 2d), z - (4 / 2d), x + (4 / 2d), y + (4 / 2d), z + (4 / 2d)), null)
							.stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).setSneaking((true));
				} else if (((((Entity) world
						.getEntitiesWithinAABB(ServerPlayerEntity.class,
								new AxisAlignedBB(x - (4 / 2d), y - (4 / 2d), z - (4 / 2d), x + (4 / 2d), y + (4 / 2d), z + (4 / 2d)), null)
						.stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)) != null) == (true))) {
					((Entity) world
							.getEntitiesWithinAABB(ServerPlayerEntity.class,
									new AxisAlignedBB(x - (4 / 2d), y - (4 / 2d), z - (4 / 2d), x + (4 / 2d), y + (4 / 2d), z + (4 / 2d)), null)
							.stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).setSneaking((true));
				}
			} else {
				entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
				if (((entity.getHorizontalFacing()) == Direction.EAST)) {
					digY = (double) y;
					if (((((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
							new AxisAlignedBB((x + 4) - (2 / 2d), y - (2 / 2d), z - (2 / 2d), (x + 4) + (2 / 2d), y + (2 / 2d), z + (2 / 2d)), null)
							.stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf((x + 4), y, z)).findFirst().orElse(null)) != null) == (true))) {
						if (((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
								new AxisAlignedBB((x + 4) - (2 / 2d), y - (2 / 2d), z - (2 / 2d), (x + 4) + (2 / 2d), y + (2 / 2d), z + (2 / 2d)),
								null).stream().sorted(new Object() {
									Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
										return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
									}
								}.compareDistOf((x + 4), y, z)).findFirst().orElse(null)) instanceof LivingEntity) {
							((LivingEntity) ((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
									new AxisAlignedBB((x + 4) - (2 / 2d), y - (2 / 2d), z - (2 / 2d), (x + 4) + (2 / 2d), y + (2 / 2d), z + (2 / 2d)),
									null).stream().sorted(new Object() {
										Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
											return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
										}
									}.compareDistOf((x + 4), y, z)).findFirst().orElse(null)))
											.attackEntityFrom(new DamageSource("bore drill").setDamageBypassesArmor(), (float) 2);
						}
					}
					for (int index0 = 0; index0 < (int) (3); index0++) {
						if (((((world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) z)))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) z)))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) (x + 2), (int) y, (int) z)).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) z)), (World) world,
											new BlockPos((int) (x + 1), (int) digY, (int) z));
									world.destroyBlock(new BlockPos((int) (x + 2), (int) digY, (int) z), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						if (((((world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) (z + 1))))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) (z + 1))))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) (z + 1))).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) (z + 1))), (World) world,
											new BlockPos((int) (x + 2), (int) digY, (int) (z + 1)));
									world.destroyBlock(new BlockPos((int) (x + 2), (int) digY, (int) (z + 1)), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						if (((((world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) (z - 1))))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) (z - 1))))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) (z - 1))).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) (x + 2), (int) digY, (int) (z - 1))), (World) world,
											new BlockPos((int) (x + 2), (int) digY, (int) (z - 1)));
									world.destroyBlock(new BlockPos((int) (x + 2), (int) digY, (int) (z - 1)), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						digY = (double) (digY + 1);
					}
				} else if (((entity.getHorizontalFacing()) == Direction.WEST)) {
					digY = (double) y;
					if (((((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
							new AxisAlignedBB((x - 4) - (2 / 2d), y - (2 / 2d), z - (2 / 2d), (x - 4) + (2 / 2d), y + (2 / 2d), z + (2 / 2d)), null)
							.stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf((x - 4), y, z)).findFirst().orElse(null)) != null) == (true))) {
						if (((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
								new AxisAlignedBB((x - 4) - (2 / 2d), y - (2 / 2d), z - (2 / 2d), (x - 4) + (2 / 2d), y + (2 / 2d), z + (2 / 2d)),
								null).stream().sorted(new Object() {
									Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
										return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
									}
								}.compareDistOf((x - 4), y, z)).findFirst().orElse(null)) instanceof LivingEntity) {
							((LivingEntity) ((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
									new AxisAlignedBB((x - 4) - (2 / 2d), y - (2 / 2d), z - (2 / 2d), (x - 4) + (2 / 2d), y + (2 / 2d), z + (2 / 2d)),
									null).stream().sorted(new Object() {
										Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
											return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
										}
									}.compareDistOf((x - 4), y, z)).findFirst().orElse(null)))
											.attackEntityFrom(new DamageSource("bore drill").setDamageBypassesArmor(), (float) 2);
						}
					}
					for (int index1 = 0; index1 < (int) (3); index1++) {
						if (((((world.getBlockState(new BlockPos((int) (x - 2), (int) digY, (int) z)))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) (x - 2), (int) digY, (int) z)))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) z)).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) (x - 2), (int) digY, (int) z)), (World) world,
											new BlockPos((int) (x - 2), (int) digY, (int) z));
									world.destroyBlock(new BlockPos((int) (x - 2), (int) digY, (int) z), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						if (((((world.getBlockState(new BlockPos((int) (x - 2), (int) digY, (int) (z + 1))))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) (x - 2), (int) digY, (int) (z + 1))))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) (x - 2), (int) digY, (int) (z + 1))).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) (x - 2), (int) digY, (int) (z + 1))), (World) world,
											new BlockPos((int) (x - 2), (int) digY, (int) (z + 1)));
									world.destroyBlock(new BlockPos((int) (x - 2), (int) digY, (int) (z + 1)), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						if (((((world.getBlockState(new BlockPos((int) (x - 2), (int) digY, (int) (z - 1))))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) (x - 2), (int) digY, (int) (z - 1))))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z - 1))).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) (x - 2), (int) digY, (int) (z - 1))), (World) world,
											new BlockPos((int) (x - 2), (int) digY, (int) (z - 1)));
									world.destroyBlock(new BlockPos((int) (x - 2), (int) digY, (int) (z - 1)), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						digY = (double) (digY + 1);
					}
				} else if (((entity.getHorizontalFacing()) == Direction.NORTH)) {
					digY = (double) y;
					if (((((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
							new AxisAlignedBB(x - (2 / 2d), y - (2 / 2d), (z - 4) - (2 / 2d), x + (2 / 2d), y + (2 / 2d), (z - 4) + (2 / 2d)), null)
							.stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf(x, y, (z - 4))).findFirst().orElse(null)) != null) == (true))) {
						if (((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
								new AxisAlignedBB(x - (2 / 2d), y - (2 / 2d), (z - 4) - (2 / 2d), x + (2 / 2d), y + (2 / 2d), (z - 4) + (2 / 2d)),
								null).stream().sorted(new Object() {
									Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
										return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
									}
								}.compareDistOf(x, y, (z - 4))).findFirst().orElse(null)) instanceof LivingEntity) {
							((LivingEntity) ((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
									new AxisAlignedBB(x - (2 / 2d), y - (2 / 2d), (z - 4) - (2 / 2d), x + (2 / 2d), y + (2 / 2d), (z - 4) + (2 / 2d)),
									null).stream().sorted(new Object() {
										Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
											return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
										}
									}.compareDistOf(x, y, (z - 4))).findFirst().orElse(null)))
											.attackEntityFrom(new DamageSource("bore drill").setDamageBypassesArmor(), (float) 2);
						}
					}
					for (int index2 = 0; index2 < (int) (3); index2++) {
						if (((((world.getBlockState(new BlockPos((int) x, (int) digY, (int) (z - 2))))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) x, (int) digY, (int) (z - 2))))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z - 2))).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) x, (int) digY, (int) (z - 2))), (World) world,
											new BlockPos((int) x, (int) digY, (int) (z - 2)));
									world.destroyBlock(new BlockPos((int) x, (int) digY, (int) (z - 2)), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						if (((((world.getBlockState(new BlockPos((int) (x + 1), (int) digY, (int) (z - 2))))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) (x + 1), (int) digY, (int) (z - 2))))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z - 2))).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) (x + 1), (int) digY, (int) (z - 2))), (World) world,
											new BlockPos((int) (x + 1), (int) digY, (int) (z - 2)));
									world.destroyBlock(new BlockPos((int) (x + 1), (int) digY, (int) (z - 2)), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						if (((((world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z - 2))))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z - 2))))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z - 2))).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z - 2))), (World) world,
											new BlockPos((int) (x - 1), (int) digY, (int) (z - 2)));
									world.destroyBlock(new BlockPos((int) (x - 1), (int) digY, (int) (z - 2)), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						digY = (double) (digY + 1);
					}
				} else if (((entity.getHorizontalFacing()) == Direction.SOUTH)) {
					digY = (double) y;
					if (((((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
							new AxisAlignedBB(x - (2 / 2d), y - (2 / 2d), (z + 4) - (2 / 2d), x + (2 / 2d), y + (2 / 2d), (z + 4) + (2 / 2d)), null)
							.stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf(x, y, (z + 4))).findFirst().orElse(null)) != null) == (true))) {
						if (((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
								new AxisAlignedBB(x - (2 / 2d), y - (2 / 2d), (z + 4) - (2 / 2d), x + (2 / 2d), y + (2 / 2d), (z + 4) + (2 / 2d)),
								null).stream().sorted(new Object() {
									Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
										return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
									}
								}.compareDistOf(x, y, (z + 4))).findFirst().orElse(null)) instanceof LivingEntity) {
							((LivingEntity) ((Entity) world.getEntitiesWithinAABB(LivingEntity.class,
									new AxisAlignedBB(x - (2 / 2d), y - (2 / 2d), (z + 4) - (2 / 2d), x + (2 / 2d), y + (2 / 2d), (z + 4) + (2 / 2d)),
									null).stream().sorted(new Object() {
										Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
											return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
										}
									}.compareDistOf(x, y, (z + 4))).findFirst().orElse(null)))
											.attackEntityFrom(new DamageSource("bore drill").setDamageBypassesArmor(), (float) 2);
						}
					}
					for (int index3 = 0; index3 < (int) (3); index3++) {
						if (((((world.getBlockState(new BlockPos((int) x, (int) digY, (int) (z + 2))))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) x, (int) digY, (int) (z + 2))))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z + 2))).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) x, (int) digY, (int) (z + 2))), (World) world,
											new BlockPos((int) x, (int) digY, (int) (z + 2)));
									world.destroyBlock(new BlockPos((int) x, (int) digY, (int) (z + 2)), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						if (((((world.getBlockState(new BlockPos((int) (x + 1), (int) digY, (int) (z + 2))))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) (x + 1), (int) digY, (int) (z + 2))))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z + 2))).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) (x + 1), (int) digY, (int) (z + 2))), (World) world,
											new BlockPos((int) (x + 1), (int) digY, (int) (z + 2)));
									world.destroyBlock(new BlockPos((int) (x + 1), (int) digY, (int) (z + 2)), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						if (((((world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z + 2))))
								.getMaterial() == net.minecraft.block.material.Material.ROCK) == (true))
								|| (((world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z + 2))))
										.getMaterial() == net.minecraft.block.material.Material.EARTH) == (true)))) {
							if ((3 >= (world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z + 2))).getHarvestLevel()))) {
								if (world instanceof World) {
									Block.spawnDrops(world.getBlockState(new BlockPos((int) (x - 1), (int) digY, (int) (z + 2))), (World) world,
											new BlockPos((int) (x - 1), (int) digY, (int) (z + 2)));
									world.destroyBlock(new BlockPos((int) (x - 1), (int) digY, (int) (z + 2)), false);
								}
								entity.getPersistentData().putDouble("workTick", ((entity.getPersistentData().getDouble("workTick")) + 1));
							}
						}
						digY = (double) (digY + 1);
					}
				}
			}
		}
	}
}
