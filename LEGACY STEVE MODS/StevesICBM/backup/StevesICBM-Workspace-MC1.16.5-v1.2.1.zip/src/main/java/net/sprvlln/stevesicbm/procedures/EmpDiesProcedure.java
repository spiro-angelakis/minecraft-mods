package net.sprvlln.stevesicbm.procedures;

import net.sprvlln.stevesicbm.entity.EmpPulseEntity;
import net.sprvlln.stevesicbm.StevesicbmMod;

import net.minecraftforge.energy.CapabilityEnergy;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Direction;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.ILivingEntityData;
import net.minecraft.entity.Entity;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.Map;

public class EmpDiesProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency x for procedure EmpDies!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency y for procedure EmpDies!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency z for procedure EmpDies!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency world for procedure EmpDies!");
			return;
		}
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		double blockX = 0;
		double blockY = 0;
		double blockZ = 0;
		double energyAmount = 0;
		if (world instanceof ServerWorld) {
			Entity entityToSpawn = new EmpPulseEntity.CustomEntity(EmpPulseEntity.entity, (World) world);
			entityToSpawn.setLocationAndAngles(x, y, z, world.getRandom().nextFloat() * 360F, 0);
			if (entityToSpawn instanceof MobEntity)
				((MobEntity) entityToSpawn).onInitialSpawn((ServerWorld) world, world.getDifficultyForLocation(entityToSpawn.getPosition()),
						SpawnReason.MOB_SUMMONED, (ILivingEntityData) null, (CompoundNBT) null);
			world.addEntity(entityToSpawn);
		}
		blockX = (double) (x - 16);
		blockY = (double) (y - 16);
		blockZ = (double) (z - 16);
		for (int index0 = 0; index0 < (int) (32); index0++) {
			for (int index1 = 0; index1 < (int) (32); index1++) {
				for (int index2 = 0; index2 < (int) (32); index2++) {
					if (((new Object() {
						public boolean canExtractEnergy(IWorld world, BlockPos pos) {
							AtomicBoolean _retval = new AtomicBoolean(false);
							TileEntity _ent = world.getTileEntity(pos);
							if (_ent != null)
								_ent.getCapability(CapabilityEnergy.ENERGY, Direction.DOWN)
										.ifPresent(capability -> _retval.set(capability.canExtract()));
							return _retval.get();
						}
					}.canExtractEnergy(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) == (true))) {
						if (((new Object() {
							public int getMaxEnergyStored(IWorld world, BlockPos pos) {
								AtomicInteger _retval = new AtomicInteger(0);
								TileEntity _ent = world.getTileEntity(pos);
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.DOWN)
											.ifPresent(capability -> _retval.set(capability.getMaxEnergyStored()));
								return _retval.get();
							}
						}.getMaxEnergyStored(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) > 1)) {
							energyAmount = (double) (new Object() {
								public int extractEnergySimulate(IWorld world, BlockPos pos, int _amount) {
									AtomicInteger _retval = new AtomicInteger(0);
									TileEntity _ent = world.getTileEntity(pos);
									if (_ent != null)
										_ent.getCapability(CapabilityEnergy.ENERGY, Direction.DOWN)
												.ifPresent(capability -> _retval.set(capability.extractEnergy(_amount, true)));
									return _retval.get();
								}
							}.extractEnergySimulate(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ), (int) 2147483647));
							{
								TileEntity _ent = world.getTileEntity(new BlockPos((int) blockX, (int) blockY, (int) blockZ));
								int _amount = (int) energyAmount;
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.DOWN)
											.ifPresent(capability -> capability.extractEnergy(_amount, false));
							}
						}
					} else if (((new Object() {
						public boolean canExtractEnergy(IWorld world, BlockPos pos) {
							AtomicBoolean _retval = new AtomicBoolean(false);
							TileEntity _ent = world.getTileEntity(pos);
							if (_ent != null)
								_ent.getCapability(CapabilityEnergy.ENERGY, Direction.UP)
										.ifPresent(capability -> _retval.set(capability.canExtract()));
							return _retval.get();
						}
					}.canExtractEnergy(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) == (true))) {
						if (((new Object() {
							public int getMaxEnergyStored(IWorld world, BlockPos pos) {
								AtomicInteger _retval = new AtomicInteger(0);
								TileEntity _ent = world.getTileEntity(pos);
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.UP)
											.ifPresent(capability -> _retval.set(capability.getMaxEnergyStored()));
								return _retval.get();
							}
						}.getMaxEnergyStored(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) > 1)) {
							energyAmount = (double) (new Object() {
								public int extractEnergySimulate(IWorld world, BlockPos pos, int _amount) {
									AtomicInteger _retval = new AtomicInteger(0);
									TileEntity _ent = world.getTileEntity(pos);
									if (_ent != null)
										_ent.getCapability(CapabilityEnergy.ENERGY, Direction.UP)
												.ifPresent(capability -> _retval.set(capability.extractEnergy(_amount, true)));
									return _retval.get();
								}
							}.extractEnergySimulate(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ), (int) 2147483647));
							{
								TileEntity _ent = world.getTileEntity(new BlockPos((int) blockX, (int) blockY, (int) blockZ));
								int _amount = (int) energyAmount;
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.UP)
											.ifPresent(capability -> capability.extractEnergy(_amount, false));
							}
						}
					} else if (((new Object() {
						public boolean canExtractEnergy(IWorld world, BlockPos pos) {
							AtomicBoolean _retval = new AtomicBoolean(false);
							TileEntity _ent = world.getTileEntity(pos);
							if (_ent != null)
								_ent.getCapability(CapabilityEnergy.ENERGY, Direction.WEST)
										.ifPresent(capability -> _retval.set(capability.canExtract()));
							return _retval.get();
						}
					}.canExtractEnergy(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) == (true))) {
						if (((new Object() {
							public int getMaxEnergyStored(IWorld world, BlockPos pos) {
								AtomicInteger _retval = new AtomicInteger(0);
								TileEntity _ent = world.getTileEntity(pos);
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.WEST)
											.ifPresent(capability -> _retval.set(capability.getMaxEnergyStored()));
								return _retval.get();
							}
						}.getMaxEnergyStored(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) > 1)) {
							energyAmount = (double) (new Object() {
								public int extractEnergySimulate(IWorld world, BlockPos pos, int _amount) {
									AtomicInteger _retval = new AtomicInteger(0);
									TileEntity _ent = world.getTileEntity(pos);
									if (_ent != null)
										_ent.getCapability(CapabilityEnergy.ENERGY, Direction.WEST)
												.ifPresent(capability -> _retval.set(capability.extractEnergy(_amount, true)));
									return _retval.get();
								}
							}.extractEnergySimulate(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ), (int) 2147483647));
							{
								TileEntity _ent = world.getTileEntity(new BlockPos((int) blockX, (int) blockY, (int) blockZ));
								int _amount = (int) energyAmount;
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.WEST)
											.ifPresent(capability -> capability.extractEnergy(_amount, false));
							}
						}
					} else if (((new Object() {
						public boolean canExtractEnergy(IWorld world, BlockPos pos) {
							AtomicBoolean _retval = new AtomicBoolean(false);
							TileEntity _ent = world.getTileEntity(pos);
							if (_ent != null)
								_ent.getCapability(CapabilityEnergy.ENERGY, Direction.EAST)
										.ifPresent(capability -> _retval.set(capability.canExtract()));
							return _retval.get();
						}
					}.canExtractEnergy(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) == (true))) {
						if (((new Object() {
							public int getMaxEnergyStored(IWorld world, BlockPos pos) {
								AtomicInteger _retval = new AtomicInteger(0);
								TileEntity _ent = world.getTileEntity(pos);
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.EAST)
											.ifPresent(capability -> _retval.set(capability.getMaxEnergyStored()));
								return _retval.get();
							}
						}.getMaxEnergyStored(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) > 1)) {
							energyAmount = (double) (new Object() {
								public int extractEnergySimulate(IWorld world, BlockPos pos, int _amount) {
									AtomicInteger _retval = new AtomicInteger(0);
									TileEntity _ent = world.getTileEntity(pos);
									if (_ent != null)
										_ent.getCapability(CapabilityEnergy.ENERGY, Direction.EAST)
												.ifPresent(capability -> _retval.set(capability.extractEnergy(_amount, true)));
									return _retval.get();
								}
							}.extractEnergySimulate(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ), (int) 2147483647));
							{
								TileEntity _ent = world.getTileEntity(new BlockPos((int) blockX, (int) blockY, (int) blockZ));
								int _amount = (int) energyAmount;
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.EAST)
											.ifPresent(capability -> capability.extractEnergy(_amount, false));
							}
						}
					} else if (((new Object() {
						public boolean canExtractEnergy(IWorld world, BlockPos pos) {
							AtomicBoolean _retval = new AtomicBoolean(false);
							TileEntity _ent = world.getTileEntity(pos);
							if (_ent != null)
								_ent.getCapability(CapabilityEnergy.ENERGY, Direction.NORTH)
										.ifPresent(capability -> _retval.set(capability.canExtract()));
							return _retval.get();
						}
					}.canExtractEnergy(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) == (true))) {
						if (((new Object() {
							public int getMaxEnergyStored(IWorld world, BlockPos pos) {
								AtomicInteger _retval = new AtomicInteger(0);
								TileEntity _ent = world.getTileEntity(pos);
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.NORTH)
											.ifPresent(capability -> _retval.set(capability.getMaxEnergyStored()));
								return _retval.get();
							}
						}.getMaxEnergyStored(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) > 1)) {
							energyAmount = (double) (new Object() {
								public int extractEnergySimulate(IWorld world, BlockPos pos, int _amount) {
									AtomicInteger _retval = new AtomicInteger(0);
									TileEntity _ent = world.getTileEntity(pos);
									if (_ent != null)
										_ent.getCapability(CapabilityEnergy.ENERGY, Direction.NORTH)
												.ifPresent(capability -> _retval.set(capability.extractEnergy(_amount, true)));
									return _retval.get();
								}
							}.extractEnergySimulate(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ), (int) 2147483647));
							{
								TileEntity _ent = world.getTileEntity(new BlockPos((int) blockX, (int) blockY, (int) blockZ));
								int _amount = (int) energyAmount;
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.NORTH)
											.ifPresent(capability -> capability.extractEnergy(_amount, false));
							}
						}
					} else {
						if (((new Object() {
							public int getMaxEnergyStored(IWorld world, BlockPos pos) {
								AtomicInteger _retval = new AtomicInteger(0);
								TileEntity _ent = world.getTileEntity(pos);
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.SOUTH)
											.ifPresent(capability -> _retval.set(capability.getMaxEnergyStored()));
								return _retval.get();
							}
						}.getMaxEnergyStored(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ))) > 1)) {
							energyAmount = (double) (new Object() {
								public int extractEnergySimulate(IWorld world, BlockPos pos, int _amount) {
									AtomicInteger _retval = new AtomicInteger(0);
									TileEntity _ent = world.getTileEntity(pos);
									if (_ent != null)
										_ent.getCapability(CapabilityEnergy.ENERGY, Direction.SOUTH)
												.ifPresent(capability -> _retval.set(capability.extractEnergy(_amount, true)));
									return _retval.get();
								}
							}.extractEnergySimulate(world, new BlockPos((int) blockX, (int) blockY, (int) blockZ), (int) 2147483647));
							{
								TileEntity _ent = world.getTileEntity(new BlockPos((int) blockX, (int) blockY, (int) blockZ));
								int _amount = (int) energyAmount;
								if (_ent != null)
									_ent.getCapability(CapabilityEnergy.ENERGY, Direction.SOUTH)
											.ifPresent(capability -> capability.extractEnergy(_amount, false));
							}
						}
					}
					blockZ = (double) (blockZ + 1);
				}
				blockZ = (double) (z - 16);
				blockX = (double) (blockX + 1);
			}
			blockX = (double) (x - 16);
			blockY = (double) (blockY + 1);
		}
	}
}
