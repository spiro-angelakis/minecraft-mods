package net.sprvlln.stevesicbm.procedures;

import net.sprvlln.stevesicbm.StevesicbmMod;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.gen.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;

import java.util.Map;

public class SpudnikDownwardOnInitialEntitySpawnProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency x for procedure SpudnikDownwardOnInitialEntitySpawn!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency z for procedure SpudnikDownwardOnInitialEntitySpawn!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency world for procedure SpudnikDownwardOnInitialEntitySpawn!");
			return;
		}
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		if (world instanceof World && !world.isRemote()) {
			((World) world).playSound(null,
					new BlockPos((int) x, (int) (world.getHeight(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z)), (int) z),
					(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("stevesicbm:travel_2")),
					SoundCategory.NEUTRAL, (float) 3, (float) 1);
		} else {
			((World) world).playSound(x, (world.getHeight(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z)), z,
					(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("stevesicbm:travel_2")),
					SoundCategory.NEUTRAL, (float) 3, (float) 1, false);
		}
	}
}
