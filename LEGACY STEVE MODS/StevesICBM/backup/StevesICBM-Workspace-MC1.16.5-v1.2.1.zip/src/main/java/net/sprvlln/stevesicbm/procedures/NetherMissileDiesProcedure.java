package net.sprvlln.stevesicbm.procedures;

import net.sprvlln.stevesicbm.StevesicbmMod;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.gen.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.entity.monster.ZoglinEntity;
import net.minecraft.entity.monster.WitherSkeletonEntity;
import net.minecraft.entity.monster.MagmaCubeEntity;
import net.minecraft.entity.monster.BlazeEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.ILivingEntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.Entity;
import net.minecraft.block.Blocks;

import java.util.Map;

public class NetherMissileDiesProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency x for procedure NetherMissileDies!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency z for procedure NetherMissileDies!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				StevesicbmMod.LOGGER.warn("Failed to load dependency world for procedure NetherMissileDies!");
			return;
		}
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		double spawnX = 0;
		double spawnY = 0;
		double spawnZ = 0;
		double spawnChance = 0;
		double blockSpawnType = 0;
		double entitySpawnType = 0;
		double spawnChanceTwo = 0;
		spawnX = (double) (x - 16);
		spawnZ = (double) (z - 16);
		for (int index0 = 0; index0 < (int) (32); index0++) {
			for (int index1 = 0; index1 < (int) (32); index1++) {
				spawnY = (double) ((world.getHeight(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) spawnX, (int) spawnZ)) - 1);
				blockSpawnType = (double) Math.random();
				if ((blockSpawnType >= 0.75)) {
					world.setBlockState(new BlockPos((int) spawnX, (int) spawnY, (int) spawnZ), Blocks.AIR.getDefaultState(), 3);
					world.setBlockState(new BlockPos((int) spawnX, (int) spawnY, (int) spawnZ), Blocks.LAVA.getDefaultState(), 3);
				} else if ((blockSpawnType >= 0.5)) {
					world.setBlockState(new BlockPos((int) spawnX, (int) spawnY, (int) spawnZ), Blocks.AIR.getDefaultState(), 3);
					world.setBlockState(new BlockPos((int) spawnX, (int) spawnY, (int) spawnZ), Blocks.MAGMA_BLOCK.getDefaultState(), 3);
				} else {
					world.setBlockState(new BlockPos((int) spawnX, (int) spawnY, (int) spawnZ), Blocks.AIR.getDefaultState(), 3);
					world.setBlockState(new BlockPos((int) spawnX, (int) spawnY, (int) spawnZ), Blocks.NETHERRACK.getDefaultState(), 3);
				}
				spawnChance = (double) Math.random();
				if ((spawnChance >= 0.9)) {
					spawnChanceTwo = (double) Math.random();
					if ((spawnChanceTwo >= 0.9)) {
						if (((world.getBlockState(new BlockPos((int) spawnX, (int) (spawnY + 3), (int) spawnZ)).isSolid()) == (true))) {
							world.setBlockState(new BlockPos((int) spawnX, (int) (spawnY + 3), (int) spawnZ), Blocks.AIR.getDefaultState(), 3);
						}
						entitySpawnType = (double) Math.random();
						if ((entitySpawnType >= 0.9)) {
							if (world instanceof ServerWorld) {
								Entity entityToSpawn = new ZoglinEntity(EntityType.ZOGLIN, (World) world);
								entityToSpawn.setLocationAndAngles(spawnX, (spawnY + 3), spawnZ, world.getRandom().nextFloat() * 360F, 0);
								if (entityToSpawn instanceof MobEntity)
									((MobEntity) entityToSpawn).onInitialSpawn((ServerWorld) world,
											world.getDifficultyForLocation(entityToSpawn.getPosition()), SpawnReason.MOB_SUMMONED,
											(ILivingEntityData) null, (CompoundNBT) null);
								world.addEntity(entityToSpawn);
							}
						} else if ((entitySpawnType >= 0.75)) {
							if (world instanceof ServerWorld) {
								Entity entityToSpawn = new BlazeEntity(EntityType.BLAZE, (World) world);
								entityToSpawn.setLocationAndAngles(spawnX, (spawnY + 3), spawnZ, world.getRandom().nextFloat() * 360F, 0);
								if (entityToSpawn instanceof MobEntity)
									((MobEntity) entityToSpawn).onInitialSpawn((ServerWorld) world,
											world.getDifficultyForLocation(entityToSpawn.getPosition()), SpawnReason.MOB_SUMMONED,
											(ILivingEntityData) null, (CompoundNBT) null);
								world.addEntity(entityToSpawn);
							}
						} else if ((entitySpawnType >= 0.5)) {
							if (world instanceof ServerWorld) {
								Entity entityToSpawn = new WitherSkeletonEntity(EntityType.WITHER_SKELETON, (World) world);
								entityToSpawn.setLocationAndAngles(spawnX, (spawnY + 3), spawnZ, world.getRandom().nextFloat() * 360F, 0);
								if (entityToSpawn instanceof MobEntity)
									((MobEntity) entityToSpawn).onInitialSpawn((ServerWorld) world,
											world.getDifficultyForLocation(entityToSpawn.getPosition()), SpawnReason.MOB_SUMMONED,
											(ILivingEntityData) null, (CompoundNBT) null);
								world.addEntity(entityToSpawn);
							}
						} else {
							if (world instanceof ServerWorld) {
								Entity entityToSpawn = new MagmaCubeEntity(EntityType.MAGMA_CUBE, (World) world);
								entityToSpawn.setLocationAndAngles(spawnX, (spawnY + 3), spawnZ, world.getRandom().nextFloat() * 360F, 0);
								if (entityToSpawn instanceof MobEntity)
									((MobEntity) entityToSpawn).onInitialSpawn((ServerWorld) world,
											world.getDifficultyForLocation(entityToSpawn.getPosition()), SpawnReason.MOB_SUMMONED,
											(ILivingEntityData) null, (CompoundNBT) null);
								world.addEntity(entityToSpawn);
							}
						}
					}
				}
				spawnZ = (double) (spawnZ + 1);
			}
			spawnZ = (double) (z - 16);
			spawnX = (double) (spawnX + 1);
		}
	}
}
