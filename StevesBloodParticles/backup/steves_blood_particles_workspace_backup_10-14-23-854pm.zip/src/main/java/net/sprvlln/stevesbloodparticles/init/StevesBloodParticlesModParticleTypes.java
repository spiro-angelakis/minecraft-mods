
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesbloodparticles.init;

import net.sprvlln.stevesbloodparticles.StevesBloodParticlesMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

public class StevesBloodParticlesModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, StevesBloodParticlesMod.MODID);
	public static final RegistryObject<SimpleParticleType> AQUA_BLOOD_PARTICLE_1 = REGISTRY.register("aqua_blood_particle_1", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> RED_BLOOD_PARTICLE_1 = REGISTRY.register("red_blood_particle_1", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> RED_BLOOD_PARTICLE_2 = REGISTRY.register("red_blood_particle_2", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> RED_BLOOD_PARTICLE_3 = REGISTRY.register("red_blood_particle_3", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> WHITE_BLOOD_PARTICLE_1 = REGISTRY.register("white_blood_particle_1", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> WHITE_BLOOD_PARTICLE_2 = REGISTRY.register("white_blood_particle_2", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> WHITE_BLOOD_PARTICLE_3 = REGISTRY.register("white_blood_particle_3", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> AQUA_BLOOD_PARTICLE_2 = REGISTRY.register("aqua_blood_particle_2", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> AQUA_BLOOD_PARTICLE_3 = REGISTRY.register("aqua_blood_particle_3", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> BLACK_BLOOD_PARTICLE_1 = REGISTRY.register("black_blood_particle_1", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> BLACK_BLOOD_PARTICLE_2 = REGISTRY.register("black_blood_particle_2", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> BLACK_BLOOD_PARTICLE_3 = REGISTRY.register("black_blood_particle_3", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> GREEN_BLOOD_PARTICLE_1 = REGISTRY.register("green_blood_particle_1", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> GREEN_BLOOD_PARTICLE_2 = REGISTRY.register("green_blood_particle_2", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> GREEN_BLOOD_PARTICLE_3 = REGISTRY.register("green_blood_particle_3", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> PURPLE_BLOOD_PARTICLE_1 = REGISTRY.register("purple_blood_particle_1", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> PURPLE_BLOOD_PARTICLE_2 = REGISTRY.register("purple_blood_particle_2", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> PURPLE_BLOOD_PARTICLE_3 = REGISTRY.register("purple_blood_particle_3", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> RED_BLOOD_HIGHLIGHT_PARTICLE = REGISTRY.register("red_blood_highlight_particle", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> AQUA_BLOOD_HIGHLIGHT_PARTICLE = REGISTRY.register("aqua_blood_highlight_particle", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> WHITE_BLOOD_HIGHLIGHT_PARTICLE = REGISTRY.register("white_blood_highlight_particle", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> BLACK_BLOOD_HIGHLIGHT_PARTICLE = REGISTRY.register("black_blood_highlight_particle", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> GREEN_BLOOD_HIGHLIGHT_PARTICLE = REGISTRY.register("green_blood_highlight_particle", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> PURPLE_BLOOD_HIGHLIGHT_PARTICLE = REGISTRY.register("purple_blood_highlight_particle", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> ORANGE_BLOOD_PARTICLE_1 = REGISTRY.register("orange_blood_particle_1", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> ORANGE_BLOOD_PARTICLE_2 = REGISTRY.register("orange_blood_particle_2", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> ORANGE_BLOOD_PARTICLE_3 = REGISTRY.register("orange_blood_particle_3", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> ORANGE_BLOOD_HIGHLIGHT_PARTICLE = REGISTRY.register("orange_blood_highlight_particle", () -> new SimpleParticleType(false));
}
