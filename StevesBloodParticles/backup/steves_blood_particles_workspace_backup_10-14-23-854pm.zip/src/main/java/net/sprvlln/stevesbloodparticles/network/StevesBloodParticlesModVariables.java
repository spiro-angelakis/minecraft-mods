package net.sprvlln.stevesbloodparticles.network;

import net.sprvlln.stevesbloodparticles.StevesBloodParticlesMod;

import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;

import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.CompoundTag;

import java.util.function.Supplier;
import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class StevesBloodParticlesModVariables {
	public static List<Object> aqua_blood_entities = new ArrayList<>();
	public static List<Object> red_blood_entities = new ArrayList<>();
	public static List<Object> white_blood_entities = new ArrayList<>();
	public static List<Object> black_blood_entities = new ArrayList<>();
	public static List<Object> green_blood_entities = new ArrayList<>();
	public static List<Object> purple_blood_entities = new ArrayList<>();
	public static List<Object> orange_blood_entities = new ArrayList<>();
	public static List<Object> blood_blacklist = new ArrayList<>();

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		StevesBloodParticlesMod.addNetworkMessage(SavedDataSyncMessage.class, SavedDataSyncMessage::buffer, SavedDataSyncMessage::new, SavedDataSyncMessage::handler);
	}

	@Mod.EventBusSubscriber
	public static class EventBusVariableHandlers {
		@SubscribeEvent
		public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
			if (!event.getEntity().level.isClientSide()) {
				SavedData mapdata = MapVariables.get(event.getEntity().level);
				SavedData worlddata = WorldVariables.get(event.getEntity().level);
				if (mapdata != null)
					StevesBloodParticlesMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) event.getEntity()), new SavedDataSyncMessage(0, mapdata));
				if (worlddata != null)
					StevesBloodParticlesMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) event.getEntity()), new SavedDataSyncMessage(1, worlddata));
			}
		}

		@SubscribeEvent
		public static void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
			if (!event.getEntity().level.isClientSide()) {
				SavedData worlddata = WorldVariables.get(event.getEntity().level);
				if (worlddata != null)
					StevesBloodParticlesMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) event.getEntity()), new SavedDataSyncMessage(1, worlddata));
			}
		}
	}

	public static class WorldVariables extends SavedData {
		public static final String DATA_NAME = "steves_blood_particles_worldvars";

		public static WorldVariables load(CompoundTag tag) {
			WorldVariables data = new WorldVariables();
			data.read(tag);
			return data;
		}

		public void read(CompoundTag nbt) {
		}

		@Override
		public CompoundTag save(CompoundTag nbt) {
			return nbt;
		}

		public void syncData(LevelAccessor world) {
			this.setDirty();
			if (world instanceof Level level && !level.isClientSide())
				StevesBloodParticlesMod.PACKET_HANDLER.send(PacketDistributor.DIMENSION.with(level::dimension), new SavedDataSyncMessage(1, this));
		}

		static WorldVariables clientSide = new WorldVariables();

		public static WorldVariables get(LevelAccessor world) {
			if (world instanceof ServerLevel level) {
				return level.getDataStorage().computeIfAbsent(e -> WorldVariables.load(e), WorldVariables::new, DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class MapVariables extends SavedData {
		public static final String DATA_NAME = "steves_blood_particles_mapvars";
		public double normal_blood_amount_mod = 0;
		public double small_blood_amount_mod = 0;
		public double large_blood_amount_mod = 0;
		public double highlight_blood_amount_mod = 0;
		public double small_blood_min_damage = 0;
		public double large_blood_min_damage = 0;
		public double highlight_blood_min_damage = 0;
		public double blood_area_size_mod = 0;
		public double normal_blood_speed = 0;
		public double small_blood_speed = 0;
		public double large_blood_speed = 0;
		public double min_damage_to_get_bleeding_potion_effect = 0;
		public double bleeding_potion_effect_chance_to_bleed_per_tick_out_of = 0;
		public double chance_to_get_bleeding_potion_effect = 0;
		public double bleeding_potion_effect_time_last = 0;

		public static MapVariables load(CompoundTag tag) {
			MapVariables data = new MapVariables();
			data.read(tag);
			return data;
		}

		public void read(CompoundTag nbt) {
			normal_blood_amount_mod = nbt.getDouble("normal_blood_amount_mod");
			small_blood_amount_mod = nbt.getDouble("small_blood_amount_mod");
			large_blood_amount_mod = nbt.getDouble("large_blood_amount_mod");
			highlight_blood_amount_mod = nbt.getDouble("highlight_blood_amount_mod");
			small_blood_min_damage = nbt.getDouble("small_blood_min_damage");
			large_blood_min_damage = nbt.getDouble("large_blood_min_damage");
			highlight_blood_min_damage = nbt.getDouble("highlight_blood_min_damage");
			blood_area_size_mod = nbt.getDouble("blood_area_size_mod");
			normal_blood_speed = nbt.getDouble("normal_blood_speed");
			small_blood_speed = nbt.getDouble("small_blood_speed");
			large_blood_speed = nbt.getDouble("large_blood_speed");
			min_damage_to_get_bleeding_potion_effect = nbt.getDouble("min_damage_to_get_bleeding_potion_effect");
			bleeding_potion_effect_chance_to_bleed_per_tick_out_of = nbt.getDouble("bleeding_potion_effect_chance_to_bleed_per_tick_out_of");
			chance_to_get_bleeding_potion_effect = nbt.getDouble("chance_to_get_bleeding_potion_effect");
			bleeding_potion_effect_time_last = nbt.getDouble("bleeding_potion_effect_time_last");
		}

		@Override
		public CompoundTag save(CompoundTag nbt) {
			nbt.putDouble("normal_blood_amount_mod", normal_blood_amount_mod);
			nbt.putDouble("small_blood_amount_mod", small_blood_amount_mod);
			nbt.putDouble("large_blood_amount_mod", large_blood_amount_mod);
			nbt.putDouble("highlight_blood_amount_mod", highlight_blood_amount_mod);
			nbt.putDouble("small_blood_min_damage", small_blood_min_damage);
			nbt.putDouble("large_blood_min_damage", large_blood_min_damage);
			nbt.putDouble("highlight_blood_min_damage", highlight_blood_min_damage);
			nbt.putDouble("blood_area_size_mod", blood_area_size_mod);
			nbt.putDouble("normal_blood_speed", normal_blood_speed);
			nbt.putDouble("small_blood_speed", small_blood_speed);
			nbt.putDouble("large_blood_speed", large_blood_speed);
			nbt.putDouble("min_damage_to_get_bleeding_potion_effect", min_damage_to_get_bleeding_potion_effect);
			nbt.putDouble("bleeding_potion_effect_chance_to_bleed_per_tick_out_of", bleeding_potion_effect_chance_to_bleed_per_tick_out_of);
			nbt.putDouble("chance_to_get_bleeding_potion_effect", chance_to_get_bleeding_potion_effect);
			nbt.putDouble("bleeding_potion_effect_time_last", bleeding_potion_effect_time_last);
			return nbt;
		}

		public void syncData(LevelAccessor world) {
			this.setDirty();
			if (world instanceof Level && !world.isClientSide())
				StevesBloodParticlesMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new SavedDataSyncMessage(0, this));
		}

		static MapVariables clientSide = new MapVariables();

		public static MapVariables get(LevelAccessor world) {
			if (world instanceof ServerLevelAccessor serverLevelAcc) {
				return serverLevelAcc.getLevel().getServer().getLevel(Level.OVERWORLD).getDataStorage().computeIfAbsent(e -> MapVariables.load(e), MapVariables::new, DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class SavedDataSyncMessage {
		public int type;
		public SavedData data;

		public SavedDataSyncMessage(FriendlyByteBuf buffer) {
			this.type = buffer.readInt();
			this.data = this.type == 0 ? new MapVariables() : new WorldVariables();
			if (this.data instanceof MapVariables _mapvars)
				_mapvars.read(buffer.readNbt());
			else if (this.data instanceof WorldVariables _worldvars)
				_worldvars.read(buffer.readNbt());
		}

		public SavedDataSyncMessage(int type, SavedData data) {
			this.type = type;
			this.data = data;
		}

		public static void buffer(SavedDataSyncMessage message, FriendlyByteBuf buffer) {
			buffer.writeInt(message.type);
			buffer.writeNbt(message.data.save(new CompoundTag()));
		}

		public static void handler(SavedDataSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					if (message.type == 0)
						MapVariables.clientSide = (MapVariables) message.data;
					else
						WorldVariables.clientSide = (WorldVariables) message.data;
				}
			});
			context.setPacketHandled(true);
		}
	}
}
