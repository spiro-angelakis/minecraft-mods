package net.sprvlln.stevesbloodparticles.procedures;

import net.sprvlln.stevesbloodparticles.network.StevesBloodParticlesModVariables;
import net.sprvlln.stevesbloodparticles.init.StevesBloodParticlesModMobEffects;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class EntityDamagedProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level, event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getAmount());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, double amount) {
		execute(null, world, x, y, z, entity, amount);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, double amount) {
		if (entity == null)
			return;
		double array_i = 0;
		if (amount >= StevesBloodParticlesModVariables.MapVariables.get(world).min_damage_to_get_bleeding_potion_effect) {
			if (Math.random() <= StevesBloodParticlesModVariables.MapVariables.get(world).chance_to_get_bleeding_potion_effect) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(StevesBloodParticlesModMobEffects.BLEEDING.get(), (int) (amount * 20 * StevesBloodParticlesModVariables.MapVariables.get(world).bleeding_potion_effect_time_last), 1, false, false));
			}
		}
		BleedProcedure.execute(world, x, y, z, entity, amount);
	}
}
