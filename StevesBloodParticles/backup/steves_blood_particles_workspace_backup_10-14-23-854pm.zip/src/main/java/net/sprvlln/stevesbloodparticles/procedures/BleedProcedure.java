package net.sprvlln.stevesbloodparticles.procedures;

import net.sprvlln.stevesbloodparticles.network.StevesBloodParticlesModVariables;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

public class BleedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, double amount) {
		if (entity == null)
			return;
		double array_i = 0;
		boolean handled_bleed = false;
		if (!StevesBloodParticlesModVariables.blood_blacklist.contains((ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()).toString()))) {
			handled_bleed = false;
			if (handled_bleed == false) {
				if (StevesBloodParticlesModVariables.aqua_blood_entities.contains((ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()).toString()))) {
					handled_bleed = true;
					BleedAquaProcedure.execute(world, x, y, z, entity, amount);
				}
			}
			if (handled_bleed == false) {
				if (StevesBloodParticlesModVariables.white_blood_entities.contains((ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()).toString()))) {
					handled_bleed = true;
					BleedWhiteProcedure.execute(world, x, y, z, entity, amount);
				}
			}
			if (handled_bleed == false) {
				if (StevesBloodParticlesModVariables.black_blood_entities.contains((ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()).toString()))) {
					handled_bleed = true;
					BleedBlackProcedure.execute(world, x, y, z, entity, amount);
				}
			}
			if (handled_bleed == false) {
				if (StevesBloodParticlesModVariables.green_blood_entities.contains((ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()).toString()))) {
					handled_bleed = true;
					BleedGreenProcedure.execute(world, x, y, z, entity, amount);
				}
			}
			if (handled_bleed == false) {
				if (StevesBloodParticlesModVariables.purple_blood_entities.contains((ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()).toString()))) {
					handled_bleed = true;
					BleedPurpleProcedure.execute(world, x, y, z, entity, amount);
				}
			}
			if (handled_bleed == false) {
				if (StevesBloodParticlesModVariables.orange_blood_entities.contains((ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()).toString()))) {
					handled_bleed = true;
					BleedOrangeProcedure.execute(world, x, y, z, entity, amount);
				}
			}
			if (handled_bleed == false) {
				handled_bleed = true;
				BleedRedProcedure.execute(world, x, y, z, entity, amount);
			}
		}
	}
}
