package net.sprvlln.stevesbloodparticles.procedures;

import net.sprvlln.stevesbloodparticles.network.StevesBloodParticlesModVariables;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.network.chat.Component;

public class TestProcedure {
	public static void execute(LevelAccessor world) {
		if (Mth.nextInt(RandomSource.create(), 1, (int) StevesBloodParticlesModVariables.MapVariables.get(world).bleeding_potion_effect_chance_to_bleed_per_tick_out_of) == 1) {
			if (!world.isClientSide() && world.getServer() != null)
				world.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Message"), false);
		}
	}
}
