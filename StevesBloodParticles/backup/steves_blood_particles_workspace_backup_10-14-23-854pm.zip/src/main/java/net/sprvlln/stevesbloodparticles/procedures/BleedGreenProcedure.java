package net.sprvlln.stevesbloodparticles.procedures;

import net.sprvlln.stevesbloodparticles.network.StevesBloodParticlesModVariables;
import net.sprvlln.stevesbloodparticles.init.StevesBloodParticlesModParticleTypes;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;

public class BleedGreenProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, double amount) {
		if (entity == null)
			return;
		double array_i = 0;
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (StevesBloodParticlesModParticleTypes.GREEN_BLOOD_PARTICLE_1.get()), x, (y + Mth.nextDouble(RandomSource.create(), entity.getBbHeight() / 4, entity.getBbHeight() / 2 + entity.getBbHeight() / 4)),
					z, (int) Math.round(amount * StevesBloodParticlesModVariables.MapVariables.get(world).normal_blood_amount_mod), ((entity.getBbWidth() / 2) * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod),
					((entity.getBbHeight() / 8) * 0.5 * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod), ((entity.getBbWidth() / 2) * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod),
					StevesBloodParticlesModVariables.MapVariables.get(world).normal_blood_speed);
		if (amount > StevesBloodParticlesModVariables.MapVariables.get(world).small_blood_min_damage) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (StevesBloodParticlesModParticleTypes.GREEN_BLOOD_PARTICLE_3.get()), x,
						(y + Mth.nextDouble(RandomSource.create(), entity.getBbHeight() / 4, entity.getBbHeight() / 2 + entity.getBbHeight() / 4)), z,
						(int) Math.round(amount * StevesBloodParticlesModVariables.MapVariables.get(world).small_blood_amount_mod), ((entity.getBbWidth() / 2) * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod),
						((entity.getBbHeight() / 8) * 0.5 * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod), ((entity.getBbWidth() / 2) * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod),
						StevesBloodParticlesModVariables.MapVariables.get(world).small_blood_speed);
		}
		if (amount > StevesBloodParticlesModVariables.MapVariables.get(world).large_blood_min_damage) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (StevesBloodParticlesModParticleTypes.GREEN_BLOOD_PARTICLE_2.get()), x,
						(y + Mth.nextDouble(RandomSource.create(), entity.getBbHeight() / 4, entity.getBbHeight() / 2 + entity.getBbHeight() / 4)), z,
						Mth.nextInt(RandomSource.create(), 0, (int) Math.round(amount * StevesBloodParticlesModVariables.MapVariables.get(world).large_blood_amount_mod)),
						((entity.getBbWidth() / 2) * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod), ((entity.getBbHeight() / 8) * 0.5 * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod),
						((entity.getBbWidth() / 2) * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod), StevesBloodParticlesModVariables.MapVariables.get(world).large_blood_speed);
		}
		if (amount > StevesBloodParticlesModVariables.MapVariables.get(world).highlight_blood_min_damage) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (StevesBloodParticlesModParticleTypes.GREEN_BLOOD_HIGHLIGHT_PARTICLE.get()), x,
						(y + Mth.nextDouble(RandomSource.create(), entity.getBbHeight() / 4, entity.getBbHeight() / 2 + entity.getBbHeight() / 4)), z,
						Mth.nextInt(RandomSource.create(), 0, (int) Math.round(amount * StevesBloodParticlesModVariables.MapVariables.get(world).highlight_blood_amount_mod)),
						((entity.getBbWidth() / 2) * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod), ((entity.getBbHeight() / 8) * 0.5 * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod),
						((entity.getBbWidth() / 2) * StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod), StevesBloodParticlesModVariables.MapVariables.get(world).small_blood_speed);
		}
	}
}
