package net.sprvlln.stevesbloodparticles.procedures;

import net.sprvlln.stevesbloodparticles.network.StevesBloodParticlesModVariables;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

public class CallForceBleed {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (Mth.nextInt(RandomSource.create(), 1, (int) StevesBloodParticlesModVariables.MapVariables.get(world).bleeding_potion_effect_chance_to_bleed_per_tick_out_of) == 1) {
			BleedProcedure.execute(world, x, y, z, entity, 8.0);
		}
	}
}
