
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesbloodparticles.init;

import net.sprvlln.stevesbloodparticles.client.particle.WhiteBloodParticle3Particle;
import net.sprvlln.stevesbloodparticles.client.particle.WhiteBloodParticle2Particle;
import net.sprvlln.stevesbloodparticles.client.particle.WhiteBloodParticle1Particle;
import net.sprvlln.stevesbloodparticles.client.particle.WhiteBloodHighlightParticleParticle;
import net.sprvlln.stevesbloodparticles.client.particle.RedBloodParticle3Particle;
import net.sprvlln.stevesbloodparticles.client.particle.RedBloodParticle2Particle;
import net.sprvlln.stevesbloodparticles.client.particle.RedBloodParticle1Particle;
import net.sprvlln.stevesbloodparticles.client.particle.RedBloodHighlightParticleParticle;
import net.sprvlln.stevesbloodparticles.client.particle.PurpleBloodParticle3Particle;
import net.sprvlln.stevesbloodparticles.client.particle.PurpleBloodParticle2Particle;
import net.sprvlln.stevesbloodparticles.client.particle.PurpleBloodParticle1Particle;
import net.sprvlln.stevesbloodparticles.client.particle.PurpleBloodHighlightParticleParticle;
import net.sprvlln.stevesbloodparticles.client.particle.OrangeBloodParticle3Particle;
import net.sprvlln.stevesbloodparticles.client.particle.OrangeBloodParticle2Particle;
import net.sprvlln.stevesbloodparticles.client.particle.OrangeBloodParticle1Particle;
import net.sprvlln.stevesbloodparticles.client.particle.OrangeBloodHighlightParticleParticle;
import net.sprvlln.stevesbloodparticles.client.particle.GreenBloodParticle3Particle;
import net.sprvlln.stevesbloodparticles.client.particle.GreenBloodParticle2Particle;
import net.sprvlln.stevesbloodparticles.client.particle.GreenBloodParticle1Particle;
import net.sprvlln.stevesbloodparticles.client.particle.GreenBloodHighlightParticleParticle;
import net.sprvlln.stevesbloodparticles.client.particle.BlackBloodParticle3Particle;
import net.sprvlln.stevesbloodparticles.client.particle.BlackBloodParticle2Particle;
import net.sprvlln.stevesbloodparticles.client.particle.BlackBloodParticle1Particle;
import net.sprvlln.stevesbloodparticles.client.particle.BlackBloodHighlightParticleParticle;
import net.sprvlln.stevesbloodparticles.client.particle.AquaBloodParticle3Particle;
import net.sprvlln.stevesbloodparticles.client.particle.AquaBloodParticle2Particle;
import net.sprvlln.stevesbloodparticles.client.particle.AquaBloodParticle1Particle;
import net.sprvlln.stevesbloodparticles.client.particle.AquaBloodHighlightParticleParticle;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class StevesBloodParticlesModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.register(StevesBloodParticlesModParticleTypes.AQUA_BLOOD_PARTICLE_1.get(), AquaBloodParticle1Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.RED_BLOOD_PARTICLE_1.get(), RedBloodParticle1Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.RED_BLOOD_PARTICLE_2.get(), RedBloodParticle2Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.RED_BLOOD_PARTICLE_3.get(), RedBloodParticle3Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.WHITE_BLOOD_PARTICLE_1.get(), WhiteBloodParticle1Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.WHITE_BLOOD_PARTICLE_2.get(), WhiteBloodParticle2Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.WHITE_BLOOD_PARTICLE_3.get(), WhiteBloodParticle3Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.AQUA_BLOOD_PARTICLE_2.get(), AquaBloodParticle2Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.AQUA_BLOOD_PARTICLE_3.get(), AquaBloodParticle3Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.BLACK_BLOOD_PARTICLE_1.get(), BlackBloodParticle1Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.BLACK_BLOOD_PARTICLE_2.get(), BlackBloodParticle2Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.BLACK_BLOOD_PARTICLE_3.get(), BlackBloodParticle3Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.GREEN_BLOOD_PARTICLE_1.get(), GreenBloodParticle1Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.GREEN_BLOOD_PARTICLE_2.get(), GreenBloodParticle2Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.GREEN_BLOOD_PARTICLE_3.get(), GreenBloodParticle3Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.PURPLE_BLOOD_PARTICLE_1.get(), PurpleBloodParticle1Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.PURPLE_BLOOD_PARTICLE_2.get(), PurpleBloodParticle2Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.PURPLE_BLOOD_PARTICLE_3.get(), PurpleBloodParticle3Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.RED_BLOOD_HIGHLIGHT_PARTICLE.get(), RedBloodHighlightParticleParticle::provider);
		event.register(StevesBloodParticlesModParticleTypes.AQUA_BLOOD_HIGHLIGHT_PARTICLE.get(), AquaBloodHighlightParticleParticle::provider);
		event.register(StevesBloodParticlesModParticleTypes.WHITE_BLOOD_HIGHLIGHT_PARTICLE.get(), WhiteBloodHighlightParticleParticle::provider);
		event.register(StevesBloodParticlesModParticleTypes.BLACK_BLOOD_HIGHLIGHT_PARTICLE.get(), BlackBloodHighlightParticleParticle::provider);
		event.register(StevesBloodParticlesModParticleTypes.GREEN_BLOOD_HIGHLIGHT_PARTICLE.get(), GreenBloodHighlightParticleParticle::provider);
		event.register(StevesBloodParticlesModParticleTypes.PURPLE_BLOOD_HIGHLIGHT_PARTICLE.get(), PurpleBloodHighlightParticleParticle::provider);
		event.register(StevesBloodParticlesModParticleTypes.ORANGE_BLOOD_PARTICLE_1.get(), OrangeBloodParticle1Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.ORANGE_BLOOD_PARTICLE_2.get(), OrangeBloodParticle2Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.ORANGE_BLOOD_PARTICLE_3.get(), OrangeBloodParticle3Particle::provider);
		event.register(StevesBloodParticlesModParticleTypes.ORANGE_BLOOD_HIGHLIGHT_PARTICLE.get(), OrangeBloodHighlightParticleParticle::provider);
	}
}
