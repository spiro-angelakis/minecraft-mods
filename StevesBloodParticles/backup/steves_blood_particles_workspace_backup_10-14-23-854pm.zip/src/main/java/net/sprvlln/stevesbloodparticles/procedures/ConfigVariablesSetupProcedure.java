package net.sprvlln.stevesbloodparticles.procedures;

import net.sprvlln.stevesbloodparticles.network.StevesBloodParticlesModVariables;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;

import net.minecraft.world.level.LevelAccessor;

import javax.annotation.Nullable;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

@Mod.EventBusSubscriber
public class ConfigVariablesSetupProcedure {
	@SubscribeEvent
	public static void onWorldLoad(net.minecraftforge.event.level.LevelEvent.Load event) {
		execute(event, event.getLevel());
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		File steves_blood_config = new File("");
		com.google.gson.JsonObject main_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject aqua_entities_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject white_entities_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject black_entities_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject green_entities_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject purple_entities_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject orange_entities_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject blacklist_json = new com.google.gson.JsonObject();
		double array_i = 0;
		double aqua_entity_count = 0;
		double white_entity_count = 0;
		double black_entity_count = 0;
		double green_entity_count = 0;
		double purple_entity_count = 0;
		double orange_entity_count = 0;
		double blacklist_count = 0;
		steves_blood_config = new File((FMLPaths.GAMEDIR.get().toString() + "/config/sprvlln/"), File.separator + "steves_blood_particles.json");
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(steves_blood_config));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				main_json = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				StevesBloodParticlesModVariables.MapVariables.get(world).min_damage_to_get_bleeding_potion_effect = main_json.get("min_damage_to_get_bleeding_potion_effect").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).chance_to_get_bleeding_potion_effect = main_json.get("chance_to_get_bleeding_potion_effect").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).bleeding_potion_effect_time_last = main_json.get("bleeding_potion_effect_time_last").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).bleeding_potion_effect_chance_to_bleed_per_tick_out_of = main_json.get("bleeding_potion_effect_chance_to_bleed_per_tick_out_of").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).normal_blood_amount_mod = main_json.get("normal_blood_amount_mod").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).small_blood_amount_mod = main_json.get("small_blood_amount_mod").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).large_blood_amount_mod = main_json.get("large_blood_amount_mod").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).highlight_blood_amount_mod = main_json.get("highlight_blood_amount_mod").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).small_blood_min_damage = main_json.get("small_blood_min_damage").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).large_blood_min_damage = main_json.get("large_blood_min_damage").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).highlight_blood_min_damage = main_json.get("highlight_blood_min_damage").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).blood_area_size_mod = main_json.get("blood_area_size_mod").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).normal_blood_speed = main_json.get("normal_blood_speed").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).small_blood_speed = main_json.get("small_blood_speed").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				StevesBloodParticlesModVariables.MapVariables.get(world).large_blood_speed = main_json.get("large_blood_speed").getAsDouble();
				StevesBloodParticlesModVariables.MapVariables.get(world).syncData(world);
				blacklist_json = main_json.get("blacklist_entities").getAsJsonObject();
				blacklist_count = main_json.get("blacklist_entities_max").getAsDouble();
				array_i = 0;
				for (int index0 = 0; index0 < (int) blacklist_count; index0++) {
					StevesBloodParticlesModVariables.blood_blacklist.add(blacklist_json.get(("blacklist_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1))).getAsString());
					array_i = array_i + 1;
				}
				aqua_entities_json = main_json.get("aqua_blood_entities").getAsJsonObject();
				aqua_entity_count = main_json.get("aqua_blood_entities_max").getAsDouble();
				array_i = 0;
				for (int index1 = 0; index1 < (int) aqua_entity_count; index1++) {
					StevesBloodParticlesModVariables.aqua_blood_entities.add(aqua_entities_json.get(("aqua_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1))).getAsString());
					array_i = array_i + 1;
				}
				white_entities_json = main_json.get("white_blood_entities").getAsJsonObject();
				white_entity_count = main_json.get("white_blood_entities_max").getAsDouble();
				array_i = 0;
				for (int index2 = 0; index2 < (int) white_entity_count; index2++) {
					StevesBloodParticlesModVariables.white_blood_entities.add(white_entities_json.get(("white_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1))).getAsString());
					array_i = array_i + 1;
				}
				black_entities_json = main_json.get("black_blood_entities").getAsJsonObject();
				black_entity_count = main_json.get("black_blood_entities_max").getAsDouble();
				array_i = 0;
				for (int index3 = 0; index3 < (int) black_entity_count; index3++) {
					StevesBloodParticlesModVariables.black_blood_entities.add(black_entities_json.get(("black_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1))).getAsString());
					array_i = array_i + 1;
				}
				green_entities_json = main_json.get("green_blood_entities").getAsJsonObject();
				green_entity_count = main_json.get("green_blood_entities_max").getAsDouble();
				array_i = 0;
				for (int index4 = 0; index4 < (int) green_entity_count; index4++) {
					StevesBloodParticlesModVariables.green_blood_entities.add(green_entities_json.get(("green_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1))).getAsString());
					array_i = array_i + 1;
				}
				purple_entities_json = main_json.get("purple_blood_entities").getAsJsonObject();
				purple_entity_count = main_json.get("purple_blood_entities_max").getAsDouble();
				array_i = 0;
				for (int index5 = 0; index5 < (int) purple_entity_count; index5++) {
					StevesBloodParticlesModVariables.purple_blood_entities.add(purple_entities_json.get(("purple_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1))).getAsString());
					array_i = array_i + 1;
				}
				orange_entities_json = main_json.get("orange_blood_entities").getAsJsonObject();
				orange_entity_count = main_json.get("orange_blood_entities_max").getAsDouble();
				array_i = 0;
				for (int index6 = 0; index6 < (int) orange_entity_count; index6++) {
					StevesBloodParticlesModVariables.orange_blood_entities.add(orange_entities_json.get(("orange_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1))).getAsString());
					array_i = array_i + 1;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
