package net.sprvlln.stevesbloodparticles.procedures;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;

import java.util.List;
import java.util.ArrayList;

import java.io.IOException;
import java.io.FileWriter;
import java.io.File;

import com.google.gson.GsonBuilder;
import com.google.gson.Gson;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BloodConfigFileProcedure {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		execute();
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		File steves_blood_config = new File("");
		double array_i = 0;
		List<Object> aqua_defaults = new ArrayList<>();
		List<Object> white_defaults = new ArrayList<>();
		List<Object> black_defaults = new ArrayList<>();
		List<Object> green_defaults = new ArrayList<>();
		List<Object> purple_defaults = new ArrayList<>();
		List<Object> orange_defaults = new ArrayList<>();
		List<Object> blacklist = new ArrayList<>();
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		com.google.gson.JsonObject aqua_defaults_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject white_defaults_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject black_defaults_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject green_defaults_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject purple_defaults_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject orange_defaults_json = new com.google.gson.JsonObject();
		com.google.gson.JsonObject blacklist_json = new com.google.gson.JsonObject();
		steves_blood_config = new File((FMLPaths.GAMEDIR.get().toString() + "/config/sprvlln/"), File.separator + "steves_blood_particles.json");
		if (!steves_blood_config.exists()) {
			try {
				steves_blood_config.getParentFile().mkdirs();
				steves_blood_config.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			main_json_object.addProperty("min_damage_to_get_bleeding_potion_effect", 6);
			main_json_object.addProperty("chance_to_get_bleeding_potion_effect", 0.97);
			main_json_object.addProperty("bleeding_potion_effect_time_last", 0.5);
			main_json_object.addProperty("bleeding_potion_effect_chance_to_bleed_per_tick_out_of", 1);
			main_json_object.addProperty("normal_blood_amount_mod", 2);
			main_json_object.addProperty("small_blood_amount_mod", 3);
			main_json_object.addProperty("large_blood_amount_mod", 0.5);
			main_json_object.addProperty("highlight_blood_amount_mod", 1);
			main_json_object.addProperty("small_blood_min_damage", 3);
			main_json_object.addProperty("large_blood_min_damage", 8);
			main_json_object.addProperty("highlight_blood_min_damage", 4);
			main_json_object.addProperty("blood_area_size_mod", 0.5);
			main_json_object.addProperty("normal_blood_speed", 0.1);
			main_json_object.addProperty("small_blood_speed", 0.15);
			main_json_object.addProperty("large_blood_speed", 0.1);
			main_json_object.addProperty("blacklist_entities_max", 2);
			blacklist.add("minecraft:skeleton");
			blacklist.add("minecraft:wither_skeleton");
			array_i = 0;
			for (int index0 = 0; index0 < (int) blacklist.size(); index0++) {
				blacklist_json.addProperty(("blacklist_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1)), blacklist.get((int) array_i) instanceof String _s ? _s : "");
				array_i = array_i + 1;
			}
			main_json_object.add("blacklist_entities", blacklist_json);
			main_json_object.addProperty("aqua_blood_entities_max", 0);
			aqua_defaults.add("minecraft:skeleton");
			array_i = 0;
			for (int index1 = 0; index1 < (int) aqua_defaults.size(); index1++) {
				aqua_defaults_json.addProperty(("aqua_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1)), aqua_defaults.get((int) array_i) instanceof String _s ? _s : "");
				array_i = array_i + 1;
			}
			main_json_object.add("aqua_blood_entities", aqua_defaults_json);
			main_json_object.addProperty("white_blood_entities_max", 1);
			white_defaults.add("minecraft:ender_dragon");
			array_i = 0;
			for (int index2 = 0; index2 < (int) white_defaults.size(); index2++) {
				white_defaults_json.addProperty(("white_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1)), white_defaults.get((int) array_i) instanceof String _s ? _s : "");
				array_i = array_i + 1;
			}
			main_json_object.add("white_blood_entities", white_defaults_json);
			main_json_object.addProperty("black_blood_entities_max", 1);
			black_defaults.add("minecraft:blaze");
			array_i = 0;
			for (int index3 = 0; index3 < (int) black_defaults.size(); index3++) {
				black_defaults_json.addProperty(("black_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1)), black_defaults.get((int) array_i) instanceof String _s ? _s : "");
				array_i = array_i + 1;
			}
			main_json_object.add("black_blood_entities", black_defaults_json);
			main_json_object.addProperty("green_blood_entities_max", 2);
			green_defaults.add("minecraft:creeper");
			green_defaults.add("minecraft:slime");
			array_i = 0;
			for (int index4 = 0; index4 < (int) green_defaults.size(); index4++) {
				green_defaults_json.addProperty(("green_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1)), green_defaults.get((int) array_i) instanceof String _s ? _s : "");
				array_i = array_i + 1;
			}
			main_json_object.add("green_blood_entities", green_defaults_json);
			main_json_object.addProperty("purple_blood_entities_max", 1);
			purple_defaults.add("minecraft:enderman");
			array_i = 0;
			for (int index5 = 0; index5 < (int) purple_defaults.size(); index5++) {
				purple_defaults_json.addProperty(("purple_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1)), purple_defaults.get((int) array_i) instanceof String _s ? _s : "");
				array_i = array_i + 1;
			}
			main_json_object.add("purple_blood_entities", purple_defaults_json);
			main_json_object.addProperty("orange_blood_entities_max", 1);
			orange_defaults.add("minecraft:magma_cube");
			array_i = 0;
			for (int index6 = 0; index6 < (int) orange_defaults.size(); index6++) {
				orange_defaults_json.addProperty(("orange_blood_entity_" + new java.text.DecimalFormat("##.##").format(array_i + 1)), orange_defaults.get((int) array_i) instanceof String _s ? _s : "");
				array_i = array_i + 1;
			}
			main_json_object.add("orange_blood_entities", orange_defaults_json);
			{
				Gson mainGSONBuilderVariable = new GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(steves_blood_config);
					fileWriter.write(mainGSONBuilderVariable.toJson(main_json_object));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		}
	}
}
