
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.steveswasteland3.init;

import net.sprvlln.steveswasteland3.fluid.types.RadWaterFluidType;
import net.sprvlln.steveswasteland3.StevesWasteland3Mod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

public class StevesWasteland3ModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, StevesWasteland3Mod.MODID);
	public static final RegistryObject<FluidType> RAD_WATER_TYPE = REGISTRY.register("rad_water", () -> new RadWaterFluidType());
}
