
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.steveswasteland3.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class StevesWasteland3ModTabs {
	public static CreativeModeTab TAB_STEVES_WASTELAND_CREATIVE_TAB;

	public static void load() {
		TAB_STEVES_WASTELAND_CREATIVE_TAB = new CreativeModeTab("tabsteves_wasteland_creative_tab") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(StevesWasteland3ModItems.ATOMIC_ITEM.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
