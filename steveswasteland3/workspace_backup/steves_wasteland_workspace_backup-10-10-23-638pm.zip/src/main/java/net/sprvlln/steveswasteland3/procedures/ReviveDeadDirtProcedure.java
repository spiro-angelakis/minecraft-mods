package net.sprvlln.steveswasteland3.procedures;

import net.sprvlln.steveswasteland3.network.StevesWasteland3ModVariables;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class ReviveDeadDirtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double reviveChance = 0;
		boolean willRevive = false;
		willRevive = false;
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).dead_dirt_revival_chance) {
			willRevive = true;
		}
		if (willRevive == true) {
			world.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 3);
			world.setBlock(new BlockPos(x, y, z), Blocks.DIRT.defaultBlockState(), 3);
		}
	}
}
