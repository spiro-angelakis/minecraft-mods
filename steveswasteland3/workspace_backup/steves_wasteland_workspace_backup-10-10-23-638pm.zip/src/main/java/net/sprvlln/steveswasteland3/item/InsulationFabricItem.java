
package net.sprvlln.steveswasteland3.item;

import net.sprvlln.steveswasteland3.init.StevesWasteland3ModTabs;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class InsulationFabricItem extends Item {
	public InsulationFabricItem() {
		super(new Item.Properties().tab(StevesWasteland3ModTabs.TAB_STEVES_WASTELAND_CREATIVE_TAB).stacksTo(64).rarity(Rarity.COMMON));
	}
}
