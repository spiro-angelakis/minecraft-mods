package net.sprvlln.steveswasteland3.procedures;

import net.sprvlln.steveswasteland3.network.StevesWasteland3ModVariables;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.monster.ZombieVillager;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class ZombieHordeEventProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double hordeCount = 0;
		double zombieType = 0;
		double spawnX = 0;
		double spawnZ = 0;
		double hordeX = 0;
		double hordeZ = 0;
		double xOffset = 0;
		double zOffset = 0;
		double nearbyZombies = 0;
		boolean canDoEvent = false;
		canDoEvent = true;
		nearbyZombies = 0;
		{
			final Vec3 _center = new Vec3(x, y, z);
			List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(StevesWasteland3ModVariables.MapVariables.get(world).distance_check_for_hordes / 2d), e -> true).stream()
					.sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
			for (Entity entityiterator : _entfound) {
				if (entityiterator.getType().is(TagKey.create(Registry.ENTITY_TYPE_REGISTRY, new ResourceLocation("forge:zombie")))) {
					nearbyZombies = nearbyZombies + 1;
				}
			}
		}
		if (nearbyZombies >= StevesWasteland3ModVariables.MapVariables.get(world).max_zombies_near_players) {
			canDoEvent = false;
		}
		if (canDoEvent) {
			hordeCount = Mth.nextInt(RandomSource.create(), (int) StevesWasteland3ModVariables.MapVariables.get(world).horde_min_heads, (int) StevesWasteland3ModVariables.MapVariables.get(world).horde_max_heads);
			xOffset = Mth.nextInt(RandomSource.create(), 80, 120);
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 1) {
				xOffset = -xOffset;
			}
			zOffset = Mth.nextInt(RandomSource.create(), 80, 120);
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 1) {
				zOffset = -zOffset;
			}
			hordeX = x + Mth.nextInt(RandomSource.create(), (int) (-StevesWasteland3ModVariables.MapVariables.get(world).horde_size_area), (int) StevesWasteland3ModVariables.MapVariables.get(world).horde_size_area);
			hordeZ = z + Mth.nextInt(RandomSource.create(), (int) (-StevesWasteland3ModVariables.MapVariables.get(world).horde_size_area), (int) StevesWasteland3ModVariables.MapVariables.get(world).horde_size_area);
			for (int index0 = 0; index0 < (int) hordeCount; index0++) {
				spawnX = hordeX + Mth.nextInt(RandomSource.create(), -8, 8);
				spawnZ = hordeZ + Mth.nextInt(RandomSource.create(), -8, 8);
				if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).villager_zombie_to_zombie_ratio) {
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = new ZombieVillager(EntityType.ZOMBIE_VILLAGER, _level);
						entityToSpawn.moveTo(spawnX, (world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) spawnX, (int) spawnZ)), spawnZ, 0, 0);
						entityToSpawn.setYBodyRot(0);
						entityToSpawn.setYHeadRot(0);
						entityToSpawn.setDeltaMovement(0, 0, 0);
						if (entityToSpawn instanceof Mob _mobToSpawn)
							_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
						world.addFreshEntity(entityToSpawn);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = new Zombie(EntityType.ZOMBIE, _level);
						entityToSpawn.moveTo(spawnX, (world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) spawnX, (int) spawnZ)), spawnZ, 0, 0);
						entityToSpawn.setYBodyRot(0);
						entityToSpawn.setYHeadRot(0);
						entityToSpawn.setDeltaMovement(0, 0, 0);
						if (entityToSpawn instanceof Mob _mobToSpawn)
							_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
						world.addFreshEntity(entityToSpawn);
					}
				}
			}
		}
	}
}
