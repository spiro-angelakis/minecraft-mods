package net.sprvlln.steveswasteland3.procedures;

import net.sprvlln.steveswasteland3.network.StevesWasteland3ModVariables;

import net.minecraftforge.fml.loading.FMLPaths;

import net.minecraft.world.level.LevelAccessor;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

public class SetupConfigVariablesProcedure {
	public static void execute(LevelAccessor world) {
		File steves_wasteland_config = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		steves_wasteland_config = new File((FMLPaths.GAMEDIR.get().toString() + "/config/sprvlln/"), File.separator + "steves_wasteland.json");
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(steves_wasteland_config));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				main_json_object = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				StevesWasteland3ModVariables.MapVariables.get(world).rad_sickness_duration = main_json_object.get("rad_sickness_duration_ticks").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).rad_sickness_poison_chance = main_json_object.get("rad_sickness_chance_to_poison").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).rad_poisoning_duration = main_json_object.get("rad_poisoning_duration_ticks").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).rad_poisoning_initial_damage = main_json_object.get("rad_poisoning_initial_damage").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).rad_poisoning_active_damage = main_json_object.get("rad_poisoning_active_damage").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).rad_poisoning_chance_to_damage = main_json_object.get("rad_poisoning_chance_to_damage").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).rad_block_spread_chance = main_json_object.get("rad_block_spread_chance").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).rad_fluid_spread_chance = main_json_object.get("rad_fluid_spread_chance").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).dead_dirt_to_rad_chance = main_json_object.get("dead_dirt_to_rad_chance").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).dead_dirt_revival_chance = main_json_object.get("dead_dirt_revival_chance").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).chance_for_zombie_spawns_out_of = main_json_object.get("chance_for_zombie_spawns_out_of").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).chance_for_horde_spawns_out_of = main_json_object.get("chance_for_horde_spawns_out_of").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).day_zombie_spawns_mod = main_json_object.get("day_zombie_spawns_mod").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).night_zombie_spawns_mod = main_json_object.get("night_zombie_spawns_mod").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).max_zombies_near_players = main_json_object.get("max_zombies_near_players").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).zombie_events_only_in_wastes = main_json_object.get("zombie_events_only_in_wastes").getAsBoolean();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).zombie_events_only_on_earth = main_json_object.get("zombie_events_only_on_earth").getAsBoolean();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).distance_check_for_hordes = main_json_object.get("distance_check_for_hordes").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).horde_min_heads = main_json_object.get("horde_min_heads").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).horde_max_heads = main_json_object.get("horde_max_heads").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).horde_size_area = main_json_object.get("horde_size_area").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).distance_check_for_zombies = main_json_object.get("distance_check_for_zombies").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).pack_min_heads = main_json_object.get("pack_min_heads").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).pack_max_heads = main_json_object.get("pack_max_heads").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).pack_size_area = main_json_object.get("pack_size_area").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).player_ticks_before_zombie_event_chance = main_json_object.get("player_ticks_before_zombie_event_chance").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
				StevesWasteland3ModVariables.MapVariables.get(world).villager_zombie_to_zombie_ratio = main_json_object.get("villager_zombie_to_zombie_ratio").getAsDouble();
				StevesWasteland3ModVariables.MapVariables.get(world).syncData(world);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
