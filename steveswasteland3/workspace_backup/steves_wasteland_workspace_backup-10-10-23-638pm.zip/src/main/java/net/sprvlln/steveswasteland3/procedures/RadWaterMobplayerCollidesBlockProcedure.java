package net.sprvlln.steveswasteland3.procedures;

import net.sprvlln.steveswasteland3.network.StevesWasteland3ModVariables;
import net.sprvlln.steveswasteland3.init.StevesWasteland3ModMobEffects;
import net.sprvlln.steveswasteland3.init.StevesWasteland3ModItems;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

public class RadWaterMobplayerCollidesBlockProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		boolean able = false;
		boolean armor_foot = false;
		boolean armor_legs = false;
		boolean armor_chest = false;
		boolean armor_head = false;
		able = true;
		armor_foot = false;
		armor_legs = false;
		armor_chest = false;
		armor_head = false;
		if (entity.getType().is(TagKey.create(Registry.ENTITY_TYPE_REGISTRY, new ResourceLocation("steves_wasteland3:rad_proof"))) == true) {
			able = false;
		}
		if ((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY).getItem() == StevesWasteland3ModItems.INSULATION_ARMOR_BOOTS.get()
				|| (ForgeRegistries.ITEMS.getKey((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY).getItem()).toString()).equals("ic2:armor_hazmat_boots")
				|| (ForgeRegistries.ITEMS.getKey((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY).getItem()).toString()).equals("mekanism:hazmat_boots")) {
			armor_foot = true;
		}
		if ((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY).getItem() == StevesWasteland3ModItems.INSULATION_ARMOR_LEGGINGS.get()
				|| (ForgeRegistries.ITEMS.getKey((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY).getItem()).toString()).equals("ic2:armor_hazmat_leggings")
				|| (ForgeRegistries.ITEMS.getKey((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY).getItem()).toString()).equals("mekanism:hazmat_pants")) {
			armor_legs = true;
		}
		if ((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY).getItem() == StevesWasteland3ModItems.INSULATION_ARMOR_CHESTPLATE.get()
				|| (ForgeRegistries.ITEMS.getKey((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY).getItem()).toString()).equals("ic2:armor_hazmat_chest")
				|| (ForgeRegistries.ITEMS.getKey((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY).getItem()).toString()).equals("mekanism:hazmat_gown")) {
			armor_chest = true;
		}
		if ((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY).getItem() == StevesWasteland3ModItems.INSULATION_ARMOR_HELMET.get()
				|| (ForgeRegistries.ITEMS.getKey((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY).getItem()).toString()).equals("ic2:armor_hazmat_helmet")
				|| (ForgeRegistries.ITEMS.getKey((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY).getItem()).toString()).equals("mekanism:hazmat_mask")) {
			armor_head = true;
		}
		if (armor_foot && armor_legs && armor_chest && armor_head) {
			able = false;
		}
		if (able) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(StevesWasteland3ModMobEffects.RAD_SICKNESS.get(), (int) StevesWasteland3ModVariables.MapVariables.get(world).rad_sickness_duration, 1));
		}
	}
}
