
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.steveswasteland3.init;

import net.sprvlln.steveswasteland3.entity.RadZombieEntity;
import net.sprvlln.steveswasteland3.entity.DayRadZombieEntity;
import net.sprvlln.steveswasteland3.StevesWasteland3Mod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class StevesWasteland3ModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, StevesWasteland3Mod.MODID);
	public static final RegistryObject<EntityType<RadZombieEntity>> RAD_ZOMBIE = register("rad_zombie",
			EntityType.Builder.<RadZombieEntity>of(RadZombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(RadZombieEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<DayRadZombieEntity>> DAY_RAD_ZOMBIE = register("day_rad_zombie",
			EntityType.Builder.<DayRadZombieEntity>of(DayRadZombieEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DayRadZombieEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			RadZombieEntity.init();
			DayRadZombieEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(RAD_ZOMBIE.get(), RadZombieEntity.createAttributes().build());
		event.put(DAY_RAD_ZOMBIE.get(), DayRadZombieEntity.createAttributes().build());
	}
}
