
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.steveswasteland3.init;

import net.sprvlln.steveswasteland3.client.renderer.RadZombieRenderer;
import net.sprvlln.steveswasteland3.client.renderer.DayRadZombieRenderer;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class StevesWasteland3ModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(StevesWasteland3ModEntities.RAD_ZOMBIE.get(), RadZombieRenderer::new);
		event.registerEntityRenderer(StevesWasteland3ModEntities.DAY_RAD_ZOMBIE.get(), DayRadZombieRenderer::new);
	}
}
