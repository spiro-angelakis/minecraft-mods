package net.sprvlln.steveswasteland3.procedures;

import net.sprvlln.steveswasteland3.init.StevesWasteland3ModMobEffects;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

public class RadPoisoningEffectExpiresProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(StevesWasteland3ModMobEffects.RAD_POISONING.get());
	}
}
