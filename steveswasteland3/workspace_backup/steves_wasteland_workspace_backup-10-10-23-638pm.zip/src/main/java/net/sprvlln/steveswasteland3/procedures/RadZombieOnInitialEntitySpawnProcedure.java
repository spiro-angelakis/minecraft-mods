package net.sprvlln.steveswasteland3.procedures;

import net.minecraft.world.entity.Entity;

public class RadZombieOnInitialEntitySpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("tick", 0);
	}
}
