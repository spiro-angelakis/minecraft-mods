package net.sprvlln.steveswasteland3.network;

import net.sprvlln.steveswasteland3.StevesWasteland3Mod;

import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.Capability;

import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.Direction;
import net.minecraft.client.Minecraft;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class StevesWasteland3ModVariables {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		StevesWasteland3Mod.addNetworkMessage(SavedDataSyncMessage.class, SavedDataSyncMessage::buffer, SavedDataSyncMessage::new, SavedDataSyncMessage::handler);
		StevesWasteland3Mod.addNetworkMessage(PlayerVariablesSyncMessage.class, PlayerVariablesSyncMessage::buffer, PlayerVariablesSyncMessage::new, PlayerVariablesSyncMessage::handler);
	}

	@SubscribeEvent
	public static void init(RegisterCapabilitiesEvent event) {
		event.register(PlayerVariables.class);
	}

	@Mod.EventBusSubscriber
	public static class EventBusVariableHandlers {
		@SubscribeEvent
		public static void onPlayerLoggedInSyncPlayerVariables(PlayerEvent.PlayerLoggedInEvent event) {
			if (!event.getEntity().level.isClientSide())
				((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables())).syncPlayerVariables(event.getEntity());
		}

		@SubscribeEvent
		public static void onPlayerRespawnedSyncPlayerVariables(PlayerEvent.PlayerRespawnEvent event) {
			if (!event.getEntity().level.isClientSide())
				((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables())).syncPlayerVariables(event.getEntity());
		}

		@SubscribeEvent
		public static void onPlayerChangedDimensionSyncPlayerVariables(PlayerEvent.PlayerChangedDimensionEvent event) {
			if (!event.getEntity().level.isClientSide())
				((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables())).syncPlayerVariables(event.getEntity());
		}

		@SubscribeEvent
		public static void clonePlayer(PlayerEvent.Clone event) {
			event.getOriginal().revive();
			PlayerVariables original = ((PlayerVariables) event.getOriginal().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()));
			PlayerVariables clone = ((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()));
			clone.sw_player_ticks = original.sw_player_ticks;
			if (!event.isWasDeath()) {
			}
		}

		@SubscribeEvent
		public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
			if (!event.getEntity().level.isClientSide()) {
				SavedData mapdata = MapVariables.get(event.getEntity().level);
				SavedData worlddata = WorldVariables.get(event.getEntity().level);
				if (mapdata != null)
					StevesWasteland3Mod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) event.getEntity()), new SavedDataSyncMessage(0, mapdata));
				if (worlddata != null)
					StevesWasteland3Mod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) event.getEntity()), new SavedDataSyncMessage(1, worlddata));
			}
		}

		@SubscribeEvent
		public static void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
			if (!event.getEntity().level.isClientSide()) {
				SavedData worlddata = WorldVariables.get(event.getEntity().level);
				if (worlddata != null)
					StevesWasteland3Mod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) event.getEntity()), new SavedDataSyncMessage(1, worlddata));
			}
		}
	}

	public static class WorldVariables extends SavedData {
		public static final String DATA_NAME = "steves_wasteland3_worldvars";

		public static WorldVariables load(CompoundTag tag) {
			WorldVariables data = new WorldVariables();
			data.read(tag);
			return data;
		}

		public void read(CompoundTag nbt) {
		}

		@Override
		public CompoundTag save(CompoundTag nbt) {
			return nbt;
		}

		public void syncData(LevelAccessor world) {
			this.setDirty();
			if (world instanceof Level level && !level.isClientSide())
				StevesWasteland3Mod.PACKET_HANDLER.send(PacketDistributor.DIMENSION.with(level::dimension), new SavedDataSyncMessage(1, this));
		}

		static WorldVariables clientSide = new WorldVariables();

		public static WorldVariables get(LevelAccessor world) {
			if (world instanceof ServerLevel level) {
				return level.getDataStorage().computeIfAbsent(e -> WorldVariables.load(e), WorldVariables::new, DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class MapVariables extends SavedData {
		public static final String DATA_NAME = "steves_wasteland3_mapvars";
		public double rad_sickness_duration = 0;
		public double rad_sickness_poison_chance = 0;
		public double rad_poisoning_duration = 0;
		public double rad_poisoning_initial_damage = 0;
		public double rad_poisoning_active_damage = 0;
		public double rad_poisoning_chance_to_damage = 0;
		public double rad_block_spread_chance = 0;
		public double rad_fluid_spread_chance = 0;
		public double dead_dirt_to_rad_chance = 0;
		public double dead_dirt_revival_chance = 0;
		public double chance_for_zombie_spawns_out_of = 0;
		public double chance_for_horde_spawns_out_of = 0;
		public double day_zombie_spawns_mod = 0;
		public double night_zombie_spawns_mod = 0;
		public double max_zombies_near_players = 0;
		public boolean zombie_events_only_in_wastes = false;
		public boolean zombie_events_only_on_earth = false;
		public double distance_check_for_hordes = 0;
		public double horde_min_heads = 0;
		public double horde_max_heads = 0;
		public double horde_size_area = 0;
		public double distance_check_for_zombies = 0;
		public double pack_min_heads = 0;
		public double pack_max_heads = 0;
		public double pack_size_area = 0;
		public double player_ticks_before_zombie_event_chance = 0;
		public double villager_zombie_to_zombie_ratio = 0;

		public static MapVariables load(CompoundTag tag) {
			MapVariables data = new MapVariables();
			data.read(tag);
			return data;
		}

		public void read(CompoundTag nbt) {
			rad_sickness_duration = nbt.getDouble("rad_sickness_duration");
			rad_sickness_poison_chance = nbt.getDouble("rad_sickness_poison_chance");
			rad_poisoning_duration = nbt.getDouble("rad_poisoning_duration");
			rad_poisoning_initial_damage = nbt.getDouble("rad_poisoning_initial_damage");
			rad_poisoning_active_damage = nbt.getDouble("rad_poisoning_active_damage");
			rad_poisoning_chance_to_damage = nbt.getDouble("rad_poisoning_chance_to_damage");
			rad_block_spread_chance = nbt.getDouble("rad_block_spread_chance");
			rad_fluid_spread_chance = nbt.getDouble("rad_fluid_spread_chance");
			dead_dirt_to_rad_chance = nbt.getDouble("dead_dirt_to_rad_chance");
			dead_dirt_revival_chance = nbt.getDouble("dead_dirt_revival_chance");
			chance_for_zombie_spawns_out_of = nbt.getDouble("chance_for_zombie_spawns_out_of");
			chance_for_horde_spawns_out_of = nbt.getDouble("chance_for_horde_spawns_out_of");
			day_zombie_spawns_mod = nbt.getDouble("day_zombie_spawns_mod");
			night_zombie_spawns_mod = nbt.getDouble("night_zombie_spawns_mod");
			max_zombies_near_players = nbt.getDouble("max_zombies_near_players");
			zombie_events_only_in_wastes = nbt.getBoolean("zombie_events_only_in_wastes");
			zombie_events_only_on_earth = nbt.getBoolean("zombie_events_only_on_earth");
			distance_check_for_hordes = nbt.getDouble("distance_check_for_hordes");
			horde_min_heads = nbt.getDouble("horde_min_heads");
			horde_max_heads = nbt.getDouble("horde_max_heads");
			horde_size_area = nbt.getDouble("horde_size_area");
			distance_check_for_zombies = nbt.getDouble("distance_check_for_zombies");
			pack_min_heads = nbt.getDouble("pack_min_heads");
			pack_max_heads = nbt.getDouble("pack_max_heads");
			pack_size_area = nbt.getDouble("pack_size_area");
			player_ticks_before_zombie_event_chance = nbt.getDouble("player_ticks_before_zombie_event_chance");
			villager_zombie_to_zombie_ratio = nbt.getDouble("villager_zombie_to_zombie_ratio");
		}

		@Override
		public CompoundTag save(CompoundTag nbt) {
			nbt.putDouble("rad_sickness_duration", rad_sickness_duration);
			nbt.putDouble("rad_sickness_poison_chance", rad_sickness_poison_chance);
			nbt.putDouble("rad_poisoning_duration", rad_poisoning_duration);
			nbt.putDouble("rad_poisoning_initial_damage", rad_poisoning_initial_damage);
			nbt.putDouble("rad_poisoning_active_damage", rad_poisoning_active_damage);
			nbt.putDouble("rad_poisoning_chance_to_damage", rad_poisoning_chance_to_damage);
			nbt.putDouble("rad_block_spread_chance", rad_block_spread_chance);
			nbt.putDouble("rad_fluid_spread_chance", rad_fluid_spread_chance);
			nbt.putDouble("dead_dirt_to_rad_chance", dead_dirt_to_rad_chance);
			nbt.putDouble("dead_dirt_revival_chance", dead_dirt_revival_chance);
			nbt.putDouble("chance_for_zombie_spawns_out_of", chance_for_zombie_spawns_out_of);
			nbt.putDouble("chance_for_horde_spawns_out_of", chance_for_horde_spawns_out_of);
			nbt.putDouble("day_zombie_spawns_mod", day_zombie_spawns_mod);
			nbt.putDouble("night_zombie_spawns_mod", night_zombie_spawns_mod);
			nbt.putDouble("max_zombies_near_players", max_zombies_near_players);
			nbt.putBoolean("zombie_events_only_in_wastes", zombie_events_only_in_wastes);
			nbt.putBoolean("zombie_events_only_on_earth", zombie_events_only_on_earth);
			nbt.putDouble("distance_check_for_hordes", distance_check_for_hordes);
			nbt.putDouble("horde_min_heads", horde_min_heads);
			nbt.putDouble("horde_max_heads", horde_max_heads);
			nbt.putDouble("horde_size_area", horde_size_area);
			nbt.putDouble("distance_check_for_zombies", distance_check_for_zombies);
			nbt.putDouble("pack_min_heads", pack_min_heads);
			nbt.putDouble("pack_max_heads", pack_max_heads);
			nbt.putDouble("pack_size_area", pack_size_area);
			nbt.putDouble("player_ticks_before_zombie_event_chance", player_ticks_before_zombie_event_chance);
			nbt.putDouble("villager_zombie_to_zombie_ratio", villager_zombie_to_zombie_ratio);
			return nbt;
		}

		public void syncData(LevelAccessor world) {
			this.setDirty();
			if (world instanceof Level && !world.isClientSide())
				StevesWasteland3Mod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new SavedDataSyncMessage(0, this));
		}

		static MapVariables clientSide = new MapVariables();

		public static MapVariables get(LevelAccessor world) {
			if (world instanceof ServerLevelAccessor serverLevelAcc) {
				return serverLevelAcc.getLevel().getServer().getLevel(Level.OVERWORLD).getDataStorage().computeIfAbsent(e -> MapVariables.load(e), MapVariables::new, DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class SavedDataSyncMessage {
		public int type;
		public SavedData data;

		public SavedDataSyncMessage(FriendlyByteBuf buffer) {
			this.type = buffer.readInt();
			this.data = this.type == 0 ? new MapVariables() : new WorldVariables();
			if (this.data instanceof MapVariables _mapvars)
				_mapvars.read(buffer.readNbt());
			else if (this.data instanceof WorldVariables _worldvars)
				_worldvars.read(buffer.readNbt());
		}

		public SavedDataSyncMessage(int type, SavedData data) {
			this.type = type;
			this.data = data;
		}

		public static void buffer(SavedDataSyncMessage message, FriendlyByteBuf buffer) {
			buffer.writeInt(message.type);
			buffer.writeNbt(message.data.save(new CompoundTag()));
		}

		public static void handler(SavedDataSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					if (message.type == 0)
						MapVariables.clientSide = (MapVariables) message.data;
					else
						WorldVariables.clientSide = (WorldVariables) message.data;
				}
			});
			context.setPacketHandled(true);
		}
	}

	public static final Capability<PlayerVariables> PLAYER_VARIABLES_CAPABILITY = CapabilityManager.get(new CapabilityToken<PlayerVariables>() {
	});

	@Mod.EventBusSubscriber
	private static class PlayerVariablesProvider implements ICapabilitySerializable<Tag> {
		@SubscribeEvent
		public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
			if (event.getObject() instanceof Player && !(event.getObject() instanceof FakePlayer))
				event.addCapability(new ResourceLocation("steves_wasteland3", "player_variables"), new PlayerVariablesProvider());
		}

		private final PlayerVariables playerVariables = new PlayerVariables();
		private final LazyOptional<PlayerVariables> instance = LazyOptional.of(() -> playerVariables);

		@Override
		public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
			return cap == PLAYER_VARIABLES_CAPABILITY ? instance.cast() : LazyOptional.empty();
		}

		@Override
		public Tag serializeNBT() {
			return playerVariables.writeNBT();
		}

		@Override
		public void deserializeNBT(Tag nbt) {
			playerVariables.readNBT(nbt);
		}
	}

	public static class PlayerVariables {
		public double sw_player_ticks = 0;

		public void syncPlayerVariables(Entity entity) {
			if (entity instanceof ServerPlayer serverPlayer)
				StevesWasteland3Mod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> serverPlayer), new PlayerVariablesSyncMessage(this));
		}

		public Tag writeNBT() {
			CompoundTag nbt = new CompoundTag();
			nbt.putDouble("sw_player_ticks", sw_player_ticks);
			return nbt;
		}

		public void readNBT(Tag Tag) {
			CompoundTag nbt = (CompoundTag) Tag;
			sw_player_ticks = nbt.getDouble("sw_player_ticks");
		}
	}

	public static class PlayerVariablesSyncMessage {
		public PlayerVariables data;

		public PlayerVariablesSyncMessage(FriendlyByteBuf buffer) {
			this.data = new PlayerVariables();
			this.data.readNBT(buffer.readNbt());
		}

		public PlayerVariablesSyncMessage(PlayerVariables data) {
			this.data = data;
		}

		public static void buffer(PlayerVariablesSyncMessage message, FriendlyByteBuf buffer) {
			buffer.writeNbt((CompoundTag) message.data.writeNBT());
		}

		public static void handler(PlayerVariablesSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					PlayerVariables variables = ((PlayerVariables) Minecraft.getInstance().player.getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()));
					variables.sw_player_ticks = message.data.sw_player_ticks;
				}
			});
			context.setPacketHandled(true);
		}
	}
}
