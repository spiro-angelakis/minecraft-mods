
package net.sprvlln.steveswasteland3.potion;

import net.sprvlln.steveswasteland3.procedures.RadSicknessOnEffectActiveTickProcedure;
import net.sprvlln.steveswasteland3.procedures.RadSicknessEffectExpiresProcedure;

import net.minecraftforge.client.extensions.common.IClientMobEffectExtensions;

import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class RadSicknessMobEffect extends MobEffect {
	public RadSicknessMobEffect() {
		super(MobEffectCategory.HARMFUL, -6750055);
	}

	@Override
	public String getDescriptionId() {
		return "effect.steves_wasteland3.rad_sickness";
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		RadSicknessOnEffectActiveTickProcedure.execute(entity.level, entity);
	}

	@Override
	public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
		super.removeAttributeModifiers(entity, attributeMap, amplifier);
		RadSicknessEffectExpiresProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public void initializeClient(java.util.function.Consumer<IClientMobEffectExtensions> consumer) {
		consumer.accept(new IClientMobEffectExtensions() {
			@Override
			public boolean isVisibleInGui(MobEffectInstance effect) {
				return false;
			}
		});
	}
}
