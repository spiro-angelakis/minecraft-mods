package net.sprvlln.steveswasteland3.procedures;

import net.sprvlln.steveswasteland3.network.StevesWasteland3ModVariables;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class RadInfectWaterUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		boolean nearWater = false;
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_fluid_spread_chance) {
			if ((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y - 1, z))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x + 1, y, z))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x - 1, y, z))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z + 1))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z - 1))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.MUD.defaultBlockState(), 3);
			}
			if ((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y - 1, z))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x + 1, y, z))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x - 1, y, z))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z + 1))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z - 1))).getBlock() == Blocks.WATER) {
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.MUD.defaultBlockState(), 3);
			}
		}
	}
}
