package net.sprvlln.steveswasteland3.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.BlockPos;

public class ReviveDeadDirtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double reviveChance = 0;
		boolean willRevive = false;
		willRevive = false;
		reviveChance = Mth.nextInt(RandomSource.create(), 0, 20);
		if (reviveChance >= 19) {
			willRevive = true;
		}
		if (willRevive == true) {
			world.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 3);
			world.setBlock(new BlockPos(x, y, z), Blocks.DIRT.defaultBlockState(), 3);
		}
	}
}
