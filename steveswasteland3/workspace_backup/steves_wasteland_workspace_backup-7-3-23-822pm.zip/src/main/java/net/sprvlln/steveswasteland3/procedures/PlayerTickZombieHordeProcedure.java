package net.sprvlln.steveswasteland3.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class PlayerTickZombieHordeProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level, event.player.getX(), event.player.getY(), event.player.getZ(), event.player);
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double hordeCount = 0;
		double zombieType = 0;
		double spawnX = 0;
		double spawnZ = 0;
		double hordeX = 0;
		double hordeZ = 0;
		double timeMod = 0;
		if ((entity.level.dimension()) == Level.OVERWORLD) {
			timeMod = 1;
			if (!(world instanceof Level _lvl3 && _lvl3.isDay())) {
				timeMod = 0.5;
			}
			if (world.getBiome(new BlockPos(x, y, z)).is(TagKey.create(Registry.BIOME_REGISTRY, new ResourceLocation("steves_wasteland3:is_wasteland")))) {
				if (Mth.nextInt(RandomSource.create(), 1, (int) (10000 * timeMod)) == 1) {
					ZombieHordeEventProcedure.execute(world, x, z);
				} else {
					if (Mth.nextInt(RandomSource.create(), 1, (int) (600 * timeMod)) == 1) {
						SpawnMoreZedsNearPlayerProcedure.execute(world, x, z);
					}
				}
			}
		}
	}
}
