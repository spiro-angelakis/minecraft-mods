
package net.sprvlln.steveswasteland3.world.biome;

import net.sprvlln.steveswasteland3.init.StevesWasteland3ModEntities;

import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import net.minecraft.world.level.biome.BiomeGenerationSettings;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.data.worldgen.BiomeDefaultFeatures;

import java.util.List;

public class RadLandsBiomeBiome {
	public static final List<Climate.ParameterPoint> PARAMETER_POINTS = List.of(
			new Climate.ParameterPoint(Climate.Parameter.span(-0.9f, 0.9f), Climate.Parameter.span(-0.8f, 0.8f), Climate.Parameter.span(-0.9f, 0.9f), Climate.Parameter.span(0.2f, 0.5f), Climate.Parameter.point(0.0f),
					Climate.Parameter.span(-1.5f, 1.5f), 0),
			new Climate.ParameterPoint(Climate.Parameter.span(-0.9f, 0.9f), Climate.Parameter.span(-0.8f, 0.8f), Climate.Parameter.span(-0.9f, 0.9f), Climate.Parameter.span(0.2f, 0.5f), Climate.Parameter.point(1.0f),
					Climate.Parameter.span(-1.5f, 1.5f), 0));

	public static Biome createBiome() {
		BiomeSpecialEffects effects = new BiomeSpecialEffects.Builder().fogColor(-3368279).waterColor(-4089140).waterFogColor(-4744500).skyColor(-3368279).foliageColorOverride(-3368248).grassColorOverride(-3368261).build();
		BiomeGenerationSettings.Builder biomeGenerationSettings = new BiomeGenerationSettings.Builder();
		BiomeDefaultFeatures.addDefaultCarversAndLakes(biomeGenerationSettings);
		BiomeDefaultFeatures.addDripstone(biomeGenerationSettings);
		BiomeDefaultFeatures.addDefaultOres(biomeGenerationSettings);
		BiomeDefaultFeatures.addExtraGold(biomeGenerationSettings);
		BiomeDefaultFeatures.addExtraEmeralds(biomeGenerationSettings);
		BiomeDefaultFeatures.addDefaultMonsterRoom(biomeGenerationSettings);
		MobSpawnSettings.Builder mobSpawnInfo = new MobSpawnSettings.Builder();
		mobSpawnInfo.addSpawn(MobCategory.MONSTER, new MobSpawnSettings.SpawnerData(StevesWasteland3ModEntities.RAD_ZOMBIE.get(), 40, 1, 8));
		mobSpawnInfo.addSpawn(MobCategory.CREATURE, new MobSpawnSettings.SpawnerData(StevesWasteland3ModEntities.DAY_RAD_ZOMBIE.get(), 80, 1, 8));
		return new Biome.BiomeBuilder().precipitation(Biome.Precipitation.RAIN).temperature(1.25f).downfall(0.5f).specialEffects(effects).mobSpawnSettings(mobSpawnInfo.build()).generationSettings(biomeGenerationSettings.build()).build();
	}
}
