package net.sprvlln.steveswasteland3.procedures;

import net.sprvlln.steveswasteland3.init.StevesWasteland3ModMobEffects;
import net.sprvlln.steveswasteland3.init.StevesWasteland3ModItems;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class RadDirtBlockUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		{
			final Vec3 _center = new Vec3(x, (y + 1), z);
			List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(1 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
			for (Entity entityiterator : _entfound) {
				if (!(entityiterator.getType().is(TagKey.create(Registry.ENTITY_TYPE_REGISTRY, new ResourceLocation("steves_wasteland3:rad_proof"))) == true)) {
					if (!((entityiterator instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY).getItem() == StevesWasteland3ModItems.INSULATION_ARMOR_BOOTS.get()
							&& (entityiterator instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY).getItem() == StevesWasteland3ModItems.INSULATION_ARMOR_LEGGINGS.get()
							&& (entityiterator instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY).getItem() == StevesWasteland3ModItems.INSULATION_ARMOR_CHESTPLATE.get()
							&& (entityiterator instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY).getItem() == StevesWasteland3ModItems.INSULATION_ARMOR_HELMET.get())) {
						if (entityiterator instanceof LivingEntity _entity && !_entity.level.isClientSide())
							_entity.addEffect(new MobEffectInstance(StevesWasteland3ModMobEffects.RAD_SICKNESS.get(), 120, 1));
					}
				}
			}
		}
		RadDirtSpreadUpdateTickProcedure.execute(world, x, y, z);
		RadInfectWaterUpdateTickProcedure.execute(world, x, y, z);
	}
}
