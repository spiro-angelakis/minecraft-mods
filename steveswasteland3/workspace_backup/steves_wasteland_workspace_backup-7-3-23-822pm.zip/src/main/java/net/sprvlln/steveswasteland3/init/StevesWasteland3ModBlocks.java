
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.steveswasteland3.init;

import net.sprvlln.steveswasteland3.block.SmallDyingBushBlock;
import net.sprvlln.steveswasteland3.block.RadWaterBlock;
import net.sprvlln.steveswasteland3.block.RadDirtBlockBlock;
import net.sprvlln.steveswasteland3.block.LargeDyingBushBlock;
import net.sprvlln.steveswasteland3.block.DeadWoodLogBlockBlock;
import net.sprvlln.steveswasteland3.block.DeadDirtBlockBlock;
import net.sprvlln.steveswasteland3.StevesWasteland3Mod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

public class StevesWasteland3ModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, StevesWasteland3Mod.MODID);
	public static final RegistryObject<Block> DEAD_DIRT_BLOCK = REGISTRY.register("dead_dirt_block", () -> new DeadDirtBlockBlock());
	public static final RegistryObject<Block> RAD_DIRT_BLOCK = REGISTRY.register("rad_dirt_block", () -> new RadDirtBlockBlock());
	public static final RegistryObject<Block> RAD_WATER = REGISTRY.register("rad_water", () -> new RadWaterBlock());
	public static final RegistryObject<Block> DEAD_WOOD_LOG_BLOCK = REGISTRY.register("dead_wood_log_block", () -> new DeadWoodLogBlockBlock());
	public static final RegistryObject<Block> SMALL_DYING_BUSH = REGISTRY.register("small_dying_bush", () -> new SmallDyingBushBlock());
	public static final RegistryObject<Block> LARGE_DYING_BUSH = REGISTRY.register("large_dying_bush", () -> new LargeDyingBushBlock());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			SmallDyingBushBlock.blockColorLoad(event);
			LargeDyingBushBlock.blockColorLoad(event);
		}
	}
}
