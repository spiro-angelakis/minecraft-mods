package net.sprvlln.steveswasteland3.procedures;

import net.minecraft.world.level.LevelAccessor;

public class RadWaterUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		RadInfectWaterUpdateTickProcedure.execute(world, x, y, z);
		RadDirtSpreadUpdateTickProcedure.execute(world, x, y, z);
	}
}
