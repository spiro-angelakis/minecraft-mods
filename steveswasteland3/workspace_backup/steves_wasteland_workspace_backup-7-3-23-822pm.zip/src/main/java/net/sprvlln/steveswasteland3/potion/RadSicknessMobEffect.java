
package net.sprvlln.steveswasteland3.potion;

import net.sprvlln.steveswasteland3.procedures.RadSicknessOnEffectActiveTickProcedure;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class RadSicknessMobEffect extends MobEffect {
	public RadSicknessMobEffect() {
		super(MobEffectCategory.HARMFUL, -6750055);
	}

	@Override
	public String getDescriptionId() {
		return "effect.steves_wasteland3.rad_sickness";
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		RadSicknessOnEffectActiveTickProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
