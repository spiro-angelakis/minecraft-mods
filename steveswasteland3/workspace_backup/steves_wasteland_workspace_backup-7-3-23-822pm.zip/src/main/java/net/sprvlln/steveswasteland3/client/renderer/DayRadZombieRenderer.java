
package net.sprvlln.steveswasteland3.client.renderer;

import net.sprvlln.steveswasteland3.entity.DayRadZombieEntity;
import net.sprvlln.steveswasteland3.client.model.Modelrad_zombie;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

public class DayRadZombieRenderer extends MobRenderer<DayRadZombieEntity, Modelrad_zombie<DayRadZombieEntity>> {
	public DayRadZombieRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelrad_zombie(context.bakeLayer(Modelrad_zombie.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(DayRadZombieEntity entity) {
		return new ResourceLocation("steves_wasteland3:textures/entities/day_rad_zombie_texture.png");
	}
}
