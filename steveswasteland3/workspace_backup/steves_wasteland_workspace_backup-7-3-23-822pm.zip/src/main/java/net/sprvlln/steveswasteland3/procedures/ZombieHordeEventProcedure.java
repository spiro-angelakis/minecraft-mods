package net.sprvlln.steveswasteland3.procedures;

import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.monster.ZombieVillager;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;

public class ZombieHordeEventProcedure {
	public static void execute(LevelAccessor world, double x, double z) {
		double hordeCount = 0;
		double zombieType = 0;
		double spawnX = 0;
		double spawnZ = 0;
		double hordeX = 0;
		double hordeZ = 0;
		double xOffset = 0;
		double zOffset = 0;
		hordeCount = Mth.nextInt(RandomSource.create(), 32, 64);
		xOffset = Mth.nextInt(RandomSource.create(), 48, 96);
		if (Mth.nextInt(RandomSource.create(), 1, 2) == 1) {
			xOffset = -xOffset;
		}
		zOffset = Mth.nextInt(RandomSource.create(), 48, 96);
		if (Mth.nextInt(RandomSource.create(), 1, 2) == 1) {
			zOffset = -zOffset;
		}
		hordeX = x + Mth.nextInt(RandomSource.create(), -128, 128);
		hordeZ = z + Mth.nextInt(RandomSource.create(), -128, 128);
		for (int index0 = 0; index0 < (int) hordeCount; index0++) {
			spawnX = hordeX + Mth.nextInt(RandomSource.create(), -8, 8);
			spawnZ = hordeZ + Mth.nextInt(RandomSource.create(), -8, 8);
			zombieType = Mth.nextInt(RandomSource.create(), 0, 1);
			if (zombieType == 0) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new Zombie(EntityType.ZOMBIE, _level);
					entityToSpawn.moveTo(spawnX, (world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) spawnX, (int) spawnZ)), spawnZ, 0, 0);
					entityToSpawn.setYBodyRot(0);
					entityToSpawn.setYHeadRot(0);
					entityToSpawn.setDeltaMovement(0, 0, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					world.addFreshEntity(entityToSpawn);
				}
			} else if (zombieType == 1) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new ZombieVillager(EntityType.ZOMBIE_VILLAGER, _level);
					entityToSpawn.moveTo(spawnX, (world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) spawnX, (int) spawnZ)), spawnZ, 0, 0);
					entityToSpawn.setYBodyRot(0);
					entityToSpawn.setYHeadRot(0);
					entityToSpawn.setDeltaMovement(0, 0, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					world.addFreshEntity(entityToSpawn);
				}
			}
		}
	}
}
