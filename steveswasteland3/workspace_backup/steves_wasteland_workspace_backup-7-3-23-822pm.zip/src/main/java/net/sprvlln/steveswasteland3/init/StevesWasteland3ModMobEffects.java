
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.steveswasteland3.init;

import net.sprvlln.steveswasteland3.potion.RadSicknessMobEffect;
import net.sprvlln.steveswasteland3.StevesWasteland3Mod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

public class StevesWasteland3ModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, StevesWasteland3Mod.MODID);
	public static final RegistryObject<MobEffect> RAD_SICKNESS = REGISTRY.register("rad_sickness", () -> new RadSicknessMobEffect());
}
