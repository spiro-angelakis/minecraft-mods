package net.sprvlln.steveswasteland3.procedures;

import net.sprvlln.steveswasteland3.network.StevesWasteland3ModVariables;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;

public class RadPoisoningEffectProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_poisoning_chance_to_damage) {
			if (entity instanceof LivingEntity _entity)
				_entity.hurt(new DamageSource("Radiation Poisioning").bypassArmor(), (float) StevesWasteland3ModVariables.MapVariables.get(world).rad_poisoning_active_damage);
		}
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_poisoning_chance_to_damage) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.POISON, 40, 1));
		}
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_poisoning_chance_to_damage) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
		}
	}
}
