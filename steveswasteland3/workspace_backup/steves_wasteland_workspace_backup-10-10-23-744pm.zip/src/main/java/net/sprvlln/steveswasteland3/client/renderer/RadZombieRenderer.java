
package net.sprvlln.steveswasteland3.client.renderer;

import net.sprvlln.steveswasteland3.entity.RadZombieEntity;
import net.sprvlln.steveswasteland3.client.model.Modelrad_zombie;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

public class RadZombieRenderer extends MobRenderer<RadZombieEntity, Modelrad_zombie<RadZombieEntity>> {
	public RadZombieRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelrad_zombie(context.bakeLayer(Modelrad_zombie.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(RadZombieEntity entity) {
		return new ResourceLocation("steves_wasteland3:textures/entities/rad_zombie_texture.png");
	}
}
