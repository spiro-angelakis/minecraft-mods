
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.steveswasteland3.init;

import net.sprvlln.steveswasteland3.item.RadWaterItem;
import net.sprvlln.steveswasteland3.item.MonsterJerkyItem;
import net.sprvlln.steveswasteland3.item.InsulationFabricItem;
import net.sprvlln.steveswasteland3.item.InsulationArmorItem;
import net.sprvlln.steveswasteland3.item.HazmatBreatherItem;
import net.sprvlln.steveswasteland3.item.DeadWoodPlankItem;
import net.sprvlln.steveswasteland3.item.DeadLeafItem;
import net.sprvlln.steveswasteland3.item.AtomicItemItem;
import net.sprvlln.steveswasteland3.StevesWasteland3Mod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

public class StevesWasteland3ModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, StevesWasteland3Mod.MODID);
	public static final RegistryObject<Item> DEAD_DIRT_BLOCK = block(StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK, StevesWasteland3ModTabs.TAB_STEVES_WASTELAND_CREATIVE_TAB);
	public static final RegistryObject<Item> ATOMIC_ITEM = REGISTRY.register("atomic_item", () -> new AtomicItemItem());
	public static final RegistryObject<Item> RAD_DIRT_BLOCK = block(StevesWasteland3ModBlocks.RAD_DIRT_BLOCK, StevesWasteland3ModTabs.TAB_STEVES_WASTELAND_CREATIVE_TAB);
	public static final RegistryObject<Item> RAD_WATER_BUCKET = REGISTRY.register("rad_water_bucket", () -> new RadWaterItem());
	public static final RegistryObject<Item> DEAD_WOOD_LOG_BLOCK = block(StevesWasteland3ModBlocks.DEAD_WOOD_LOG_BLOCK, StevesWasteland3ModTabs.TAB_STEVES_WASTELAND_CREATIVE_TAB);
	public static final RegistryObject<Item> DEAD_WOOD_PLANK = REGISTRY.register("dead_wood_plank", () -> new DeadWoodPlankItem());
	public static final RegistryObject<Item> DEAD_LEAF = REGISTRY.register("dead_leaf", () -> new DeadLeafItem());
	public static final RegistryObject<Item> SMALL_DYING_BUSH = block(StevesWasteland3ModBlocks.SMALL_DYING_BUSH, StevesWasteland3ModTabs.TAB_STEVES_WASTELAND_CREATIVE_TAB);
	public static final RegistryObject<Item> LARGE_DYING_BUSH = block(StevesWasteland3ModBlocks.LARGE_DYING_BUSH, StevesWasteland3ModTabs.TAB_STEVES_WASTELAND_CREATIVE_TAB);
	public static final RegistryObject<Item> INSULATION_FABRIC = REGISTRY.register("insulation_fabric", () -> new InsulationFabricItem());
	public static final RegistryObject<Item> INSULATION_ARMOR_HELMET = REGISTRY.register("insulation_armor_helmet", () -> new InsulationArmorItem.Helmet());
	public static final RegistryObject<Item> INSULATION_ARMOR_CHESTPLATE = REGISTRY.register("insulation_armor_chestplate", () -> new InsulationArmorItem.Chestplate());
	public static final RegistryObject<Item> INSULATION_ARMOR_LEGGINGS = REGISTRY.register("insulation_armor_leggings", () -> new InsulationArmorItem.Leggings());
	public static final RegistryObject<Item> INSULATION_ARMOR_BOOTS = REGISTRY.register("insulation_armor_boots", () -> new InsulationArmorItem.Boots());
	public static final RegistryObject<Item> HAZMAT_BREATHER = REGISTRY.register("hazmat_breather", () -> new HazmatBreatherItem());
	public static final RegistryObject<Item> RAD_ZOMBIE_SPAWN_EGG = REGISTRY.register("rad_zombie_spawn_egg",
			() -> new ForgeSpawnEggItem(StevesWasteland3ModEntities.RAD_ZOMBIE, -13408768, -10066432, new Item.Properties().tab(StevesWasteland3ModTabs.TAB_STEVES_WASTELAND_CREATIVE_TAB)));
	public static final RegistryObject<Item> DAY_RAD_ZOMBIE_SPAWN_EGG = REGISTRY.register("day_rad_zombie_spawn_egg",
			() -> new ForgeSpawnEggItem(StevesWasteland3ModEntities.DAY_RAD_ZOMBIE, -13408768, -10066432, new Item.Properties().tab(StevesWasteland3ModTabs.TAB_STEVES_WASTELAND_CREATIVE_TAB)));
	public static final RegistryObject<Item> MONSTER_JERKY = REGISTRY.register("monster_jerky", () -> new MonsterJerkyItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
