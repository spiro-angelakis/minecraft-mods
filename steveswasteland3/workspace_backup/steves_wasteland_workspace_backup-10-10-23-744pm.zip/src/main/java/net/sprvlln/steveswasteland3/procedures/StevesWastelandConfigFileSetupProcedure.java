package net.sprvlln.steveswasteland3.procedures;

import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.FileWriter;
import java.io.File;

import com.google.gson.GsonBuilder;
import com.google.gson.Gson;

public class StevesWastelandConfigFileSetupProcedure {
	public static void execute() {
		File steves_wasteland_config = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		steves_wasteland_config = new File((FMLPaths.GAMEDIR.get().toString() + "/config/sprvlln/"), File.separator + "steves_wasteland.json");
		if (!steves_wasteland_config.exists()) {
			try {
				steves_wasteland_config.getParentFile().mkdirs();
				steves_wasteland_config.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			main_json_object.addProperty("rad_sickness_duration_ticks", 480);
			main_json_object.addProperty("rad_sickness_chance_to_poison", 0.01);
			main_json_object.addProperty("rad_poisoning_duration_ticks", 20);
			main_json_object.addProperty("rad_poisoning_initial_damage", 1);
			main_json_object.addProperty("rad_poisoning_active_damage", 0.5);
			main_json_object.addProperty("rad_poisoning_chance_to_damage", 0.002);
			main_json_object.addProperty("rad_block_spread_chance", 0.1);
			main_json_object.addProperty("rad_fluid_spread_chance", 0.1);
			main_json_object.addProperty("dead_dirt_to_rad_chance", 0.001);
			main_json_object.addProperty("dead_dirt_revival_chance", 0.9);
			main_json_object.addProperty("zombie_events_only_in_wastes", false);
			main_json_object.addProperty("zombie_events_only_on_earth", true);
			main_json_object.addProperty("chance_for_zombie_spawns_out_of", 20);
			main_json_object.addProperty("chance_for_horde_spawns_out_of", 200);
			main_json_object.addProperty("day_zombie_spawns_mod", 1);
			main_json_object.addProperty("night_zombie_spawns_mod", 0.5);
			main_json_object.addProperty("max_zombies_near_players", 300);
			main_json_object.addProperty("distance_check_for_hordes", 128);
			main_json_object.addProperty("horde_min_heads", 32);
			main_json_object.addProperty("horde_max_heads", 64);
			main_json_object.addProperty("horde_size_area", 128);
			main_json_object.addProperty("distance_check_for_zombies", 64);
			main_json_object.addProperty("pack_min_heads", 1);
			main_json_object.addProperty("pack_max_heads", 9);
			main_json_object.addProperty("pack_size_area", 9);
			main_json_object.addProperty("villager_zombie_to_zombie_ratio", 0.25);
			main_json_object.addProperty("player_ticks_before_zombie_event_chance", 20);
			main_json_object.addProperty("spawn_zombie_min_distance", 120);
			main_json_object.addProperty("spawn_zombie_max_distance", 240);
			{
				Gson mainGSONBuilderVariable = new GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(steves_wasteland_config);
					fileWriter.write(mainGSONBuilderVariable.toJson(main_json_object));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		}
	}
}
