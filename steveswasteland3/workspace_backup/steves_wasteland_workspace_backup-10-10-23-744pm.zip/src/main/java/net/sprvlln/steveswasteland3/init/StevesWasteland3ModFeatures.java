
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.steveswasteland3.init;

import net.sprvlln.steveswasteland3.world.features.plants.SmallDyingBushFeature;
import net.sprvlln.steveswasteland3.world.features.plants.LargeDyingBushFeature;
import net.sprvlln.steveswasteland3.world.features.StoneRuins5Feature;
import net.sprvlln.steveswasteland3.world.features.StoneRuins4Feature;
import net.sprvlln.steveswasteland3.world.features.StoneRuins3Feature;
import net.sprvlln.steveswasteland3.world.features.StoneRuins2Feature;
import net.sprvlln.steveswasteland3.world.features.StoneRuins1Feature;
import net.sprvlln.steveswasteland3.world.features.GlayGenInWaterFeature;
import net.sprvlln.steveswasteland3.world.features.DeadTreeWoodsGenFeature;
import net.sprvlln.steveswasteland3.world.features.DeadTreeGenFeature;
import net.sprvlln.steveswasteland3.world.features.DeadOakTreeWoodsGenFeature;
import net.sprvlln.steveswasteland3.world.features.DeadOakTreeGenFeature;
import net.sprvlln.steveswasteland3.world.features.ClayGenerationUndergroundFeatureFeature;
import net.sprvlln.steveswasteland3.world.features.ClayGenerationUndergroundFeature2Feature;
import net.sprvlln.steveswasteland3.world.features.ClayGenInWater2Feature;
import net.sprvlln.steveswasteland3.StevesWasteland3Mod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

@Mod.EventBusSubscriber
public class StevesWasteland3ModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, StevesWasteland3Mod.MODID);
	public static final RegistryObject<Feature<?>> SMALL_DYING_BUSH = REGISTRY.register("small_dying_bush", SmallDyingBushFeature::feature);
	public static final RegistryObject<Feature<?>> LARGE_DYING_BUSH = REGISTRY.register("large_dying_bush", LargeDyingBushFeature::feature);
	public static final RegistryObject<Feature<?>> CLAY_GENERATION_UNDERGROUND_FEATURE = REGISTRY.register("clay_generation_underground_feature", ClayGenerationUndergroundFeatureFeature::new);
	public static final RegistryObject<Feature<?>> DEAD_OAK_TREE_GEN = REGISTRY.register("dead_oak_tree_gen", DeadOakTreeGenFeature::new);
	public static final RegistryObject<Feature<?>> GLAY_GEN_IN_WATER = REGISTRY.register("glay_gen_in_water", GlayGenInWaterFeature::new);
	public static final RegistryObject<Feature<?>> STONE_RUINS_1 = REGISTRY.register("stone_ruins_1", StoneRuins1Feature::feature);
	public static final RegistryObject<Feature<?>> STONE_RUINS_2 = REGISTRY.register("stone_ruins_2", StoneRuins2Feature::feature);
	public static final RegistryObject<Feature<?>> STONE_RUINS_3 = REGISTRY.register("stone_ruins_3", StoneRuins3Feature::feature);
	public static final RegistryObject<Feature<?>> STONE_RUINS_4 = REGISTRY.register("stone_ruins_4", StoneRuins4Feature::feature);
	public static final RegistryObject<Feature<?>> STONE_RUINS_5 = REGISTRY.register("stone_ruins_5", StoneRuins5Feature::feature);
	public static final RegistryObject<Feature<?>> CLAY_GEN_IN_WATER_2 = REGISTRY.register("clay_gen_in_water_2", ClayGenInWater2Feature::new);
	public static final RegistryObject<Feature<?>> CLAY_GENERATION_UNDERGROUND_FEATURE_2 = REGISTRY.register("clay_generation_underground_feature_2", ClayGenerationUndergroundFeature2Feature::new);
	public static final RegistryObject<Feature<?>> DEAD_TREE_GEN = REGISTRY.register("dead_tree_gen", DeadTreeGenFeature::new);
	public static final RegistryObject<Feature<?>> DEAD_TREE_WOODS_GEN = REGISTRY.register("dead_tree_woods_gen", DeadTreeWoodsGenFeature::new);
	public static final RegistryObject<Feature<?>> DEAD_OAK_TREE_WOODS_GEN = REGISTRY.register("dead_oak_tree_woods_gen", DeadOakTreeWoodsGenFeature::new);
}
