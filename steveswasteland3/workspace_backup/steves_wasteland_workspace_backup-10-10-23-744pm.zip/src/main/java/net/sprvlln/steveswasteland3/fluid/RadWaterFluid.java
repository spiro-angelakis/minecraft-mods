
package net.sprvlln.steveswasteland3.fluid;

import net.sprvlln.steveswasteland3.init.StevesWasteland3ModItems;
import net.sprvlln.steveswasteland3.init.StevesWasteland3ModFluids;
import net.sprvlln.steveswasteland3.init.StevesWasteland3ModFluidTypes;
import net.sprvlln.steveswasteland3.init.StevesWasteland3ModBlocks;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

public abstract class RadWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> StevesWasteland3ModFluidTypes.RAD_WATER_TYPE.get(), () -> StevesWasteland3ModFluids.RAD_WATER.get(),
			() -> StevesWasteland3ModFluids.FLOWING_RAD_WATER.get()).explosionResistance(100f).bucket(() -> StevesWasteland3ModItems.RAD_WATER_BUCKET.get()).block(() -> (LiquidBlock) StevesWasteland3ModBlocks.RAD_WATER.get());

	private RadWaterFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.FALLING_WATER;
	}

	public static class Source extends RadWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends RadWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
