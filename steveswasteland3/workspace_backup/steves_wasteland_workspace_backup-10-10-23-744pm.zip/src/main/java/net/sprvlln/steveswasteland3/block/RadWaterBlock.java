
package net.sprvlln.steveswasteland3.block;

import net.sprvlln.steveswasteland3.procedures.RadWaterMobplayerCollidesBlockProcedure;
import net.sprvlln.steveswasteland3.init.StevesWasteland3ModFluids;

import net.minecraft.world.level.material.MaterialColor;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

public class RadWaterBlock extends LiquidBlock {
	public RadWaterBlock() {
		super(() -> StevesWasteland3ModFluids.RAD_WATER.get(), BlockBehaviour.Properties.of(Material.WATER, MaterialColor.COLOR_YELLOW).strength(100f).noCollission().noLootTable());
	}

	@Override
	public void entityInside(BlockState blockstate, Level world, BlockPos pos, Entity entity) {
		super.entityInside(blockstate, world, pos, entity);
		RadWaterMobplayerCollidesBlockProcedure.execute(world, entity);
	}
}
