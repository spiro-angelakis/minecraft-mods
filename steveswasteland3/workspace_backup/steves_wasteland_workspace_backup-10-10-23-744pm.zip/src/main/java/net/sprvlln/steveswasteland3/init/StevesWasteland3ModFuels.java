
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.steveswasteland3.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;

import net.minecraft.world.item.ItemStack;

@Mod.EventBusSubscriber
public class StevesWasteland3ModFuels {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		ItemStack itemstack = event.getItemStack();
		if (itemstack.getItem() == StevesWasteland3ModBlocks.DEAD_WOOD_LOG_BLOCK.get().asItem())
			event.setBurnTime(75);
		else if (itemstack.getItem() == StevesWasteland3ModItems.DEAD_WOOD_PLANK.get())
			event.setBurnTime(150);
		else if (itemstack.getItem() == StevesWasteland3ModItems.DEAD_LEAF.get())
			event.setBurnTime(37);
	}
}
