package net.sprvlln.steveswasteland3.procedures;

import net.sprvlln.steveswasteland3.network.StevesWasteland3ModVariables;
import net.sprvlln.steveswasteland3.init.StevesWasteland3ModBlocks;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class RadDirtSpreadUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		boolean nearWater = false;
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_block_spread_chance) {
			if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_block_spread_chance) {
				if ((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get()) {
					world.setBlock(new BlockPos(x, y + 1, z), Blocks.AIR.defaultBlockState(), 3);
					world.setBlock(new BlockPos(x, y + 1, z), StevesWasteland3ModBlocks.RAD_DIRT_BLOCK.get().defaultBlockState(), 3);
				} else if ((world.getBlockState(new BlockPos(x, y - 1, z))).getBlock() == StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get()) {
					world.setBlock(new BlockPos(x, y - 1, z), Blocks.AIR.defaultBlockState(), 3);
					world.setBlock(new BlockPos(x, y - 1, z), StevesWasteland3ModBlocks.RAD_DIRT_BLOCK.get().defaultBlockState(), 3);
				} else if ((world.getBlockState(new BlockPos(x + 1, y, z))).getBlock() == StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get()) {
					world.setBlock(new BlockPos(x + 1, y, z), Blocks.AIR.defaultBlockState(), 3);
					world.setBlock(new BlockPos(x + 1, y, z), StevesWasteland3ModBlocks.RAD_DIRT_BLOCK.get().defaultBlockState(), 3);
				} else if ((world.getBlockState(new BlockPos(x - 1, y, z))).getBlock() == StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get()) {
					world.setBlock(new BlockPos(x - 1, y, z), Blocks.AIR.defaultBlockState(), 3);
					world.setBlock(new BlockPos(x - 1, y, z), StevesWasteland3ModBlocks.RAD_DIRT_BLOCK.get().defaultBlockState(), 3);
				} else if ((world.getBlockState(new BlockPos(x, y, z + 1))).getBlock() == StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get()) {
					world.setBlock(new BlockPos(x, y, z + 1), Blocks.AIR.defaultBlockState(), 3);
					world.setBlock(new BlockPos(x, y, z + 1), StevesWasteland3ModBlocks.RAD_DIRT_BLOCK.get().defaultBlockState(), 3);
				} else if ((world.getBlockState(new BlockPos(x, y, z - 1))).getBlock() == StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get()) {
					world.setBlock(new BlockPos(x, y, z - 1), Blocks.AIR.defaultBlockState(), 3);
					world.setBlock(new BlockPos(x, y, z - 1), StevesWasteland3ModBlocks.RAD_DIRT_BLOCK.get().defaultBlockState(), 3);
				}
			}
		}
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_block_spread_chance) {
			if ((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == Blocks.DIRT) {
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y + 1, z), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y - 1, z))).getBlock() == Blocks.DIRT) {
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y - 1, z), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x + 1, y, z))).getBlock() == Blocks.DIRT) {
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x + 1, y, z), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x - 1, y, z))).getBlock() == Blocks.DIRT) {
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x - 1, y, z), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z + 1))).getBlock() == Blocks.DIRT) {
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z + 1), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z - 1))).getBlock() == Blocks.DIRT) {
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z - 1), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			}
		}
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_block_spread_chance) {
			if ((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == Blocks.PACKED_MUD) {
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.DIRT.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y - 1, z))).getBlock() == Blocks.PACKED_MUD) {
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.DIRT.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x + 1, y, z))).getBlock() == Blocks.PACKED_MUD) {
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.DIRT.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x - 1, y, z))).getBlock() == Blocks.PACKED_MUD) {
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.DIRT.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z + 1))).getBlock() == Blocks.PACKED_MUD) {
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.DIRT.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z - 1))).getBlock() == Blocks.PACKED_MUD) {
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.DIRT.defaultBlockState(), 3);
			}
		}
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_block_spread_chance) {
			if ((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == Blocks.MUD) {
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.PACKED_MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y - 1, z))).getBlock() == Blocks.MUD) {
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.PACKED_MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x + 1, y, z))).getBlock() == Blocks.MUD) {
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.PACKED_MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x - 1, y, z))).getBlock() == Blocks.MUD) {
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.PACKED_MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z + 1))).getBlock() == Blocks.MUD) {
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.PACKED_MUD.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z - 1))).getBlock() == Blocks.MUD) {
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.PACKED_MUD.defaultBlockState(), 3);
			}
		}
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_block_spread_chance) {
			if ((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == Blocks.GRASS_BLOCK) {
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.DIRT.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y - 1, z))).getBlock() == Blocks.GRASS_BLOCK) {
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.DIRT.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x + 1, y, z))).getBlock() == Blocks.GRASS_BLOCK) {
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.DIRT.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x - 1, y, z))).getBlock() == Blocks.GRASS_BLOCK) {
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.DIRT.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z + 1))).getBlock() == Blocks.GRASS_BLOCK) {
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.DIRT.defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z - 1))).getBlock() == Blocks.GRASS_BLOCK) {
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.DIRT.defaultBlockState(), 3);
			}
		}
		if (Math.random() <= StevesWasteland3ModVariables.MapVariables.get(world).rad_block_spread_chance) {
			if ((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == Blocks.DIRT_PATH) {
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y + 1, z), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y - 1, z))).getBlock() == Blocks.DIRT_PATH) {
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y - 1, z), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x + 1, y, z))).getBlock() == Blocks.DIRT_PATH) {
				world.setBlock(new BlockPos(x + 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x + 1, y, z), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x - 1, y, z))).getBlock() == Blocks.DIRT_PATH) {
				world.setBlock(new BlockPos(x - 1, y, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x - 1, y, z), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z + 1))).getBlock() == Blocks.DIRT_PATH) {
				world.setBlock(new BlockPos(x, y, z + 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z + 1), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(new BlockPos(x, y, z - 1))).getBlock() == Blocks.DIRT_PATH) {
				world.setBlock(new BlockPos(x, y, z - 1), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y, z - 1), StevesWasteland3ModBlocks.DEAD_DIRT_BLOCK.get().defaultBlockState(), 3);
			}
		}
	}
}
