
package net.sprvlln.steveswasteland3.item;

import net.sprvlln.steveswasteland3.init.StevesWasteland3ModTabs;
import net.sprvlln.steveswasteland3.init.StevesWasteland3ModFluids;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

public class RadWaterItem extends BucketItem {
	public RadWaterItem() {
		super(StevesWasteland3ModFluids.RAD_WATER, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON).tab(StevesWasteland3ModTabs.TAB_STEVES_WASTELAND_CREATIVE_TAB));
	}
}
