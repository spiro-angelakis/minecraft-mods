package net.sprvlln.steveswasteland3.procedures;

import net.sprvlln.steveswasteland3.network.StevesWasteland3ModVariables;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;
import net.minecraft.core.BlockPos;

public class PlayerTickZombieHordeProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double hordeCount = 0;
		double zombieType = 0;
		double spawnX = 0;
		double spawnZ = 0;
		double hordeX = 0;
		double hordeZ = 0;
		double timeMod = 0;
		boolean allowed_attempt = false;
		allowed_attempt = true;
		if ((entity.level.dimension()) == Level.NETHER) {
			allowed_attempt = false;
		}
		if ((entity.level.dimension()) == Level.END) {
			allowed_attempt = false;
		}
		if (!((entity.level.dimension()) == Level.OVERWORLD)) {
			if (StevesWasteland3ModVariables.MapVariables.get(world).zombie_events_only_on_earth) {
				allowed_attempt = false;
			}
		}
		if (!world.getBiome(new BlockPos(x, y, z)).is(TagKey.create(Registry.BIOME_REGISTRY, new ResourceLocation("steves_wasteland3:is_wasteland")))) {
			if (StevesWasteland3ModVariables.MapVariables.get(world).zombie_events_only_in_wastes) {
				allowed_attempt = false;
			}
		}
		if (world instanceof Level _lvl10 && _lvl10.isDay()) {
			timeMod = StevesWasteland3ModVariables.MapVariables.get(world).day_zombie_spawns_mod;
			if (StevesWasteland3ModVariables.MapVariables.get(world).day_zombie_spawns_mod <= 0) {
				allowed_attempt = false;
			}
		} else {
			timeMod = StevesWasteland3ModVariables.MapVariables.get(world).night_zombie_spawns_mod;
			if (StevesWasteland3ModVariables.MapVariables.get(world).night_zombie_spawns_mod <= 0) {
				allowed_attempt = false;
			}
		}
		if (allowed_attempt == true) {
			if (Mth.nextInt(RandomSource.create(), 0, (int) (StevesWasteland3ModVariables.MapVariables.get(world).chance_for_horde_spawns_out_of * timeMod)) == 1) {
				ZombieHordeEventProcedure.execute(world, x, y, z);
			} else {
				if (Mth.nextInt(RandomSource.create(), 0, (int) (StevesWasteland3ModVariables.MapVariables.get(world).chance_for_zombie_spawns_out_of * timeMod)) == 1) {
					SpawnMoreZedsNearPlayerProcedure.execute(world, x, y, z);
				}
			}
		}
	}
}
