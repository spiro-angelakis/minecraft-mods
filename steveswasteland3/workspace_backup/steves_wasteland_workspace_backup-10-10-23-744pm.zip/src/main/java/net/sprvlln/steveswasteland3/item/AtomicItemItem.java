
package net.sprvlln.steveswasteland3.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AtomicItemItem extends Item {
	public AtomicItemItem() {
		super(new Item.Properties().tab(null).stacksTo(1).rarity(Rarity.EPIC));
	}
}
