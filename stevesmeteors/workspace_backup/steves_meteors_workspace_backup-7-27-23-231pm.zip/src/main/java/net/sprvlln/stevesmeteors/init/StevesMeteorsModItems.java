
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesmeteors.init;

import net.sprvlln.stevesmeteors.item.SmallStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallObsidianMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallNetherMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallLavaStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallLavaObsidianMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallLavaNetherMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallLapisStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallIronStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallIceMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallGoldStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallGoldNetherMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallEmeraldStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallDiamondStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallCoppperStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.SmallCoalStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeObsidianMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeNetherMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeLavaStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeLavaObsidianMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeLavaNetherMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeLapisStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeIronStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeIceMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeGoldStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeGoldNetherMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeEmeraldStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeDiamondStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeCopperStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.item.LargeCoalStoneMeteorSpawnerItem;
import net.sprvlln.stevesmeteors.StevesMeteorsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

public class StevesMeteorsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, StevesMeteorsMod.MODID);
	public static final RegistryObject<Item> SMALL_STONE_METEOR_SPAWNER = REGISTRY.register("small_stone_meteor_spawner", () -> new SmallStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_LAVA_STONE_METEOR_SPAWNER = REGISTRY.register("small_lava_stone_meteor_spawner", () -> new SmallLavaStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_COAL_STONE_METEOR_SPAWNER = REGISTRY.register("small_coal_stone_meteor_spawner", () -> new SmallCoalStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_IRON_STONE_METEOR_SPAWNER = REGISTRY.register("small_iron_stone_meteor_spawner", () -> new SmallIronStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_COPPPER_STONE_METEOR_SPAWNER = REGISTRY.register("small_coppper_stone_meteor_spawner", () -> new SmallCoppperStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_GOLD_STONE_METEOR_SPAWNER = REGISTRY.register("small_gold_stone_meteor_spawner", () -> new SmallGoldStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_LAPIS_STONE_METEOR_SPAWNER = REGISTRY.register("small_lapis_stone_meteor_spawner", () -> new SmallLapisStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_EMERALD_STONE_METEOR_SPAWNER = REGISTRY.register("small_emerald_stone_meteor_spawner", () -> new SmallEmeraldStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_DIAMOND_STONE_METEOR_SPAWNER = REGISTRY.register("small_diamond_stone_meteor_spawner", () -> new SmallDiamondStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_STONE_METEOR_SPAWNER = REGISTRY.register("large_stone_meteor_spawner", () -> new LargeStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_LAVA_STONE_METEOR_SPAWNER = REGISTRY.register("large_lava_stone_meteor_spawner", () -> new LargeLavaStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_COAL_STONE_METEOR_SPAWNER = REGISTRY.register("large_coal_stone_meteor_spawner", () -> new LargeCoalStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_IRON_STONE_METEOR_SPAWNER = REGISTRY.register("large_iron_stone_meteor_spawner", () -> new LargeIronStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_COPPER_STONE_METEOR_SPAWNER = REGISTRY.register("large_copper_stone_meteor_spawner", () -> new LargeCopperStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_GOLD_STONE_METEOR_SPAWNER = REGISTRY.register("large_gold_stone_meteor_spawner", () -> new LargeGoldStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_LAPIS_STONE_METEOR_SPAWNER = REGISTRY.register("large_lapis_stone_meteor_spawner", () -> new LargeLapisStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_EMERALD_STONE_METEOR_SPAWNER = REGISTRY.register("large_emerald_stone_meteor_spawner", () -> new LargeEmeraldStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_DIAMOND_STONE_METEOR_SPAWNER = REGISTRY.register("large_diamond_stone_meteor_spawner", () -> new LargeDiamondStoneMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_NETHER_METEOR_SPAWNER = REGISTRY.register("small_nether_meteor_spawner", () -> new SmallNetherMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_LAVA_NETHER_METEOR_SPAWNER = REGISTRY.register("small_lava_nether_meteor_spawner", () -> new SmallLavaNetherMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_GOLD_NETHER_METEOR_SPAWNER = REGISTRY.register("small_gold_nether_meteor_spawner", () -> new SmallGoldNetherMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_NETHER_METEOR_SPAWNER = REGISTRY.register("large_nether_meteor_spawner", () -> new LargeNetherMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_LAVA_NETHER_METEOR_SPAWNER = REGISTRY.register("large_lava_nether_meteor_spawner", () -> new LargeLavaNetherMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_GOLD_NETHER_METEOR_SPAWNER = REGISTRY.register("large_gold_nether_meteor_spawner", () -> new LargeGoldNetherMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_OBSIDIAN_METEOR_SPAWNER = REGISTRY.register("small_obsidian_meteor_spawner", () -> new SmallObsidianMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_LAVA_OBSIDIAN_METEOR_SPAWNER = REGISTRY.register("small_lava_obsidian_meteor_spawner", () -> new SmallLavaObsidianMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_OBSIDIAN_METEOR_SPAWNER = REGISTRY.register("large_obsidian_meteor_spawner", () -> new LargeObsidianMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_LAVA_OBSIDIAN_METEOR_SPAWNER = REGISTRY.register("large_lava_obsidian_meteor_spawner", () -> new LargeLavaObsidianMeteorSpawnerItem());
	public static final RegistryObject<Item> SMALL_ICE_METEOR_SPAWNER = REGISTRY.register("small_ice_meteor_spawner", () -> new SmallIceMeteorSpawnerItem());
	public static final RegistryObject<Item> LARGE_ICE_METEOR_SPAWNER = REGISTRY.register("large_ice_meteor_spawner", () -> new LargeIceMeteorSpawnerItem());
	public static final RegistryObject<Item> METEOR_WORLD_GEN_BLOCK = block(StevesMeteorsModBlocks.METEOR_WORLD_GEN_BLOCK, null);
	public static final RegistryObject<Item> METEOR_DETECTOR_COMPUTER = block(StevesMeteorsModBlocks.METEOR_DETECTOR_COMPUTER, StevesMeteorsModTabs.TAB_STEVES_METEORS_CREATIVE_TAB);
	public static final RegistryObject<Item> METEOR_DEFENSE_LASER = block(StevesMeteorsModBlocks.METEOR_DEFENSE_LASER, StevesMeteorsModTabs.TAB_STEVES_METEORS_CREATIVE_TAB);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
