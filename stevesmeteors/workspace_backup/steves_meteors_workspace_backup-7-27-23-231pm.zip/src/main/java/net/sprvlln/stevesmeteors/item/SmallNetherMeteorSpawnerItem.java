
package net.sprvlln.stevesmeteors.item;

import net.sprvlln.stevesmeteors.procedures.SmallNetherMeteorCreationProcedure;
import net.sprvlln.stevesmeteors.init.StevesMeteorsModTabs;

import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.InteractionResult;

public class SmallNetherMeteorSpawnerItem extends Item {
	public SmallNetherMeteorSpawnerItem() {
		super(new Item.Properties().tab(StevesMeteorsModTabs.TAB_STEVES_METEORS_CREATIVE_TAB).stacksTo(1).rarity(Rarity.EPIC));
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		super.useOn(context);
		SmallNetherMeteorCreationProcedure.execute(context.getLevel(), context.getClickedPos().getX(), context.getClickedPos().getY(), context.getClickedPos().getZ());
		return InteractionResult.SUCCESS;
	}
}
