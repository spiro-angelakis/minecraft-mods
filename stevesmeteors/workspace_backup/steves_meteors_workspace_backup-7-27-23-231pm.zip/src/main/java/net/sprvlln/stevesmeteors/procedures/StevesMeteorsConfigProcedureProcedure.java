package net.sprvlln.stevesmeteors.procedures;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;

import java.io.IOException;
import java.io.FileWriter;
import java.io.File;

import com.google.gson.GsonBuilder;
import com.google.gson.Gson;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class StevesMeteorsConfigProcedureProcedure {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		execute();
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		File steves_meteors_config = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		steves_meteors_config = new File((FMLPaths.GAMEDIR.get().toString() + "/config/"), File.separator + "steves-meteors-config.json");
		if (!steves_meteors_config.exists()) {
			try {
				steves_meteors_config.getParentFile().mkdirs();
				steves_meteors_config.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			main_json_object.addProperty("meteor_defense_laser_does_need_power", false);
			main_json_object.addProperty("meteor_tracking_pc_does_need_power", false);
			main_json_object.addProperty("meteor_falling_event_chance_out_of", 1920);
			main_json_object.addProperty("allow_force_meteor_event_command", true);
			main_json_object.addProperty("meteor_event_only_on_earth", false);
			{
				Gson mainGSONBuilderVariable = new GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(steves_meteors_config);
					fileWriter.write(mainGSONBuilderVariable.toJson(main_json_object));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		}
	}
}
