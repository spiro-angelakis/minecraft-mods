
package net.sprvlln.stevesmeteors.client.renderer;

import net.sprvlln.stevesmeteors.entity.MeteorIncomingEntityEntity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

public class MeteorIncomingEntityRenderer extends HumanoidMobRenderer<MeteorIncomingEntityEntity, HumanoidModel<MeteorIncomingEntityEntity>> {
	public MeteorIncomingEntityRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR))));
	}

	@Override
	public ResourceLocation getTextureLocation(MeteorIncomingEntityEntity entity) {
		return new ResourceLocation("steves_meteors:textures/entities/transparent.png");
	}
}
