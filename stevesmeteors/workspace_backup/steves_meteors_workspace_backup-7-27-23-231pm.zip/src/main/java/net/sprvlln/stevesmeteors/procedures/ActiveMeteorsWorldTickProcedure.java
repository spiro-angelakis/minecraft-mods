package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;
import net.sprvlln.stevesmeteors.init.StevesMeteorsModParticleTypes;
import net.sprvlln.stevesmeteors.init.StevesMeteorsModEntities;
import net.sprvlln.stevesmeteors.entity.MeteorIncomingEntityEntity;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import java.util.ArrayList;

import java.io.File;

@Mod.EventBusSubscriber
public class ActiveMeteorsWorldTickProcedure {
	@SubscribeEvent
	public static void onWorldTick(TickEvent.LevelTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.level);
		}
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		Entity playerTarget = null;
		File steves_meteors_config = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		double playerI = 0;
		double playerNum = 0;
		double meteor_event_chance_out_of = 0;
		boolean pickedPlayer = false;
		boolean processNewMeteor = false;
		boolean validWorld = false;
		boolean onlyEarth = false;
		onlyEarth = false;
		meteor_event_chance_out_of = 1920;
		if (StevesMeteorsModVariables.MapVariables.get(world).FallingEventChanceOutOf != meteor_event_chance_out_of) {
			if (StevesMeteorsModVariables.MapVariables.get(world).FallingEventChanceOutOf > 1) {
				meteor_event_chance_out_of = Math.round(StevesMeteorsModVariables.MapVariables.get(world).FallingEventChanceOutOf);
			}
		}
		if (StevesMeteorsModVariables.MapVariables.get(world).EventOnlyOnEarth == true) {
			onlyEarth = true;
		}
		validWorld = true;
		if (onlyEarth == true) {
			if (!((world instanceof Level _lvl ? _lvl.dimension() : Level.OVERWORLD) == Level.OVERWORLD)) {
				validWorld = false;
			}
		}
		if ((world instanceof Level _lvl ? _lvl.dimension() : Level.OVERWORLD) == Level.NETHER) {
			validWorld = false;
		}
		if ((world instanceof Level _lvl ? _lvl.dimension() : Level.OVERWORLD) == Level.END) {
			validWorld = false;
		}
		if (validWorld == true) {
			if (StevesMeteorsModVariables.MapVariables.get(world).meteorEventProcess == false) {
				if (StevesMeteorsModVariables.MapVariables.get(world).meteorIncoming == false) {
					processNewMeteor = false;
					if (StevesMeteorsModVariables.MapVariables.get(world).forceMeteorEvent == true) {
						processNewMeteor = true;
						StevesMeteorsModVariables.MapVariables.get(world).forceMeteorEvent = false;
						StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
					} else if (Mth.nextInt(RandomSource.create(), 0, (int) meteor_event_chance_out_of) == 1) {
						processNewMeteor = true;
					}
					if (processNewMeteor == true) {
						StevesMeteorsModVariables.MapVariables.get(world).meteorEventProcess = true;
						StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
						pickedPlayer = false;
						playerI = 1;
						playerNum = Mth.nextInt(RandomSource.create(), 1, world.players().size());
						for (Entity entityiterator : new ArrayList<>(world.players())) {
							if (pickedPlayer == false) {
								if (playerI == playerNum) {
									playerTarget = entityiterator;
									pickedPlayer = true;
								} else {
									playerI = playerI + 1;
								}
							} else {
								break;
							}
						}
						if (pickedPlayer == true) {
							StevesMeteorsModVariables.MapVariables.get(world).meteorIncoming = true;
							StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
							StevesMeteorsModVariables.MapVariables.get(world).targetPlayerName = playerTarget.getDisplayName().getString();
							StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
							StevesMeteorsModVariables.MapVariables.get(world).meteorX = playerTarget.getX() + Mth.nextInt(RandomSource.create(), -250, 250);
							StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
							StevesMeteorsModVariables.MapVariables.get(world).meteorZ = playerTarget.getZ() + Mth.nextInt(RandomSource.create(), -250, 250);
							StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
							StevesMeteorsModVariables.MapVariables.get(world).meteorTime = 250;
							StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
							world.addParticle((SimpleParticleType) (StevesMeteorsModParticleTypes.STONE_METEOR_PARTICLE.get()), StevesMeteorsModVariables.MapVariables.get(world).meteorX, 300, StevesMeteorsModVariables.MapVariables.get(world).meteorZ,
									0, 1, 0);
							if (world instanceof ServerLevel _level) {
								Entity entityToSpawn = new MeteorIncomingEntityEntity(StevesMeteorsModEntities.METEOR_INCOMING_ENTITY.get(), _level);
								entityToSpawn.moveTo(StevesMeteorsModVariables.MapVariables.get(world).meteorX, 300, StevesMeteorsModVariables.MapVariables.get(world).meteorZ, 0, 0);
								entityToSpawn.setYBodyRot(0);
								entityToSpawn.setYHeadRot(0);
								entityToSpawn.setDeltaMovement(0, 0, 0);
								if (entityToSpawn instanceof Mob _mobToSpawn)
									_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
								world.addFreshEntity(entityToSpawn);
							}
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null,
											new BlockPos(StevesMeteorsModVariables.MapVariables.get(world).meteorX,
													world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorX, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorZ),
													StevesMeteorsModVariables.MapVariables.get(world).meteorZ),
											ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("steves_meteors:meteor_falling")), SoundSource.AMBIENT, 5, 1);
								} else {
									_level.playLocalSound(StevesMeteorsModVariables.MapVariables.get(world).meteorX,
											(world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorX, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorZ)),
											StevesMeteorsModVariables.MapVariables.get(world).meteorZ, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("steves_meteors:meteor_falling")), SoundSource.AMBIENT, 5, 1, false);
								}
							}
						} else {
							StevesMeteorsModVariables.MapVariables.get(world).meteorEventProcess = false;
							StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
						}
					}
				}
			}
		}
	}
}
