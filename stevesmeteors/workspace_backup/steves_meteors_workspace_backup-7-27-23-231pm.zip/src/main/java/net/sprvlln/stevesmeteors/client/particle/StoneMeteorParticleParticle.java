
package net.sprvlln.stevesmeteors.client.particle;

import net.sprvlln.stevesmeteors.procedures.MeteorParticleExpiryConditionProcedure;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.multiplayer.ClientLevel;

@OnlyIn(Dist.CLIENT)
public class StoneMeteorParticleParticle extends TextureSheetParticle {
	public static StoneMeteorParticleParticleProvider provider(SpriteSet spriteSet) {
		return new StoneMeteorParticleParticleProvider(spriteSet);
	}

	public static class StoneMeteorParticleParticleProvider implements ParticleProvider<SimpleParticleType> {
		private final SpriteSet spriteSet;

		public StoneMeteorParticleParticleProvider(SpriteSet spriteSet) {
			this.spriteSet = spriteSet;
		}

		public Particle createParticle(SimpleParticleType typeIn, ClientLevel worldIn, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
			return new StoneMeteorParticleParticle(worldIn, x, y, z, xSpeed, ySpeed, zSpeed, this.spriteSet);
		}
	}

	private final SpriteSet spriteSet;

	protected StoneMeteorParticleParticle(ClientLevel world, double x, double y, double z, double vx, double vy, double vz, SpriteSet spriteSet) {
		super(world, x, y, z);
		this.spriteSet = spriteSet;
		this.setSize(0.2f, 0.2f);

		this.lifetime = 1200;
		this.gravity = 0.1f;
		this.hasPhysics = true;
		this.xd = vx * 3;
		this.yd = vy * 3;
		this.zd = vz * 3;
		this.pickSprite(spriteSet);
	}

	@Override
	public ParticleRenderType getRenderType() {
		return ParticleRenderType.PARTICLE_SHEET_OPAQUE;
	}

	@Override
	public void tick() {
		super.tick();
		double x = this.x;
		double y = this.y;
		double z = this.z;
		if (MeteorParticleExpiryConditionProcedure.execute(onGround))
			this.remove();
	}
}
