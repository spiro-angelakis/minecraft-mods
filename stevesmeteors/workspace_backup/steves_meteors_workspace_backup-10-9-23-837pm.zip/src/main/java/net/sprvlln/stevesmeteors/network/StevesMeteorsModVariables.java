package net.sprvlln.stevesmeteors.network;

import net.sprvlln.stevesmeteors.StevesMeteorsMod;

import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;

import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.CompoundTag;

import java.util.function.Supplier;
import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class StevesMeteorsModVariables {
	public static List<Object> meteor_types_array = new ArrayList<>();
	public static List<Object> meteor_type_array_1 = new ArrayList<>();
	public static List<Object> meteor_type_array_2 = new ArrayList<>();
	public static List<Object> meteor_type_array_3 = new ArrayList<>();
	public static List<Object> meteor_type_array_4 = new ArrayList<>();
	public static List<Object> meteor_type_array_5 = new ArrayList<>();
	public static List<Object> meteor_type_array_6 = new ArrayList<>();
	public static List<Object> meteor_type_array_7 = new ArrayList<>();
	public static List<Object> meteor_type_array_8 = new ArrayList<>();
	public static List<Object> meteor_type_array_9 = new ArrayList<>();
	public static List<Object> meteor_type_array_10 = new ArrayList<>();
	public static List<Object> meteor_type_array_11 = new ArrayList<>();
	public static List<Object> meteor_type_array_12 = new ArrayList<>();
	public static List<Object> meteor_type_array_13 = new ArrayList<>();
	public static List<Object> meteor_type_array_14 = new ArrayList<>();
	public static List<Object> meteor_type_array_15 = new ArrayList<>();
	public static List<Object> meteor_type_array_16 = new ArrayList<>();
	public static List<Object> meteor_type_array_17 = new ArrayList<>();
	public static List<Object> meteor_type_array_18 = new ArrayList<>();
	public static List<Object> meteor_type_array_19 = new ArrayList<>();
	public static List<Object> meteor_type_array_20 = new ArrayList<>();
	public static List<Object> meteor_type_array_21 = new ArrayList<>();
	public static List<Object> meteor_type_array_22 = new ArrayList<>();
	public static List<Object> meteor_type_array_23 = new ArrayList<>();
	public static List<Object> meteor_type_array_24 = new ArrayList<>();
	public static List<Object> meteor_type_array_25 = new ArrayList<>();

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		StevesMeteorsMod.addNetworkMessage(SavedDataSyncMessage.class, SavedDataSyncMessage::buffer, SavedDataSyncMessage::new, SavedDataSyncMessage::handler);
	}

	@Mod.EventBusSubscriber
	public static class EventBusVariableHandlers {
		@SubscribeEvent
		public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
			if (!event.getEntity().level.isClientSide()) {
				SavedData mapdata = MapVariables.get(event.getEntity().level);
				SavedData worlddata = WorldVariables.get(event.getEntity().level);
				if (mapdata != null)
					StevesMeteorsMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) event.getEntity()), new SavedDataSyncMessage(0, mapdata));
				if (worlddata != null)
					StevesMeteorsMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) event.getEntity()), new SavedDataSyncMessage(1, worlddata));
			}
		}

		@SubscribeEvent
		public static void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
			if (!event.getEntity().level.isClientSide()) {
				SavedData worlddata = WorldVariables.get(event.getEntity().level);
				if (worlddata != null)
					StevesMeteorsMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer) event.getEntity()), new SavedDataSyncMessage(1, worlddata));
			}
		}
	}

	public static class WorldVariables extends SavedData {
		public static final String DATA_NAME = "steves_meteors_worldvars";
		public double ticks_since_meteor_chance = 0;
		public double current_meteor_size = 0;
		public BlockState meteor_rock_block = Blocks.AIR.defaultBlockState();
		public BlockState meteor_stone_block = Blocks.AIR.defaultBlockState();
		public BlockState meteor_ore_block = Blocks.AIR.defaultBlockState();

		public static WorldVariables load(CompoundTag tag) {
			WorldVariables data = new WorldVariables();
			data.read(tag);
			return data;
		}

		public void read(CompoundTag nbt) {
			ticks_since_meteor_chance = nbt.getDouble("ticks_since_meteor_chance");
			current_meteor_size = nbt.getDouble("current_meteor_size");
			meteor_rock_block = NbtUtils.readBlockState(nbt.getCompound("meteor_rock_block"));
			meteor_stone_block = NbtUtils.readBlockState(nbt.getCompound("meteor_stone_block"));
			meteor_ore_block = NbtUtils.readBlockState(nbt.getCompound("meteor_ore_block"));
		}

		@Override
		public CompoundTag save(CompoundTag nbt) {
			nbt.putDouble("ticks_since_meteor_chance", ticks_since_meteor_chance);
			nbt.putDouble("current_meteor_size", current_meteor_size);
			nbt.put("meteor_rock_block", NbtUtils.writeBlockState(meteor_rock_block));
			nbt.put("meteor_stone_block", NbtUtils.writeBlockState(meteor_stone_block));
			nbt.put("meteor_ore_block", NbtUtils.writeBlockState(meteor_ore_block));
			return nbt;
		}

		public void syncData(LevelAccessor world) {
			this.setDirty();
			if (world instanceof Level level && !level.isClientSide())
				StevesMeteorsMod.PACKET_HANDLER.send(PacketDistributor.DIMENSION.with(level::dimension), new SavedDataSyncMessage(1, this));
		}

		static WorldVariables clientSide = new WorldVariables();

		public static WorldVariables get(LevelAccessor world) {
			if (world instanceof ServerLevel level) {
				return level.getDataStorage().computeIfAbsent(e -> WorldVariables.load(e), WorldVariables::new, DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class MapVariables extends SavedData {
		public static final String DATA_NAME = "steves_meteors_mapvars";
		public boolean meteorIncoming = false;
		public double meteorX = 0;
		public double meteorZ = 0;
		public double meteorTime = 0;
		public String targetPlayerName = "\"\"";
		public boolean meteorBlocked = false;
		public boolean meteorEventProcess = false;
		public boolean forceMeteorEvent = false;
		public boolean defenseLaserNeedsPower = false;
		public boolean trackingPcNeedsPower = false;
		public double FallingEventChanceOutOf = 0;
		public boolean AllowForceEventCommand = false;
		public boolean EventOnlyOnEarth = false;
		public double minutes_between_meteor_chance = 0;
		public boolean allow_laser_chat_local = false;
		public boolean allow_laser_chat_global = false;
		public double small_meteor_min_size = 0;
		public double small_meteor_max_size = 0;
		public double small_meteor_crater_mod = 0;
		public double large_meteor_min_size = 0;
		public double large_meteor_max_size = 0;
		public double large_meteor_crater_mod = 0;
		public double stone_to_ore_ratio = 0;
		public double ice_to_stone_ratio = 0;
		public double rock_to_lava_ratio = 0;
		public double max_fires = 0;
		public double max_subcraters = 0;
		public boolean allow_meteor_worldgen = false;
		public boolean allow_meteor_events = false;
		public double defense_laser_reach = 0;
		public double monitor_reach = 0;
		public double defense_laser_local_chat_reach = 0;
		public double monitor_local_chat_reach = 0;
		public double meteor_dist_from_player = 0;
		public double meteoric_rock_to_other_ratio = 0;
		public double meteor_types_to_use = 0;
		public double large_to_small_meteor_spawn_ratio = 0;

		public static MapVariables load(CompoundTag tag) {
			MapVariables data = new MapVariables();
			data.read(tag);
			return data;
		}

		public void read(CompoundTag nbt) {
			meteorIncoming = nbt.getBoolean("meteorIncoming");
			meteorX = nbt.getDouble("meteorX");
			meteorZ = nbt.getDouble("meteorZ");
			meteorTime = nbt.getDouble("meteorTime");
			targetPlayerName = nbt.getString("targetPlayerName");
			meteorBlocked = nbt.getBoolean("meteorBlocked");
			meteorEventProcess = nbt.getBoolean("meteorEventProcess");
			forceMeteorEvent = nbt.getBoolean("forceMeteorEvent");
			defenseLaserNeedsPower = nbt.getBoolean("defenseLaserNeedsPower");
			trackingPcNeedsPower = nbt.getBoolean("trackingPcNeedsPower");
			FallingEventChanceOutOf = nbt.getDouble("FallingEventChanceOutOf");
			AllowForceEventCommand = nbt.getBoolean("AllowForceEventCommand");
			EventOnlyOnEarth = nbt.getBoolean("EventOnlyOnEarth");
			minutes_between_meteor_chance = nbt.getDouble("minutes_between_meteor_chance");
			allow_laser_chat_local = nbt.getBoolean("allow_laser_chat_local");
			allow_laser_chat_global = nbt.getBoolean("allow_laser_chat_global");
			small_meteor_min_size = nbt.getDouble("small_meteor_min_size");
			small_meteor_max_size = nbt.getDouble("small_meteor_max_size");
			small_meteor_crater_mod = nbt.getDouble("small_meteor_crater_mod");
			large_meteor_min_size = nbt.getDouble("large_meteor_min_size");
			large_meteor_max_size = nbt.getDouble("large_meteor_max_size");
			large_meteor_crater_mod = nbt.getDouble("large_meteor_crater_mod");
			stone_to_ore_ratio = nbt.getDouble("stone_to_ore_ratio");
			ice_to_stone_ratio = nbt.getDouble("ice_to_stone_ratio");
			rock_to_lava_ratio = nbt.getDouble("rock_to_lava_ratio");
			max_fires = nbt.getDouble("max_fires");
			max_subcraters = nbt.getDouble("max_subcraters");
			allow_meteor_worldgen = nbt.getBoolean("allow_meteor_worldgen");
			allow_meteor_events = nbt.getBoolean("allow_meteor_events");
			defense_laser_reach = nbt.getDouble("defense_laser_reach");
			monitor_reach = nbt.getDouble("monitor_reach");
			defense_laser_local_chat_reach = nbt.getDouble("defense_laser_local_chat_reach");
			monitor_local_chat_reach = nbt.getDouble("monitor_local_chat_reach");
			meteor_dist_from_player = nbt.getDouble("meteor_dist_from_player");
			meteoric_rock_to_other_ratio = nbt.getDouble("meteoric_rock_to_other_ratio");
			meteor_types_to_use = nbt.getDouble("meteor_types_to_use");
			large_to_small_meteor_spawn_ratio = nbt.getDouble("large_to_small_meteor_spawn_ratio");
		}

		@Override
		public CompoundTag save(CompoundTag nbt) {
			nbt.putBoolean("meteorIncoming", meteorIncoming);
			nbt.putDouble("meteorX", meteorX);
			nbt.putDouble("meteorZ", meteorZ);
			nbt.putDouble("meteorTime", meteorTime);
			nbt.putString("targetPlayerName", targetPlayerName);
			nbt.putBoolean("meteorBlocked", meteorBlocked);
			nbt.putBoolean("meteorEventProcess", meteorEventProcess);
			nbt.putBoolean("forceMeteorEvent", forceMeteorEvent);
			nbt.putBoolean("defenseLaserNeedsPower", defenseLaserNeedsPower);
			nbt.putBoolean("trackingPcNeedsPower", trackingPcNeedsPower);
			nbt.putDouble("FallingEventChanceOutOf", FallingEventChanceOutOf);
			nbt.putBoolean("AllowForceEventCommand", AllowForceEventCommand);
			nbt.putBoolean("EventOnlyOnEarth", EventOnlyOnEarth);
			nbt.putDouble("minutes_between_meteor_chance", minutes_between_meteor_chance);
			nbt.putBoolean("allow_laser_chat_local", allow_laser_chat_local);
			nbt.putBoolean("allow_laser_chat_global", allow_laser_chat_global);
			nbt.putDouble("small_meteor_min_size", small_meteor_min_size);
			nbt.putDouble("small_meteor_max_size", small_meteor_max_size);
			nbt.putDouble("small_meteor_crater_mod", small_meteor_crater_mod);
			nbt.putDouble("large_meteor_min_size", large_meteor_min_size);
			nbt.putDouble("large_meteor_max_size", large_meteor_max_size);
			nbt.putDouble("large_meteor_crater_mod", large_meteor_crater_mod);
			nbt.putDouble("stone_to_ore_ratio", stone_to_ore_ratio);
			nbt.putDouble("ice_to_stone_ratio", ice_to_stone_ratio);
			nbt.putDouble("rock_to_lava_ratio", rock_to_lava_ratio);
			nbt.putDouble("max_fires", max_fires);
			nbt.putDouble("max_subcraters", max_subcraters);
			nbt.putBoolean("allow_meteor_worldgen", allow_meteor_worldgen);
			nbt.putBoolean("allow_meteor_events", allow_meteor_events);
			nbt.putDouble("defense_laser_reach", defense_laser_reach);
			nbt.putDouble("monitor_reach", monitor_reach);
			nbt.putDouble("defense_laser_local_chat_reach", defense_laser_local_chat_reach);
			nbt.putDouble("monitor_local_chat_reach", monitor_local_chat_reach);
			nbt.putDouble("meteor_dist_from_player", meteor_dist_from_player);
			nbt.putDouble("meteoric_rock_to_other_ratio", meteoric_rock_to_other_ratio);
			nbt.putDouble("meteor_types_to_use", meteor_types_to_use);
			nbt.putDouble("large_to_small_meteor_spawn_ratio", large_to_small_meteor_spawn_ratio);
			return nbt;
		}

		public void syncData(LevelAccessor world) {
			this.setDirty();
			if (world instanceof Level && !world.isClientSide())
				StevesMeteorsMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new SavedDataSyncMessage(0, this));
		}

		static MapVariables clientSide = new MapVariables();

		public static MapVariables get(LevelAccessor world) {
			if (world instanceof ServerLevelAccessor serverLevelAcc) {
				return serverLevelAcc.getLevel().getServer().getLevel(Level.OVERWORLD).getDataStorage().computeIfAbsent(e -> MapVariables.load(e), MapVariables::new, DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class SavedDataSyncMessage {
		public int type;
		public SavedData data;

		public SavedDataSyncMessage(FriendlyByteBuf buffer) {
			this.type = buffer.readInt();
			this.data = this.type == 0 ? new MapVariables() : new WorldVariables();
			if (this.data instanceof MapVariables _mapvars)
				_mapvars.read(buffer.readNbt());
			else if (this.data instanceof WorldVariables _worldvars)
				_worldvars.read(buffer.readNbt());
		}

		public SavedDataSyncMessage(int type, SavedData data) {
			this.type = type;
			this.data = data;
		}

		public static void buffer(SavedDataSyncMessage message, FriendlyByteBuf buffer) {
			buffer.writeInt(message.type);
			buffer.writeNbt(message.data.save(new CompoundTag()));
		}

		public static void handler(SavedDataSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					if (message.type == 0)
						MapVariables.clientSide = (MapVariables) message.data;
					else
						WorldVariables.clientSide = (WorldVariables) message.data;
				}
			});
			context.setPacketHandled(true);
		}
	}
}
