
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesmeteors.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class StevesMeteorsModTabs {
	public static CreativeModeTab TAB_STEVES_METEORS_CREATIVE_TAB;

	public static void load() {
		TAB_STEVES_METEORS_CREATIVE_TAB = new CreativeModeTab("tabsteves_meteors_creative_tab") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(StevesMeteorsModItems.NETHER_METEOR.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
