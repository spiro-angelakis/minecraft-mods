package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;
import net.sprvlln.stevesmeteors.StevesMeteorsMod;

import net.minecraftforge.fml.loading.FMLPaths;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.nbt.TagParser;
import net.minecraft.nbt.NbtUtils;

import java.util.List;
import java.util.ArrayList;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.mojang.brigadier.exceptions.CommandSyntaxException;

import com.google.gson.Gson;

public class SetupMeteorTypesVariablesProcedure {
	public static void execute() {
		List<Object> meteor_types = new ArrayList<>();
		List<Object> current_meteor_type_array = new ArrayList<>();
		File meteor_types_file = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		double meteor_type_iterator = 0;
		meteor_type_iterator = 1;
		meteor_types_file = new File((FMLPaths.GAMEDIR.get().toString() + "/config/sprvlln/steves-meteors/"), File.separator + "sm_meteor_types.json");
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(meteor_types_file));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				main_json_object = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				for (int index0 = 0; index0 < 25; index0++) {
					if (meteor_type_iterator == 1) {
						StevesMeteorsModVariables.meteor_type_array_1.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_1.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_1.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 2) {
						StevesMeteorsModVariables.meteor_type_array_2.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_2.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_2.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 3) {
						StevesMeteorsModVariables.meteor_type_array_3.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_3.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_3.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 4) {
						StevesMeteorsModVariables.meteor_type_array_4.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_4.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_4.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 5) {
						StevesMeteorsModVariables.meteor_type_array_5.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_5.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_5.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 6) {
						StevesMeteorsModVariables.meteor_type_array_6.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_6.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_6.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 7) {
						StevesMeteorsModVariables.meteor_type_array_7.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_7.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_7.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 8) {
						StevesMeteorsModVariables.meteor_type_array_8.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_8.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_8.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 9) {
						StevesMeteorsModVariables.meteor_type_array_9.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_9.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_9.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 10) {
						StevesMeteorsModVariables.meteor_type_array_10.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_10.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_10.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 11) {
						StevesMeteorsModVariables.meteor_type_array_11.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_11.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_11.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 12) {
						StevesMeteorsModVariables.meteor_type_array_12.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_12.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_12.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 13) {
						StevesMeteorsModVariables.meteor_type_array_13.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_13.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_13.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 14) {
						StevesMeteorsModVariables.meteor_type_array_14.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_14.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_14.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 15) {
						StevesMeteorsModVariables.meteor_type_array_15.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_15.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_15.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 16) {
						StevesMeteorsModVariables.meteor_type_array_16.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_16.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_16.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 17) {
						StevesMeteorsModVariables.meteor_type_array_17.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_17.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_17.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 18) {
						StevesMeteorsModVariables.meteor_type_array_18.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_18.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_18.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 19) {
						StevesMeteorsModVariables.meteor_type_array_19.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_19.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_19.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 20) {
						StevesMeteorsModVariables.meteor_type_array_20.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_20.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_20.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 21) {
						StevesMeteorsModVariables.meteor_type_array_21.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_21.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_21.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 22) {
						StevesMeteorsModVariables.meteor_type_array_22.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_22.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_22.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 23) {
						StevesMeteorsModVariables.meteor_type_array_23.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_23.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_23.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 24) {
						StevesMeteorsModVariables.meteor_type_array_24.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_24.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_24.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					} else if (meteor_type_iterator == 25) {
						StevesMeteorsModVariables.meteor_type_array_25.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_stone_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_25.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_ore_block")).getAsString()));
						StevesMeteorsModVariables.meteor_type_array_25.add(new Object() {
							public BlockState getBlockState(String _nbt) {
								try {
									return NbtUtils.readBlockState(TagParser.parseTag(_nbt));
								} catch (CommandSyntaxException e) {
									StevesMeteorsMod.LOGGER.error(e);
									return Blocks.AIR.defaultBlockState();
								}
							}
						}.getBlockState(main_json_object.get(("meteor_" + new java.text.DecimalFormat("##.##").format(meteor_type_iterator) + "_rock_block")).getAsString()));
					}
					meteor_type_iterator = meteor_type_iterator + 1;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		StevesMeteorsModVariables.meteor_types_array.clear();
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_1);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_2);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_3);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_4);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_5);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_6);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_7);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_8);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_9);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_10);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_11);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_12);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_13);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_14);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_15);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_16);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_17);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_18);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_19);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_20);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_21);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_22);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_23);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_24);
		StevesMeteorsModVariables.meteor_types_array.add(StevesMeteorsModVariables.meteor_type_array_25);
	}
}
