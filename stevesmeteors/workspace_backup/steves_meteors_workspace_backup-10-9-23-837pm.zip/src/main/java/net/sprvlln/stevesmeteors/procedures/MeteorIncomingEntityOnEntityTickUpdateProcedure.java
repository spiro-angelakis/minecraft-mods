package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

public class MeteorIncomingEntityOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean landed = false;
		landed = false;
		if (entity.getPersistentData().getBoolean("bombEnabled") == true) {
			if (entity.isOnGround() == true) {
				landed = true;
			} else if (entity.isInWaterOrBubble() == true) {
				landed = true;
			}
			if (landed == true) {
				GenerateMeteorProcedure.execute(world, x, y, z);
				if (!entity.level.isClientSide())
					entity.discard();
			}
		} else {
			if (StevesMeteorsModVariables.MapVariables.get(world).allow_laser_chat_global) {
				if (!world.isClientSide() && world.getServer() != null)
					world.getServer().getPlayerList().broadcastSystemMessage(Component.literal("An incoming meteor was destroyed in the atmosphere by planetary defenses."), false);
			}
			StevesMeteorsModVariables.MapVariables.get(world).meteorTime = 0;
			StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
			StevesMeteorsModVariables.MapVariables.get(world).meteorX = 0;
			StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
			StevesMeteorsModVariables.MapVariables.get(world).meteorZ = 0;
			StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
			StevesMeteorsModVariables.MapVariables.get(world).meteorBlocked = false;
			StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
			StevesMeteorsModVariables.MapVariables.get(world).targetPlayerName = "";
			StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
			StevesMeteorsModVariables.MapVariables.get(world).meteorIncoming = false;
			StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
			StevesMeteorsModVariables.MapVariables.get(world).meteorEventProcess = false;
			StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
			StevesMeteorsModVariables.MapVariables.get(world).forceMeteorEvent = false;
			StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						("forceload remove " + new java.text.DecimalFormat("##.##").format(world.getChunk(new BlockPos(x, y, z)).getPos().getMinBlockX()) + " "
								+ new java.text.DecimalFormat("##.##").format(world.getChunk(new BlockPos(x, y, z)).getPos().getMinBlockZ()) + " "
								+ new java.text.DecimalFormat("##.##").format(world.getChunk(new BlockPos(x, y, z)).getPos().getMaxBlockX()) + " "
								+ new java.text.DecimalFormat("##.##").format(world.getChunk(new BlockPos(x, y, z)).getPos().getMaxBlockZ())));
			if (!entity.level.isClientSide())
				entity.discard();
		}
	}
}
