
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesmeteors.init;

import net.sprvlln.stevesmeteors.item.NetherMeteorItem;
import net.sprvlln.stevesmeteors.item.MeteoriteChunkItem;
import net.sprvlln.stevesmeteors.item.LargeMeteoriteChunkItem;
import net.sprvlln.stevesmeteors.StevesMeteorsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

public class StevesMeteorsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, StevesMeteorsMod.MODID);
	public static final RegistryObject<Item> METEOR_WORLD_GEN_BLOCK = block(StevesMeteorsModBlocks.METEOR_WORLD_GEN_BLOCK, null);
	public static final RegistryObject<Item> METEOR_DETECTOR_COMPUTER = block(StevesMeteorsModBlocks.METEOR_DETECTOR_COMPUTER, StevesMeteorsModTabs.TAB_STEVES_METEORS_CREATIVE_TAB);
	public static final RegistryObject<Item> METEOR_DEFENSE_LASER = block(StevesMeteorsModBlocks.METEOR_DEFENSE_LASER, StevesMeteorsModTabs.TAB_STEVES_METEORS_CREATIVE_TAB);
	public static final RegistryObject<Item> METEORIC_ROCK = block(StevesMeteorsModBlocks.METEORIC_ROCK, StevesMeteorsModTabs.TAB_STEVES_METEORS_CREATIVE_TAB);
	public static final RegistryObject<Item> NETHER_METEOR = REGISTRY.register("nether_meteor", () -> new NetherMeteorItem());
	public static final RegistryObject<Item> METEORITE_CHUNK = REGISTRY.register("meteorite_chunk", () -> new MeteoriteChunkItem());
	public static final RegistryObject<Item> LARGE_METEORITE_CHUNK = REGISTRY.register("large_meteorite_chunk", () -> new LargeMeteoriteChunkItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
