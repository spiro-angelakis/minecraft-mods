package net.sprvlln.stevesmeteors.procedures;

import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

public class MeteorFallingEventProcedure {
	public static void execute() {
		boolean isLargeMeteor = false;
		double specialMeteorType = 0;
		double meteorType = 0;
		if (Math.random() >= 0.55) {
			isLargeMeteor = false;
		} else {
			isLargeMeteor = true;
		}
		specialMeteorType = Mth.nextInt(RandomSource.create(), 0, 3);
		if (specialMeteorType == 0) {
			meteorType = Mth.nextInt(RandomSource.create(), 0, 8);
		} else if (specialMeteorType == 1) {
			meteorType = Mth.nextInt(RandomSource.create(), 0, 2);
		} else if (specialMeteorType == 2) {
			meteorType = Mth.nextInt(RandomSource.create(), 0, 1);
		} else {
			meteorType = 0;
		}
		if (Mth.nextInt(RandomSource.create(), 0, 3) == 0) {
			specialMeteorType = 0;
			meteorType = Mth.nextInt(RandomSource.create(), 0, 8);
		}
		if (isLargeMeteor == false) {
			if (specialMeteorType == 0) {
				if (meteorType == 0) {
				} else if (meteorType == 1) {
				} else if (meteorType == 2) {
				} else if (meteorType == 3) {
				} else if (meteorType == 4) {
				} else if (meteorType == 5) {
				} else if (meteorType == 6) {
				} else if (meteorType == 7) {
				} else {
				}
			} else if (specialMeteorType == 1) {
				if (meteorType == 0) {
				} else if (meteorType == 1) {
				} else if (meteorType == 2) {
				}
			} else if (specialMeteorType == 2) {
				if (meteorType == 0) {
				} else if (meteorType == 1) {
				}
			} else {
			}
		} else {
			if (specialMeteorType == 0) {
				if (meteorType == 0) {
				} else if (meteorType == 1) {
				} else if (meteorType == 2) {
				} else if (meteorType == 3) {
				} else if (meteorType == 4) {
				} else if (meteorType == 5) {
				} else if (meteorType == 6) {
				} else if (meteorType == 7) {
				} else {
				}
			} else if (specialMeteorType == 1) {
				if (meteorType == 0) {
				} else if (meteorType == 1) {
				} else if (meteorType == 2) {
				}
			} else if (specialMeteorType == 2) {
				if (meteorType == 0) {
				} else if (meteorType == 1) {
				}
			} else {
			}
		}
	}
}
