package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.init.StevesMeteorsModBlocks;

import net.minecraftforge.fml.loading.FMLPaths;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.nbt.NbtUtils;

import java.io.IOException;
import java.io.FileWriter;
import java.io.File;

import com.google.gson.GsonBuilder;
import com.google.gson.Gson;

public class MeteorTypesSetupProcedure {
	public static void execute() {
		File meteor_types_file = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		meteor_types_file = new File((FMLPaths.GAMEDIR.get().toString() + "/config/sprvlln/steves-meteors/"), File.separator + "sm_meteor_types.json");
		if (!meteor_types_file.exists()) {
			try {
				meteor_types_file.getParentFile().mkdirs();
				meteor_types_file.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			main_json_object.addProperty("meteor_1_stone_block", NbtUtils.writeBlockState(Blocks.STONE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_1_ore_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_1_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_2_stone_block", NbtUtils.writeBlockState(Blocks.STONE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_2_ore_block", NbtUtils.writeBlockState(Blocks.LAVA.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_2_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_3_stone_block", NbtUtils.writeBlockState(Blocks.STONE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_3_ore_block", NbtUtils.writeBlockState(Blocks.COAL_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_3_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_4_stone_block", NbtUtils.writeBlockState(Blocks.STONE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_4_ore_block", NbtUtils.writeBlockState(Blocks.COPPER_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_4_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_5_stone_block", NbtUtils.writeBlockState(Blocks.STONE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_5_ore_block", NbtUtils.writeBlockState(Blocks.IRON_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_5_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_6_stone_block", NbtUtils.writeBlockState(Blocks.STONE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_6_ore_block", NbtUtils.writeBlockState(Blocks.GOLD_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_6_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_7_stone_block", NbtUtils.writeBlockState(Blocks.STONE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_7_ore_block", NbtUtils.writeBlockState(Blocks.LAPIS_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_7_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_8_stone_block", NbtUtils.writeBlockState(Blocks.STONE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_8_ore_block", NbtUtils.writeBlockState(Blocks.EMERALD_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_8_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_9_stone_block", NbtUtils.writeBlockState(Blocks.STONE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_9_ore_block", NbtUtils.writeBlockState(Blocks.DIAMOND_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_9_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_10_stone_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_10_ore_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_10_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_11_stone_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_11_ore_block", NbtUtils.writeBlockState(Blocks.LAVA.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_11_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_12_stone_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_12_ore_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE_COAL_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_12_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_13_stone_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_13_ore_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE_COPPER_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_13_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_14_stone_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_14_ore_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE_IRON_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_14_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_15_stone_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_15_ore_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE_GOLD_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_15_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_16_stone_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_16_ore_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE_LAPIS_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_16_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_17_stone_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_17_ore_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE_EMERALD_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_17_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_18_stone_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_18_ore_block", NbtUtils.writeBlockState(Blocks.DEEPSLATE_DIAMOND_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_18_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_19_stone_block", NbtUtils.writeBlockState(Blocks.NETHERRACK.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_19_ore_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_19_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_20_stone_block", NbtUtils.writeBlockState(Blocks.NETHERRACK.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_20_ore_block", NbtUtils.writeBlockState(Blocks.LAVA.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_20_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_21_stone_block", NbtUtils.writeBlockState(Blocks.NETHERRACK.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_21_ore_block", NbtUtils.writeBlockState(Blocks.NETHER_QUARTZ_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_21_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_22_stone_block", NbtUtils.writeBlockState(Blocks.NETHERRACK.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_22_ore_block", NbtUtils.writeBlockState(Blocks.NETHER_GOLD_ORE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_22_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_23_stone_block", NbtUtils.writeBlockState(Blocks.STONE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_23_ore_block", NbtUtils.writeBlockState(Blocks.ICE.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_23_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_24_stone_block", NbtUtils.writeBlockState(Blocks.MAGMA_BLOCK.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_24_ore_block", NbtUtils.writeBlockState(Blocks.LAVA.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_24_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_25_stone_block", NbtUtils.writeBlockState(Blocks.OBSIDIAN.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_25_ore_block", NbtUtils.writeBlockState(Blocks.CRYING_OBSIDIAN.defaultBlockState()).getAsString());
			main_json_object.addProperty("meteor_25_rock_block", NbtUtils.writeBlockState(StevesMeteorsModBlocks.METEORIC_ROCK.get().defaultBlockState()).getAsString());
			{
				Gson mainGSONBuilderVariable = new GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(meteor_types_file);
					fileWriter.write(mainGSONBuilderVariable.toJson(main_json_object));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		}
	}
}
