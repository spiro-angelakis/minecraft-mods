package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

public class MeteorLandedProcedure {
	public static void execute(LevelAccessor world) {
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null,
						new BlockPos(StevesMeteorsModVariables.MapVariables.get(world).meteorX,
								world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorX, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorZ),
								StevesMeteorsModVariables.MapVariables.get(world).meteorZ),
						ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("steves_meteors:meteor_crash")), SoundSource.AMBIENT, 5, 1);
			} else {
				_level.playLocalSound(StevesMeteorsModVariables.MapVariables.get(world).meteorX,
						(world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorX, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorZ)),
						StevesMeteorsModVariables.MapVariables.get(world).meteorZ, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("steves_meteors:meteor_crash")), SoundSource.AMBIENT, 5, 1, false);
			}
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null,
						new BlockPos(StevesMeteorsModVariables.MapVariables.get(world).meteorX,
								world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorX, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorZ),
								StevesMeteorsModVariables.MapVariables.get(world).meteorZ),
						ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.explode")), SoundSource.BLOCKS, 5, 1);
			} else {
				_level.playLocalSound(StevesMeteorsModVariables.MapVariables.get(world).meteorX,
						(world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorX, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorZ)),
						StevesMeteorsModVariables.MapVariables.get(world).meteorZ, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.explode")), SoundSource.BLOCKS, 5, 1, false);
			}
		}
		StevesMeteorsModVariables.MapVariables.get(world).meteorTime = 0;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).meteorX = 0;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).meteorZ = 0;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).meteorBlocked = false;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).targetPlayerName = "";
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).meteorIncoming = false;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).meteorEventProcess = false;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).forceMeteorEvent = false;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
	}
}
