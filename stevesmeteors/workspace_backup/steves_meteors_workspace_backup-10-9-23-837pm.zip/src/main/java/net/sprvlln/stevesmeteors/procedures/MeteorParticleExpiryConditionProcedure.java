package net.sprvlln.stevesmeteors.procedures;

public class MeteorParticleExpiryConditionProcedure {
	public static boolean execute(boolean onGround) {
		if (onGround == true) {
			return true;
		}
		return false;
	}
}
