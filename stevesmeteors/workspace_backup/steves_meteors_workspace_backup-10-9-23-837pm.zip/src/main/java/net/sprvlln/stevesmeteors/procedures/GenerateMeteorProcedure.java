package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.ArrayList;

public class GenerateMeteorProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double meteor_type = 0;
		BlockState rock_block = Blocks.AIR.defaultBlockState();
		BlockState ore_block = Blocks.AIR.defaultBlockState();
		BlockState stone_block = Blocks.AIR.defaultBlockState();
		List<Object> meteor_data = new ArrayList<>();
		meteor_type = Mth.nextInt(RandomSource.create(), 1, (int) StevesMeteorsModVariables.MapVariables.get(world).meteor_types_to_use);
		meteor_data = (ArrayList) StevesMeteorsModVariables.meteor_types_array.get((int) (meteor_type - 1));
		stone_block = meteor_data.get(0) instanceof BlockState _bs ? _bs : Blocks.AIR.defaultBlockState();
		ore_block = meteor_data.get(1) instanceof BlockState _bs ? _bs : Blocks.AIR.defaultBlockState();
		rock_block = meteor_data.get(2) instanceof BlockState _bs ? _bs : Blocks.AIR.defaultBlockState();
		StevesMeteorsModVariables.WorldVariables.get(world).meteor_rock_block = rock_block;
		StevesMeteorsModVariables.WorldVariables.get(world).syncData(world);
		StevesMeteorsModVariables.WorldVariables.get(world).meteor_stone_block = stone_block;
		StevesMeteorsModVariables.WorldVariables.get(world).syncData(world);
		StevesMeteorsModVariables.WorldVariables.get(world).meteor_ore_block = ore_block;
		StevesMeteorsModVariables.WorldVariables.get(world).syncData(world);
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null,
						new BlockPos(StevesMeteorsModVariables.MapVariables.get(world).meteorX,
								world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorX, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorZ),
								StevesMeteorsModVariables.MapVariables.get(world).meteorZ),
						ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("steves_meteors:meteor_crash")), SoundSource.AMBIENT, 5, 1);
			} else {
				_level.playLocalSound(StevesMeteorsModVariables.MapVariables.get(world).meteorX,
						(world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorX, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorZ)),
						StevesMeteorsModVariables.MapVariables.get(world).meteorZ, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("steves_meteors:meteor_crash")), SoundSource.AMBIENT, 5, 1, false);
			}
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null,
						new BlockPos(StevesMeteorsModVariables.MapVariables.get(world).meteorX,
								world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorX, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorZ),
								StevesMeteorsModVariables.MapVariables.get(world).meteorZ),
						ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.explode")), SoundSource.BLOCKS, 5, 1);
			} else {
				_level.playLocalSound(StevesMeteorsModVariables.MapVariables.get(world).meteorX,
						(world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorX, (int) StevesMeteorsModVariables.MapVariables.get(world).meteorZ)),
						StevesMeteorsModVariables.MapVariables.get(world).meteorZ, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.explode")), SoundSource.BLOCKS, 5, 1, false);
			}
		}
		if (Math.random() <= StevesMeteorsModVariables.MapVariables.get(world).large_to_small_meteor_spawn_ratio) {
			CreateLargeMeteorProcedure.execute(world, x, y, z);
		} else {
			CreateSmallMeteorProcedure.execute(world, x, y, z);
		}
		StevesMeteorsModVariables.MapVariables.get(world).meteorTime = 0;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).meteorX = 0;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).meteorZ = 0;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).meteorBlocked = false;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).targetPlayerName = "";
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).meteorIncoming = false;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).meteorEventProcess = false;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		StevesMeteorsModVariables.MapVariables.get(world).forceMeteorEvent = false;
		StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
	}
}
