package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import javax.annotation.Nullable;

import java.io.File;

@Mod.EventBusSubscriber
public class ActiveMeteorsWorldTickProcedure {
	@SubscribeEvent
	public static void onWorldTick(TickEvent.LevelTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.level);
		}
	}

	public static void execute(LevelAccessor world) {
		execute(null, world);
	}

	private static void execute(@Nullable Event event, LevelAccessor world) {
		Entity playerTarget = null;
		File steves_meteors_config = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		double playerI = 0;
		double playerNum = 0;
		double meteor_event_chance_out_of = 0;
		boolean pickedPlayer = false;
		boolean processNewMeteor = false;
		boolean validWorld = false;
		boolean onlyEarth = false;
		StevesMeteorsModVariables.WorldVariables.get(world).ticks_since_meteor_chance = StevesMeteorsModVariables.WorldVariables.get(world).ticks_since_meteor_chance + 1;
		StevesMeteorsModVariables.WorldVariables.get(world).syncData(world);
		if (StevesMeteorsModVariables.WorldVariables.get(world).ticks_since_meteor_chance >= StevesMeteorsModVariables.MapVariables.get(world).minutes_between_meteor_chance * 20) {
			StevesMeteorsModVariables.WorldVariables.get(world).ticks_since_meteor_chance = 0;
			StevesMeteorsModVariables.WorldVariables.get(world).syncData(world);
			MeteorEventChanceProcedure.execute(world);
		} else {
			if (StevesMeteorsModVariables.MapVariables.get(world).forceMeteorEvent == true) {
				StevesMeteorsModVariables.WorldVariables.get(world).ticks_since_meteor_chance = 0;
				StevesMeteorsModVariables.WorldVariables.get(world).syncData(world);
				MeteorEventChanceProcedure.execute(world);
			}
		}
	}
}
