
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesmeteors.init;

import net.sprvlln.stevesmeteors.StevesMeteorsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

public class StevesMeteorsModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, StevesMeteorsMod.MODID);
	public static final RegistryObject<SoundEvent> METEOR_FALLING = REGISTRY.register("meteor_falling", () -> new SoundEvent(new ResourceLocation("steves_meteors", "meteor_falling")));
	public static final RegistryObject<SoundEvent> METEOR_CRASH = REGISTRY.register("meteor_crash", () -> new SoundEvent(new ResourceLocation("steves_meteors", "meteor_crash")));
	public static final RegistryObject<SoundEvent> METEOR_LASER_FIRE = REGISTRY.register("meteor_laser_fire", () -> new SoundEvent(new ResourceLocation("steves_meteors", "meteor_laser_fire")));
	public static final RegistryObject<SoundEvent> METEOR_TRACKING_PC_ALERT = REGISTRY.register("meteor_tracking_pc_alert", () -> new SoundEvent(new ResourceLocation("steves_meteors", "meteor_tracking_pc_alert")));
}
