package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;

import net.minecraftforge.fml.loading.FMLPaths;

import net.minecraft.world.level.LevelAccessor;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

public class SetupConfigVariablesProcedure {
	public static void execute(LevelAccessor world) {
		File steves_meteors_config = new File("");
		com.google.gson.JsonObject main_json = new com.google.gson.JsonObject();
		steves_meteors_config = new File((FMLPaths.GAMEDIR.get().toString() + "/config/sprvlln/steves-meteors/"), File.separator + "steves-meteors-common.json");
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(steves_meteors_config));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				main_json = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				StevesMeteorsModVariables.MapVariables.get(world).allow_meteor_worldgen = main_json.get("allow_meteor_worldgen").getAsBoolean();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).allow_meteor_events = main_json.get("allow_meteor_events").getAsBoolean();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).defenseLaserNeedsPower = main_json.get("meteor_defense_laser_does_need_power").getAsBoolean();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).trackingPcNeedsPower = main_json.get("meteor_tracking_pc_does_need_power").getAsBoolean();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).meteor_types_to_use = main_json.get("max_meteor_types").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).large_to_small_meteor_spawn_ratio = main_json.get("large_to_small_meteor_spawn_ratio").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).meteor_dist_from_player = main_json.get("meteor_distance_from_player").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).meteoric_rock_to_other_ratio = main_json.get("meteoric_rock_to_other_ratio").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).minutes_between_meteor_chance = main_json.get("seconds_between_meteor_chance").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).FallingEventChanceOutOf = main_json.get("meteor_falling_event_chance_out_of").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).small_meteor_min_size = main_json.get("small_meteor_min_size").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).small_meteor_max_size = main_json.get("small_meteor_max_size").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).small_meteor_crater_mod = main_json.get("small_meteor_crater_mod").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).large_meteor_min_size = main_json.get("large_meteor_min_size").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).large_meteor_max_size = main_json.get("large_meteor_max_size").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).large_meteor_crater_mod = main_json.get("large_meteor_crater_mod").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).stone_to_ore_ratio = main_json.get("stone_to_ore_ratio").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).ice_to_stone_ratio = main_json.get("ice_to_stone_ratio").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).rock_to_lava_ratio = main_json.get("rock_to_lava_ratio").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).max_fires = main_json.get("max_fires").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).max_subcraters = main_json.get("max_subcraters").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).defense_laser_reach = main_json.get("meteor_defense_laser_reach").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).defense_laser_local_chat_reach = main_json.get("meteor_defense_laser_local_chat_reach").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).monitor_local_chat_reach = main_json.get("meteor_tracking_pc_local_chat_reach").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).monitor_reach = main_json.get("meteor_tracking_pc_reach").getAsDouble();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).allow_laser_chat_local = main_json.get("allow_meteor_laser_chat_local").getAsBoolean();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).allow_laser_chat_global = main_json.get("allow_meteor_laser_chat_global").getAsBoolean();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).AllowForceEventCommand = main_json.get("allow_force_meteor_event_command").getAsBoolean();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				StevesMeteorsModVariables.MapVariables.get(world).EventOnlyOnEarth = main_json.get("meteor_event_only_on_earth").getAsBoolean();
				StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
