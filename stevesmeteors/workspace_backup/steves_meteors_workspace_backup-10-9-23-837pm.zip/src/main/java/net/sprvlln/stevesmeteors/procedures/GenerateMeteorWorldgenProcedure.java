package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import java.util.List;
import java.util.ArrayList;

public class GenerateMeteorWorldgenProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double meteor_type = 0;
		BlockState rock_block = Blocks.AIR.defaultBlockState();
		BlockState ore_block = Blocks.AIR.defaultBlockState();
		BlockState stone_block = Blocks.AIR.defaultBlockState();
		List<Object> meteor_data = new ArrayList<>();
		meteor_type = Mth.nextInt(RandomSource.create(), 1, (int) StevesMeteorsModVariables.MapVariables.get(world).meteor_types_to_use);
		meteor_data = (ArrayList) StevesMeteorsModVariables.meteor_types_array.get((int) (meteor_type - 1));
		stone_block = meteor_data.get(0) instanceof BlockState _bs ? _bs : Blocks.AIR.defaultBlockState();
		ore_block = meteor_data.get(1) instanceof BlockState _bs ? _bs : Blocks.AIR.defaultBlockState();
		rock_block = meteor_data.get(2) instanceof BlockState _bs ? _bs : Blocks.AIR.defaultBlockState();
		StevesMeteorsModVariables.WorldVariables.get(world).meteor_rock_block = rock_block;
		StevesMeteorsModVariables.WorldVariables.get(world).syncData(world);
		StevesMeteorsModVariables.WorldVariables.get(world).meteor_stone_block = stone_block;
		StevesMeteorsModVariables.WorldVariables.get(world).syncData(world);
		StevesMeteorsModVariables.WorldVariables.get(world).meteor_ore_block = ore_block;
		StevesMeteorsModVariables.WorldVariables.get(world).syncData(world);
		if (Math.random() <= StevesMeteorsModVariables.MapVariables.get(world).large_to_small_meteor_spawn_ratio) {
			CreateLargeMeteorProcedure.execute(world, x, y, z);
		} else {
			CreateSmallMeteorProcedure.execute(world, x, y, z);
		}
	}
}
