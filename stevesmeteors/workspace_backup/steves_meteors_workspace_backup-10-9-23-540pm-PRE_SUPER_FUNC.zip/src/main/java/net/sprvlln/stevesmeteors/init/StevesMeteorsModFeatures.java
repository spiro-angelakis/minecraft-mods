
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesmeteors.init;

import net.sprvlln.stevesmeteors.world.features.MeteorWorldGenBlockStructureFeature;
import net.sprvlln.stevesmeteors.StevesMeteorsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

@Mod.EventBusSubscriber
public class StevesMeteorsModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, StevesMeteorsMod.MODID);
	public static final RegistryObject<Feature<?>> METEOR_WORLD_GEN_BLOCK_STRUCTURE = REGISTRY.register("meteor_world_gen_block_structure", MeteorWorldGenBlockStructureFeature::feature);
}
