
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesmeteors.init;

import net.sprvlln.stevesmeteors.block.entity.MeteorDetectorComputerBlockEntity;
import net.sprvlln.stevesmeteors.block.entity.MeteorDefenseLaserBlockEntity;
import net.sprvlln.stevesmeteors.StevesMeteorsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

public class StevesMeteorsModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, StevesMeteorsMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> METEOR_DETECTOR_COMPUTER = register("meteor_detector_computer", StevesMeteorsModBlocks.METEOR_DETECTOR_COMPUTER, MeteorDetectorComputerBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> METEOR_DEFENSE_LASER = register("meteor_defense_laser", StevesMeteorsModBlocks.METEOR_DEFENSE_LASER, MeteorDefenseLaserBlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
