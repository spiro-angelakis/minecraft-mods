package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;
import net.sprvlln.stevesmeteors.entity.MeteorIncomingEntityEntity;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import java.util.stream.Collectors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.List;
import java.util.Comparator;

import java.io.File;

public class MeteorDetectorComputerUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		File steves_meteors_config = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		if (StevesMeteorsModVariables.MapVariables.get(world).trackingPcNeedsPower == true) {
			if (new Object() {
				public int getEnergyStored(LevelAccessor level, BlockPos pos) {
					AtomicInteger _retval = new AtomicInteger(0);
					BlockEntity _ent = level.getBlockEntity(pos);
					if (_ent != null)
						_ent.getCapability(ForgeCapabilities.ENERGY, null).ifPresent(capability -> _retval.set(capability.getEnergyStored()));
					return _retval.get();
				}
			}.getEnergyStored(world, new BlockPos(x, y, z)) >= 100) {
				if (new Object() {
					public double getValue(LevelAccessor world, BlockPos pos, String tag) {
						BlockEntity blockEntity = world.getBlockEntity(pos);
						if (blockEntity != null)
							return blockEntity.getPersistentData().getDouble(tag);
						return -1;
					}
				}.getValue(world, new BlockPos(x, y, z), "cooldown") <= 0) {
					if (!world.getEntitiesOfClass(MeteorIncomingEntityEntity.class, AABB.ofSize(new Vec3(x, 300, z), StevesMeteorsModVariables.MapVariables.get(world).monitor_reach, StevesMeteorsModVariables.MapVariables.get(world).monitor_reach,
							StevesMeteorsModVariables.MapVariables.get(world).monitor_reach), e -> true).isEmpty() == true) {
						if (((Entity) world.getEntitiesOfClass(MeteorIncomingEntityEntity.class, AABB.ofSize(new Vec3(x, 300, z), StevesMeteorsModVariables.MapVariables.get(world).monitor_reach,
								StevesMeteorsModVariables.MapVariables.get(world).monitor_reach, StevesMeteorsModVariables.MapVariables.get(world).monitor_reach), e -> true).stream().sorted(new Object() {
									Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
										return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
									}
								}.compareDistOf(x, 300, z)).findFirst().orElse(null)).getPersistentData().getBoolean("bombEnabled") == true) {
							if (!world.isClientSide()) {
								BlockPos _bp = new BlockPos(x, y, z);
								BlockEntity _blockEntity = world.getBlockEntity(_bp);
								BlockState _bs = world.getBlockState(_bp);
								if (_blockEntity != null)
									_blockEntity.getPersistentData().putDouble("cooldown", 400);
								if (world instanceof Level _level)
									_level.sendBlockUpdated(_bp, _bs, _bs, 3);
							}
							{
								BlockEntity _ent = world.getBlockEntity(new BlockPos(x, y, z));
								int _amount = 100;
								if (_ent != null)
									_ent.getCapability(ForgeCapabilities.ENERGY, null).ifPresent(capability -> capability.extractEnergy(_amount, false));
							}
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("steves_meteors:meteor_tracking_pc_alert")), SoundSource.BLOCKS, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("steves_meteors:meteor_tracking_pc_alert")), SoundSource.BLOCKS, 1, 1, false);
								}
							}
							{
								final Vec3 _center = new Vec3(x, y, z);
								List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(StevesMeteorsModVariables.MapVariables.get(world).monitor_local_chat_reach / 2d), e -> true).stream()
										.sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
								for (Entity entityiterator : _entfound) {
									if (entityiterator instanceof ServerPlayer || entityiterator instanceof Player) {
										if (entityiterator instanceof Player _player && !_player.level.isClientSide())
											_player.displayClientMessage(Component.literal(("WARNING! Meteor Incoming at: " + "X : " + new java.text.DecimalFormat("##.##").format(StevesMeteorsModVariables.MapVariables.get(world).meteorX) + " "
													+ "Z : " + new java.text.DecimalFormat("##.##").format(StevesMeteorsModVariables.MapVariables.get(world).meteorZ))), false);
									}
								}
							}
						}
					}
				} else {
					if (!world.isClientSide()) {
						BlockPos _bp = new BlockPos(x, y, z);
						BlockEntity _blockEntity = world.getBlockEntity(_bp);
						BlockState _bs = world.getBlockState(_bp);
						if (_blockEntity != null)
							_blockEntity.getPersistentData().putDouble("cooldown", ((new Object() {
								public double getValue(LevelAccessor world, BlockPos pos, String tag) {
									BlockEntity blockEntity = world.getBlockEntity(pos);
									if (blockEntity != null)
										return blockEntity.getPersistentData().getDouble(tag);
									return -1;
								}
							}.getValue(world, new BlockPos(x, y, z), "cooldown")) - 1));
						if (world instanceof Level _level)
							_level.sendBlockUpdated(_bp, _bs, _bs, 3);
					}
				}
			}
		} else {
			if (new Object() {
				public double getValue(LevelAccessor world, BlockPos pos, String tag) {
					BlockEntity blockEntity = world.getBlockEntity(pos);
					if (blockEntity != null)
						return blockEntity.getPersistentData().getDouble(tag);
					return -1;
				}
			}.getValue(world, new BlockPos(x, y, z), "cooldown") <= 0) {
				if (!world.getEntitiesOfClass(MeteorIncomingEntityEntity.class, AABB.ofSize(new Vec3(x, 300, z), StevesMeteorsModVariables.MapVariables.get(world).monitor_reach, StevesMeteorsModVariables.MapVariables.get(world).monitor_reach,
						StevesMeteorsModVariables.MapVariables.get(world).monitor_reach), e -> true).isEmpty() == true) {
					if (((Entity) world.getEntitiesOfClass(MeteorIncomingEntityEntity.class, AABB.ofSize(new Vec3(x, 300, z), StevesMeteorsModVariables.MapVariables.get(world).monitor_reach,
							StevesMeteorsModVariables.MapVariables.get(world).monitor_reach, StevesMeteorsModVariables.MapVariables.get(world).monitor_reach), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, 300, z)).findFirst().orElse(null)).getPersistentData().getBoolean("bombEnabled") == true) {
						if (!world.isClientSide()) {
							BlockPos _bp = new BlockPos(x, y, z);
							BlockEntity _blockEntity = world.getBlockEntity(_bp);
							BlockState _bs = world.getBlockState(_bp);
							if (_blockEntity != null)
								_blockEntity.getPersistentData().putDouble("cooldown", 400);
							if (world instanceof Level _level)
								_level.sendBlockUpdated(_bp, _bs, _bs, 3);
						}
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("steves_meteors:meteor_tracking_pc_alert")), SoundSource.BLOCKS, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("steves_meteors:meteor_tracking_pc_alert")), SoundSource.BLOCKS, 1, 1, false);
							}
						}
						{
							final Vec3 _center = new Vec3(x, y, z);
							List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(StevesMeteorsModVariables.MapVariables.get(world).monitor_local_chat_reach / 2d), e -> true).stream()
									.sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
							for (Entity entityiterator : _entfound) {
								if (entityiterator instanceof ServerPlayer || entityiterator instanceof Player) {
									if (entityiterator instanceof Player _player && !_player.level.isClientSide())
										_player.displayClientMessage(Component.literal(("WARNING! Meteor Incoming at: " + "X : " + new java.text.DecimalFormat("##.##").format(StevesMeteorsModVariables.MapVariables.get(world).meteorX) + " " + "Z : "
												+ new java.text.DecimalFormat("##.##").format(StevesMeteorsModVariables.MapVariables.get(world).meteorZ))), false);
								}
							}
						}
					}
				}
			} else {
				if (!world.isClientSide()) {
					BlockPos _bp = new BlockPos(x, y, z);
					BlockEntity _blockEntity = world.getBlockEntity(_bp);
					BlockState _bs = world.getBlockState(_bp);
					if (_blockEntity != null)
						_blockEntity.getPersistentData().putDouble("cooldown", ((new Object() {
							public double getValue(LevelAccessor world, BlockPos pos, String tag) {
								BlockEntity blockEntity = world.getBlockEntity(pos);
								if (blockEntity != null)
									return blockEntity.getPersistentData().getDouble(tag);
								return -1;
							}
						}.getValue(world, new BlockPos(x, y, z), "cooldown")) - 1));
					if (world instanceof Level _level)
						_level.sendBlockUpdated(_bp, _bs, _bs, 3);
				}
			}
		}
	}
}
