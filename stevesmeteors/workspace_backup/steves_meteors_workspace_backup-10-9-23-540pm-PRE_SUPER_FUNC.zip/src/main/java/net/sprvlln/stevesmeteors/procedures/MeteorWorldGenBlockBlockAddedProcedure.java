package net.sprvlln.stevesmeteors.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

public class MeteorWorldGenBlockBlockAddedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		boolean isLargeMeteor = false;
		double specialMeteorType = 0;
		double meteorType = 0;
		if (Math.random() >= 0.55) {
			isLargeMeteor = false;
		} else {
			isLargeMeteor = true;
		}
		specialMeteorType = Mth.nextInt(RandomSource.create(), 0, 5);
		if (specialMeteorType <= 2) {
			meteorType = Mth.nextInt(RandomSource.create(), 0, 8);
		} else if (specialMeteorType == 3) {
			meteorType = Mth.nextInt(RandomSource.create(), 0, 2);
		} else if (specialMeteorType == 4) {
			meteorType = Mth.nextInt(RandomSource.create(), 0, 1);
		} else {
			meteorType = 0;
		}
		if (isLargeMeteor == false) {
			if (specialMeteorType == 0) {
				if (meteorType == 0) {
					SmallStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 1) {
					SmallLavaStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 2) {
					SmallCoalStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 3) {
					SmallIronStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 4) {
					SmallCopperStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 5) {
					SmallGoldStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 6) {
					SmallLapisStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 7) {
					SmallEmeraldStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else {
					SmallDiamondStoneMeteorCreationProcedure.execute(world, x, y, z);
				}
			} else if (specialMeteorType == 1) {
				if (meteorType == 0) {
					SmallNetherMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 1) {
					SmallLavaNetherMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 2) {
					SmallGoldNetherMeteorCreationProcedure.execute(world, x, y, z);
				}
			} else if (specialMeteorType == 2) {
				if (meteorType == 0) {
					SmallObsidianMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 1) {
					SmallLavaObsidianMeteorCreationProcedure.execute(world, x, y, z);
				}
			} else {
				SmallIceMeteorCreationProcedure.execute(world, x, y, z);
			}
		} else {
			if (specialMeteorType == 0) {
				if (meteorType == 0) {
					LargeStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 1) {
					LargeLavaStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 2) {
					LargeCoalStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 3) {
					LargeIronStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 4) {
					LargeCopperStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 5) {
					LargeGoldStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 6) {
					LargeLapisStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 7) {
					LargeEmeraldStoneMeteorCreationProcedure.execute(world, x, y, z);
				} else {
					LargeDiamondStoneMeteorCreationProcedure.execute(world, x, y, z);
				}
			} else if (specialMeteorType == 1) {
				if (meteorType == 0) {
					LargeNetherMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 1) {
					LargeLavaNetherMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 2) {
					LargeGoldNetherMeteorCreationProcedure.execute(world, x, y, z);
				}
			} else if (specialMeteorType == 2) {
				if (meteorType == 0) {
					LargeObsidianMeteorCreationProcedure.execute(world, x, y, z);
				} else if (meteorType == 1) {
					LargeLavaObsidianMeteorCreationProcedure.execute(world, x, y, z);
				}
			} else {
				LargeIceMeteorCreationProcedure.execute(world, x, y, z);
			}
		}
	}
}
