package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;

import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.BlockPos;

import java.util.Map;

public class SmallLavaNetherMeteorCreationProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		boolean createMeteor = false;
		double meteorCubeSize = 0;
		double fireChance = 0;
		double fires = 0;
		createMeteor = true;
		fires = 0;
		meteorCubeSize = Mth.nextInt(RandomSource.create(), (int) StevesMeteorsModVariables.MapVariables.get(world).small_meteor_min_size, (int) StevesMeteorsModVariables.MapVariables.get(world).small_meteor_max_size);
		fireChance = Mth.nextDouble(RandomSource.create(), 0.15, 0.25);
		if (createMeteor == true) {
			int horizontalRadiusSphere = (int) (meteorCubeSize * StevesMeteorsModVariables.MapVariables.get(world).small_meteor_crater_mod) - 1;
			int verticalRadiusSphere = (int) meteorCubeSize - 1;
			int yIterationsSphere = verticalRadiusSphere;
			for (int i = -yIterationsSphere; i <= yIterationsSphere; i++) {
				for (int xi = -horizontalRadiusSphere; xi <= horizontalRadiusSphere; xi++) {
					for (int zi = -horizontalRadiusSphere; zi <= horizontalRadiusSphere; zi++) {
						double distanceSq = (xi * xi) / (double) (horizontalRadiusSphere * horizontalRadiusSphere) + (i * i) / (double) (verticalRadiusSphere * verticalRadiusSphere)
								+ (zi * zi) / (double) (horizontalRadiusSphere * horizontalRadiusSphere);
						if (distanceSq <= 1.0) {
							{
								BlockPos _bp = new BlockPos(x + xi, y + i, z + zi);
								BlockState _bs = Blocks.AIR.defaultBlockState();
								BlockState _bso = world.getBlockState(_bp);
								for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
									Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
									if (_property != null && _bs.getValue(_property) != null)
										try {
											_bs = _bs.setValue(_property, (Comparable) entry.getValue());
										} catch (Exception e) {
										}
								}
								world.setBlock(_bp, _bs, 3);
							}
						}
					}
				}
			}
		}
		if (createMeteor == true) {
			int horizontalRadiusSphere = (int) meteorCubeSize - 1;
			int verticalRadiusSphere = (int) meteorCubeSize - 1;
			int yIterationsSphere = verticalRadiusSphere;
			for (int i = -yIterationsSphere; i <= yIterationsSphere; i++) {
				for (int xi = -horizontalRadiusSphere; xi <= horizontalRadiusSphere; xi++) {
					for (int zi = -horizontalRadiusSphere; zi <= horizontalRadiusSphere; zi++) {
						double distanceSq = (xi * xi) / (double) (horizontalRadiusSphere * horizontalRadiusSphere) + (i * i) / (double) (verticalRadiusSphere * verticalRadiusSphere)
								+ (zi * zi) / (double) (horizontalRadiusSphere * horizontalRadiusSphere);
						if (distanceSq <= 1.0) {
							if (Math.random() >= StevesMeteorsModVariables.MapVariables.get(world).rock_to_lava_ratio) {
								{
									BlockPos _bp = new BlockPos(x + xi, y + i - meteorCubeSize / 2, z + zi);
									BlockState _bs = Blocks.LAVA.defaultBlockState();
									BlockState _bso = world.getBlockState(_bp);
									for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
										Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
										if (_property != null && _bs.getValue(_property) != null)
											try {
												_bs = _bs.setValue(_property, (Comparable) entry.getValue());
											} catch (Exception e) {
											}
									}
									world.setBlock(_bp, _bs, 3);
								}
							} else {
								{
									BlockPos _bp = new BlockPos(x + xi, y + i - meteorCubeSize / 2, z + zi);
									BlockState _bs = Blocks.NETHERRACK.defaultBlockState();
									BlockState _bso = world.getBlockState(_bp);
									for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
										Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
										if (_property != null && _bs.getValue(_property) != null)
											try {
												_bs = _bs.setValue(_property, (Comparable) entry.getValue());
											} catch (Exception e) {
											}
									}
									world.setBlock(_bp, _bs, 3);
								}
							}
						}
					}
				}
			}
		}
		if (createMeteor == true) {
			int horizontalRadiusSphere = (int) (meteorCubeSize * StevesMeteorsModVariables.MapVariables.get(world).small_meteor_crater_mod + 8) - 1;
			int verticalRadiusSphere = (int) (meteorCubeSize * StevesMeteorsModVariables.MapVariables.get(world).small_meteor_crater_mod + 8) - 1;
			int yIterationsSphere = verticalRadiusSphere;
			for (int i = -yIterationsSphere; i <= yIterationsSphere; i++) {
				for (int xi = -horizontalRadiusSphere; xi <= horizontalRadiusSphere; xi++) {
					for (int zi = -horizontalRadiusSphere; zi <= horizontalRadiusSphere; zi++) {
						double distanceSq = (xi * xi) / (double) (horizontalRadiusSphere * horizontalRadiusSphere) + (i * i) / (double) (verticalRadiusSphere * verticalRadiusSphere)
								+ (zi * zi) / (double) (horizontalRadiusSphere * horizontalRadiusSphere);
						if (distanceSq <= 1.0) {
							if (fires < StevesMeteorsModVariables.MapVariables.get(world).max_fires) {
								if (Math.random() + fireChance >= 1.1) {
									if (y + i == world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) x + xi, (int) z + zi)) {
										fires = fires + 1;
										{
											BlockPos _bp = new BlockPos(x + xi, y + i, z + zi);
											BlockState _bs = Blocks.FIRE.defaultBlockState();
											BlockState _bso = world.getBlockState(_bp);
											for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
												Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
												if (_property != null && _bs.getValue(_property) != null)
													try {
														_bs = _bs.setValue(_property, (Comparable) entry.getValue());
													} catch (Exception e) {
													}
											}
											world.setBlock(_bp, _bs, 3);
										}
									}
								}
							}
						}
					}
				}
			}
		}
		UnforceChunkLoadProcedure.execute(world, x, y, z);
	}
}
