package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;

import net.minecraft.world.level.LevelAccessor;

import java.io.File;

public class ForceMeteorEventProcedureProcedure {
	public static void execute(LevelAccessor world) {
		File steves_meteors_config = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		if (StevesMeteorsModVariables.MapVariables.get(world).AllowForceEventCommand == true) {
			StevesMeteorsModVariables.MapVariables.get(world).forceMeteorEvent = true;
			StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
		}
	}
}
