package net.sprvlln.stevesmeteors.procedures;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;

import javax.annotation.Nullable;

import java.io.IOException;
import java.io.FileWriter;
import java.io.File;

import com.google.gson.GsonBuilder;
import com.google.gson.Gson;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class StevesMeteorsConfigProcedureProcedure {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		execute();
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		File steves_meteors_config = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		steves_meteors_config = new File((FMLPaths.GAMEDIR.get().toString() + "/config/"), File.separator + "steves-meteors-config.json");
		if (!steves_meteors_config.exists()) {
			try {
				steves_meteors_config.getParentFile().mkdirs();
				steves_meteors_config.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			main_json_object.addProperty("allow_meteor_worldgen", true);
			main_json_object.addProperty("allow_meteor_events", true);
			main_json_object.addProperty("seconds_between_meteor_chance", 300);
			main_json_object.addProperty("meteor_falling_event_chance_out_of", 25);
			main_json_object.addProperty("allow_force_meteor_event_command", false);
			main_json_object.addProperty("meteor_event_only_on_earth", true);
			main_json_object.addProperty("meteor_distance_from_player", 250);
			main_json_object.addProperty("small_meteor_min_size", 2);
			main_json_object.addProperty("small_meteor_max_size", 6);
			main_json_object.addProperty("small_meteor_crater_mod", 3);
			main_json_object.addProperty("large_meteor_min_size", 10);
			main_json_object.addProperty("large_meteor_max_size", 14);
			main_json_object.addProperty("large_meteor_crater_mod", 2);
			main_json_object.addProperty("meteoric_rock_to_other_ratio", 0.25);
			main_json_object.addProperty("stone_to_ore_ratio", 0.95);
			main_json_object.addProperty("ice_to_stone_ratio", 0.6);
			main_json_object.addProperty("rock_to_lava_ratio", 0.8);
			main_json_object.addProperty("max_fires", 64);
			main_json_object.addProperty("max_subcraters", 12);
			main_json_object.addProperty("meteor_defense_laser_does_need_power", true);
			main_json_object.addProperty("meteor_defense_laser_reach", 1024);
			main_json_object.addProperty("meteor_defense_laser_local_chat_reach", 128);
			main_json_object.addProperty("meteor_tracking_pc_does_need_power", false);
			main_json_object.addProperty("meteor_tracking_pc_local_chat_reach", 128);
			main_json_object.addProperty("meteor_tracking_pc_reach", 1024);
			main_json_object.addProperty("allow_meteor_laser_chat_local", false);
			main_json_object.addProperty("allow_meteor_laser_chat_global", false);
			{
				Gson mainGSONBuilderVariable = new GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(steves_meteors_config);
					fileWriter.write(mainGSONBuilderVariable.toJson(main_json_object));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		}
	}
}
