package net.sprvlln.stevesmeteors.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

public class MeteorIncomingEntityOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putBoolean("bombEnabled", true);
		if (world instanceof ServerLevel _level)
			_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(), ("forceload add "
					+ new java.text.DecimalFormat("##.##").format(world.getChunk(new BlockPos(x, y, z)).getPos().getMinBlockX()) + " " + new java.text.DecimalFormat("##.##").format(world.getChunk(new BlockPos(x, y, z)).getPos().getMinBlockZ()) + " "
					+ new java.text.DecimalFormat("##.##").format(world.getChunk(new BlockPos(x, y, z)).getPos().getMaxBlockX()) + " " + new java.text.DecimalFormat("##.##").format(world.getChunk(new BlockPos(x, y, z)).getPos().getMaxBlockZ())));
	}
}
