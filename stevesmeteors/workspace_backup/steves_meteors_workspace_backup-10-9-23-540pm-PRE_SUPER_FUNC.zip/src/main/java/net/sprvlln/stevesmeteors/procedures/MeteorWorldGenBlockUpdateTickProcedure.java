package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;
import net.sprvlln.stevesmeteors.StevesMeteorsMod;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class MeteorWorldGenBlockUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		StevesMeteorsMod.queueServerWork(20, () -> {
			world.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 3);
			if (StevesMeteorsModVariables.MapVariables.get(world).allow_meteor_worldgen) {
				MeteorWorldGenBlockBlockAddedProcedure.execute(world, x, y, z);
			}
		});
	}
}
