package net.sprvlln.stevesmeteors.procedures;

import net.sprvlln.stevesmeteors.network.StevesMeteorsModVariables;

import net.minecraftforge.fml.loading.FMLPaths;

import net.minecraft.world.level.LevelAccessor;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

public class ForceMeteorEventProcedureProcedure {
	public static void execute(LevelAccessor world) {
		File steves_meteors_config = new File("");
		com.google.gson.JsonObject main_json_object = new com.google.gson.JsonObject();
		steves_meteors_config = new File((FMLPaths.GAMEDIR.get().toString() + "/config/"), File.separator + "steves-meteors-config.json");
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(steves_meteors_config));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				main_json_object = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				if (main_json_object.get("allow_force_meteor_event_command").getAsBoolean() == true) {
					StevesMeteorsModVariables.MapVariables.get(world).forceMeteorEvent = true;
					StevesMeteorsModVariables.MapVariables.get(world).syncData(world);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
