
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesmeteors.init;

import net.sprvlln.stevesmeteors.block.MeteorWorldGenBlockBlock;
import net.sprvlln.stevesmeteors.block.MeteorDetectorComputerBlock;
import net.sprvlln.stevesmeteors.block.MeteorDefenseLaserBlock;
import net.sprvlln.stevesmeteors.StevesMeteorsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

public class StevesMeteorsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, StevesMeteorsMod.MODID);
	public static final RegistryObject<Block> METEOR_WORLD_GEN_BLOCK = REGISTRY.register("meteor_world_gen_block", () -> new MeteorWorldGenBlockBlock());
	public static final RegistryObject<Block> METEOR_DETECTOR_COMPUTER = REGISTRY.register("meteor_detector_computer", () -> new MeteorDetectorComputerBlock());
	public static final RegistryObject<Block> METEOR_DEFENSE_LASER = REGISTRY.register("meteor_defense_laser", () -> new MeteorDefenseLaserBlock());
}
