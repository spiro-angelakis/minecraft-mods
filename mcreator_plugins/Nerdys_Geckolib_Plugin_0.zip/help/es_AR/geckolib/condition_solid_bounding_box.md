Mientras el valor devuelto es verdadero, la caja delimitadora de la entidad es sólida. 
Esta característica la utilizan, por ejemplo, los barcos.