This parameter determined in which perspectives item animations will play.
"All Perspectives" will always allow animations to play,
"First Person" will only play animations when in first person and
"Third/Second Person" will play animations only when not in first person.