Wówczas gdy zwrócona wartość jest prawidłowa, obwiednia bytu jest stała.
Z tej funkcji korzystają na przykład łodzie.


