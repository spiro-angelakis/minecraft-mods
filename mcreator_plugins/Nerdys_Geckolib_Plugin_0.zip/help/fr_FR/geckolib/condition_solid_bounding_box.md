Si la valeur renvoyée est vraie, le rectangle de délimitation de l'entité est solide. 
Cette caractéristique est utilisée par les bateaux, par exemple.