The display settings file that was exported from blockbench.
This is used to properly render the item model and is therefore required.