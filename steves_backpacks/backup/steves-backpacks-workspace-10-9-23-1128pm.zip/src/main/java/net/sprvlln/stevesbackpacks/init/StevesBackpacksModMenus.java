
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesbackpacks.init;

import net.sprvlln.stevesbackpacks.world.inventory.PaperBagGUIMenu;
import net.sprvlln.stevesbackpacks.world.inventory.LeatherBackpackGUIMenu;
import net.sprvlln.stevesbackpacks.world.inventory.IronBackpackGUIMenu;
import net.sprvlln.stevesbackpacks.world.inventory.GoldBackpackGUIMenu;
import net.sprvlln.stevesbackpacks.world.inventory.DiamondBackpackGUIMenu;
import net.sprvlln.stevesbackpacks.world.inventory.CopperBackpackGUIMenu;
import net.sprvlln.stevesbackpacks.world.inventory.BriefcaseInvGUIMenu;
import net.sprvlln.stevesbackpacks.StevesBackpacksMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

public class StevesBackpacksModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, StevesBackpacksMod.MODID);
	public static final RegistryObject<MenuType<CopperBackpackGUIMenu>> COPPER_BACKPACK_GUI = REGISTRY.register("copper_backpack_gui", () -> IForgeMenuType.create(CopperBackpackGUIMenu::new));
	public static final RegistryObject<MenuType<LeatherBackpackGUIMenu>> LEATHER_BACKPACK_GUI = REGISTRY.register("leather_backpack_gui", () -> IForgeMenuType.create(LeatherBackpackGUIMenu::new));
	public static final RegistryObject<MenuType<IronBackpackGUIMenu>> IRON_BACKPACK_GUI = REGISTRY.register("iron_backpack_gui", () -> IForgeMenuType.create(IronBackpackGUIMenu::new));
	public static final RegistryObject<MenuType<GoldBackpackGUIMenu>> GOLD_BACKPACK_GUI = REGISTRY.register("gold_backpack_gui", () -> IForgeMenuType.create(GoldBackpackGUIMenu::new));
	public static final RegistryObject<MenuType<DiamondBackpackGUIMenu>> DIAMOND_BACKPACK_GUI = REGISTRY.register("diamond_backpack_gui", () -> IForgeMenuType.create(DiamondBackpackGUIMenu::new));
	public static final RegistryObject<MenuType<PaperBagGUIMenu>> PAPER_BAG_GUI = REGISTRY.register("paper_bag_gui", () -> IForgeMenuType.create(PaperBagGUIMenu::new));
	public static final RegistryObject<MenuType<BriefcaseInvGUIMenu>> BRIEFCASE_INV_GUI = REGISTRY.register("briefcase_inv_gui", () -> IForgeMenuType.create(BriefcaseInvGUIMenu::new));
}
