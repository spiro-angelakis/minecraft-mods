
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesbackpacks.init;

import net.sprvlln.stevesbackpacks.item.PaperBagItem;
import net.sprvlln.stevesbackpacks.item.LeatherBackpackItem;
import net.sprvlln.stevesbackpacks.item.IronBackpackItem;
import net.sprvlln.stevesbackpacks.item.GoldBackpackItem;
import net.sprvlln.stevesbackpacks.item.DiamondBackpackItem;
import net.sprvlln.stevesbackpacks.item.CopperBackpackItem;
import net.sprvlln.stevesbackpacks.item.BriefcaseItem;
import net.sprvlln.stevesbackpacks.StevesBackpacksMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

public class StevesBackpacksModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, StevesBackpacksMod.MODID);
	public static final RegistryObject<Item> COPPER_BACKPACK = REGISTRY.register("copper_backpack", () -> new CopperBackpackItem());
	public static final RegistryObject<Item> LEATHER_BACKPACK = REGISTRY.register("leather_backpack", () -> new LeatherBackpackItem());
	public static final RegistryObject<Item> IRON_BACKPACK = REGISTRY.register("iron_backpack", () -> new IronBackpackItem());
	public static final RegistryObject<Item> GOLD_BACKPACK = REGISTRY.register("gold_backpack", () -> new GoldBackpackItem());
	public static final RegistryObject<Item> DIAMOND_BACKPACK = REGISTRY.register("diamond_backpack", () -> new DiamondBackpackItem());
	public static final RegistryObject<Item> PAPER_BAG = REGISTRY.register("paper_bag", () -> new PaperBagItem());
	public static final RegistryObject<Item> BRIEFCASE = REGISTRY.register("briefcase", () -> new BriefcaseItem());
}
