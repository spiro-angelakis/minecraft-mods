
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesbackpacks.init;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class StevesBackpacksModTabs {
	public static CreativeModeTab TAB_STEVES_BACKPACKS_CREATIVE_TAB;

	public static void load() {
		TAB_STEVES_BACKPACKS_CREATIVE_TAB = new CreativeModeTab("tabsteves_backpacks_creative_tab") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(Blocks.SPRUCE_PLANKS);
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
