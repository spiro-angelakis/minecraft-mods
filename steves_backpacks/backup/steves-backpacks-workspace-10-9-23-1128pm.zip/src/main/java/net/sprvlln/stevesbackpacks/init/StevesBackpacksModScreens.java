
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesbackpacks.init;

import net.sprvlln.stevesbackpacks.client.gui.PaperBagGUIScreen;
import net.sprvlln.stevesbackpacks.client.gui.LeatherBackpackGUIScreen;
import net.sprvlln.stevesbackpacks.client.gui.IronBackpackGUIScreen;
import net.sprvlln.stevesbackpacks.client.gui.GoldBackpackGUIScreen;
import net.sprvlln.stevesbackpacks.client.gui.DiamondBackpackGUIScreen;
import net.sprvlln.stevesbackpacks.client.gui.CopperBackpackGUIScreen;
import net.sprvlln.stevesbackpacks.client.gui.BriefcaseInvGUIScreen;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class StevesBackpacksModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(StevesBackpacksModMenus.COPPER_BACKPACK_GUI.get(), CopperBackpackGUIScreen::new);
			MenuScreens.register(StevesBackpacksModMenus.LEATHER_BACKPACK_GUI.get(), LeatherBackpackGUIScreen::new);
			MenuScreens.register(StevesBackpacksModMenus.IRON_BACKPACK_GUI.get(), IronBackpackGUIScreen::new);
			MenuScreens.register(StevesBackpacksModMenus.GOLD_BACKPACK_GUI.get(), GoldBackpackGUIScreen::new);
			MenuScreens.register(StevesBackpacksModMenus.DIAMOND_BACKPACK_GUI.get(), DiamondBackpackGUIScreen::new);
			MenuScreens.register(StevesBackpacksModMenus.PAPER_BAG_GUI.get(), PaperBagGUIScreen::new);
			MenuScreens.register(StevesBackpacksModMenus.BRIEFCASE_INV_GUI.get(), BriefcaseInvGUIScreen::new);
		});
	}
}
