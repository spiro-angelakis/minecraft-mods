package net.sprvlln.stevesprimitivestart.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.level.BlockEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class PlayerBreaksBlockProcedure {
	@SubscribeEvent
	public static void onBlockBreak(BlockEvent.BreakEvent event) {
		execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getPlayer());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean cancelEvent = false;
		boolean toolsOnStoneReturn = false;
		boolean stoneToolsOnStoneReturn = false;
		boolean woodBreakReturn = false;
		boolean clayBreakReturn = false;
		cancelEvent = false;
		BreakLeavesProcedure.execute(world, x, y, z);
		BreakGrassProcedure.execute(world, x, y, z);
		toolsOnStoneReturn = WoodToolsOnStoneGravelProcedure.execute(world, x, y, z, entity);
		if (toolsOnStoneReturn == false) {
			cancelEvent = true;
		}
		stoneToolsOnStoneReturn = StoneToolsOnStoneProcedure.execute(world, x, y, z, entity);
		if (stoneToolsOnStoneReturn == false) {
			cancelEvent = true;
		}
		woodBreakReturn = WoodenLogBrokenProcedure.execute(world, x, y, z, entity);
		if (woodBreakReturn == true) {
			cancelEvent = true;
		}
		clayBreakReturn = ClayBlockBrokenProcedure.execute(world, x, y, z, entity);
		if (clayBreakReturn == true) {
			cancelEvent = true;
		}
		WeakWoodToolsProcedure.execute(entity);
		if (cancelEvent == true) {
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			}
		}
	}
}
