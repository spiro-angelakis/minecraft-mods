
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesprimitivestart.init;

import net.sprvlln.stevesprimitivestart.client.gui.WickerBasketGUIScreen;
import net.sprvlln.stevesprimitivestart.client.gui.SurvivalGuideGUIScreen;
import net.sprvlln.stevesprimitivestart.client.gui.PrimitiveFurnaceRecipesGUIScreen;
import net.sprvlln.stevesprimitivestart.client.gui.PrimitiveFurnaceGUIScreen;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class StevesPrimitiveStartModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(StevesPrimitiveStartModMenus.WICKER_BASKET_GUI.get(), WickerBasketGUIScreen::new);
			MenuScreens.register(StevesPrimitiveStartModMenus.PRIMITIVE_FURNACE_GUI.get(), PrimitiveFurnaceGUIScreen::new);
			MenuScreens.register(StevesPrimitiveStartModMenus.SURVIVAL_GUIDE_GUI.get(), SurvivalGuideGUIScreen::new);
			MenuScreens.register(StevesPrimitiveStartModMenus.PRIMITIVE_FURNACE_RECIPES_GUI.get(), PrimitiveFurnaceRecipesGUIScreen::new);
		});
	}
}
