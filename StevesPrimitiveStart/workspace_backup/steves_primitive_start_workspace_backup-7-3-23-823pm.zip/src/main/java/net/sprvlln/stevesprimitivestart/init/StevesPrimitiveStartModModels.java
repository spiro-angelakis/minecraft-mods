
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesprimitivestart.init;

import net.sprvlln.stevesprimitivestart.client.model.Modelwooden_spear_entity2;
import net.sprvlln.stevesprimitivestart.client.model.Modelwooden_spear_entity;
import net.sprvlln.stevesprimitivestart.client.model.Modelstone_spear_entity;
import net.sprvlln.stevesprimitivestart.client.model.Modelprimitive_arrow;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class StevesPrimitiveStartModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelprimitive_arrow.LAYER_LOCATION, Modelprimitive_arrow::createBodyLayer);
		event.registerLayerDefinition(Modelwooden_spear_entity.LAYER_LOCATION, Modelwooden_spear_entity::createBodyLayer);
		event.registerLayerDefinition(Modelstone_spear_entity.LAYER_LOCATION, Modelstone_spear_entity::createBodyLayer);
		event.registerLayerDefinition(Modelwooden_spear_entity2.LAYER_LOCATION, Modelwooden_spear_entity2::createBodyLayer);
	}
}
