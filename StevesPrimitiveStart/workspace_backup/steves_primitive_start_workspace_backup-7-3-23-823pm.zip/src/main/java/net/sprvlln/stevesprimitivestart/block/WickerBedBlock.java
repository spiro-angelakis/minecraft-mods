
package net.sprvlln.stevesprimitivestart.block;

import net.sprvlln.stevesprimitivestart.procedures.WickerBedOnBlockRightClickedProcedure;
import net.sprvlln.stevesprimitivestart.init.StevesPrimitiveStartModItems;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.Collections;

public class WickerBedBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public WickerBedBlock() {
		super(BlockBehaviour.Properties.of(Material.WOOD).sound(SoundType.WOOD).strength(0f, 0.1f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(0.01421, 0, -15.99289, 16.01421, 1, 16.00711), box(6.18004, 1, -11.64332, 14.18004, 2, -6.64332), box(-3.83058, 1, -3.43414, 1.16942, 2, 4.56586), box(-5.33058, 1, -8.93414, 2.66942, 2, -3.93414));
			case NORTH -> Shapes.or(box(-0.01421, 0, -0.00711, 15.98579, 1, 31.99289), box(1.81996, 1, 22.64332, 9.81996, 2, 27.64332), box(14.83058, 1, 11.43414, 19.83058, 2, 19.43414), box(13.33058, 1, 19.93414, 21.33058, 2, 24.93414));
			case EAST -> Shapes.or(box(-15.99289, 0, -0.01421, 16.00711, 1, 15.98579), box(-11.64332, 1, 1.81996, -6.64332, 2, 9.81996), box(-3.43414, 1, 14.83058, 4.56586, 2, 19.83058), box(-8.93414, 1, 13.33058, -3.93414, 2, 21.33058));
			case WEST -> Shapes.or(box(-0.00711, 0, 0.01421, 31.99289, 1, 16.01421), box(22.64332, 1, 6.18004, 27.64332, 2, 14.18004), box(11.43414, 1, -3.83058, 19.43414, 2, 1.16942), box(19.93414, 1, -5.33058, 24.93414, 2, 2.66942));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public int getFlammability(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
		return 5;
	}

	@Override
	public int getFireSpreadSpeed(BlockState state, BlockGetter world, BlockPos pos, Direction face) {
		return 100;
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
		List<ItemStack> dropsOriginal = super.getDrops(state, builder);
		if (!dropsOriginal.isEmpty())
			return dropsOriginal;
		return Collections.singletonList(new ItemStack(StevesPrimitiveStartModItems.WICKER_SHEET.get()));
	}

	@Override
	public InteractionResult use(BlockState blockstate, Level world, BlockPos pos, Player entity, InteractionHand hand, BlockHitResult hit) {
		super.use(blockstate, world, pos, entity, hand, hit);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		WickerBedOnBlockRightClickedProcedure.execute(x, y, z, entity);
		return InteractionResult.SUCCESS;
	}
}
