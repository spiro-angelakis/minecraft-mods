
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesprimitivestart.init;

import net.sprvlln.stevesprimitivestart.client.renderer.WoodenSpearRenderer;
import net.sprvlln.stevesprimitivestart.client.renderer.StoneTippedSpearRenderer;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class StevesPrimitiveStartModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(StevesPrimitiveStartModEntities.WOODEN_SPEAR.get(), WoodenSpearRenderer::new);
		event.registerEntityRenderer(StevesPrimitiveStartModEntities.STONE_TIPPED_SPEAR.get(), StoneTippedSpearRenderer::new);
	}
}
