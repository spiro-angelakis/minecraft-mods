
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesprimitivestart.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class StevesPrimitiveStartModTabs {
	public static CreativeModeTab TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB;

	public static void load() {
		TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB = new CreativeModeTab("tabsteves_primitive_start_creative_tab") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(StevesPrimitiveStartModItems.PRIMITIVE_ARROW.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
