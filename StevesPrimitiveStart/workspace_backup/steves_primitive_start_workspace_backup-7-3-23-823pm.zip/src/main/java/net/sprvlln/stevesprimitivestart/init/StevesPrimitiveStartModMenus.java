
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesprimitivestart.init;

import net.sprvlln.stevesprimitivestart.world.inventory.WickerBasketGUIMenu;
import net.sprvlln.stevesprimitivestart.world.inventory.SurvivalGuideGUIMenu;
import net.sprvlln.stevesprimitivestart.world.inventory.PrimitiveFurnaceRecipesGUIMenu;
import net.sprvlln.stevesprimitivestart.world.inventory.PrimitiveFurnaceGUIMenu;
import net.sprvlln.stevesprimitivestart.StevesPrimitiveStartMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

public class StevesPrimitiveStartModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, StevesPrimitiveStartMod.MODID);
	public static final RegistryObject<MenuType<WickerBasketGUIMenu>> WICKER_BASKET_GUI = REGISTRY.register("wicker_basket_gui", () -> IForgeMenuType.create(WickerBasketGUIMenu::new));
	public static final RegistryObject<MenuType<PrimitiveFurnaceGUIMenu>> PRIMITIVE_FURNACE_GUI = REGISTRY.register("primitive_furnace_gui", () -> IForgeMenuType.create(PrimitiveFurnaceGUIMenu::new));
	public static final RegistryObject<MenuType<SurvivalGuideGUIMenu>> SURVIVAL_GUIDE_GUI = REGISTRY.register("survival_guide_gui", () -> IForgeMenuType.create(SurvivalGuideGUIMenu::new));
	public static final RegistryObject<MenuType<PrimitiveFurnaceRecipesGUIMenu>> PRIMITIVE_FURNACE_RECIPES_GUI = REGISTRY.register("primitive_furnace_recipes_gui", () -> IForgeMenuType.create(PrimitiveFurnaceRecipesGUIMenu::new));
}
