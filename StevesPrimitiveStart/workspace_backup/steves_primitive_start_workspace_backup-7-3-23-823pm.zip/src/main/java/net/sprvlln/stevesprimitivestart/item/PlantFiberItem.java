
package net.sprvlln.stevesprimitivestart.item;

import net.sprvlln.stevesprimitivestart.init.StevesPrimitiveStartModTabs;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PlantFiberItem extends Item {
	public PlantFiberItem() {
		super(new Item.Properties().tab(StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB).stacksTo(64).rarity(Rarity.COMMON));
	}
}
