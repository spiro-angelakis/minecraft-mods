
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesprimitivestart.init;

import net.sprvlln.stevesprimitivestart.block.entity.WickerDoorOpenBlockEntity;
import net.sprvlln.stevesprimitivestart.block.entity.WickerDoorBlockEntity;
import net.sprvlln.stevesprimitivestart.block.entity.WickerBasketBlockEntity;
import net.sprvlln.stevesprimitivestart.block.entity.PrimitiveFurnaceBurningBlockEntity;
import net.sprvlln.stevesprimitivestart.block.entity.PrimitiveFurnaceBlockEntity;
import net.sprvlln.stevesprimitivestart.block.entity.MakeshiftDoorOpenBlockEntity;
import net.sprvlln.stevesprimitivestart.block.entity.MakeshiftDoorBlockEntity;
import net.sprvlln.stevesprimitivestart.StevesPrimitiveStartMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

public class StevesPrimitiveStartModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, StevesPrimitiveStartMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> PRIMITIVE_FURNACE = register("primitive_furnace", StevesPrimitiveStartModBlocks.PRIMITIVE_FURNACE, PrimitiveFurnaceBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> PRIMITIVE_FURNACE_BURNING = register("primitive_furnace_burning", StevesPrimitiveStartModBlocks.PRIMITIVE_FURNACE_BURNING, PrimitiveFurnaceBurningBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> WICKER_BASKET = register("wicker_basket", StevesPrimitiveStartModBlocks.WICKER_BASKET, WickerBasketBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> WICKER_DOOR = register("wicker_door", StevesPrimitiveStartModBlocks.WICKER_DOOR, WickerDoorBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> WICKER_DOOR_OPEN = register("wicker_door_open", StevesPrimitiveStartModBlocks.WICKER_DOOR_OPEN, WickerDoorOpenBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> MAKESHIFT_DOOR = register("makeshift_door", StevesPrimitiveStartModBlocks.MAKESHIFT_DOOR, MakeshiftDoorBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> MAKESHIFT_DOOR_OPEN = register("makeshift_door_open", StevesPrimitiveStartModBlocks.MAKESHIFT_DOOR_OPEN, MakeshiftDoorOpenBlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
