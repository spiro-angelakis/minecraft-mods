
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesprimitivestart.init;

import net.sprvlln.stevesprimitivestart.item.WoodenSpearItem;
import net.sprvlln.stevesprimitivestart.item.WickerThreadItem;
import net.sprvlln.stevesprimitivestart.item.WickerSheetItem;
import net.sprvlln.stevesprimitivestart.item.TinyClayBallItem;
import net.sprvlln.stevesprimitivestart.item.SurvivalGuideItem;
import net.sprvlln.stevesprimitivestart.item.StoneTippedSpearItem;
import net.sprvlln.stevesprimitivestart.item.SmallRockItem;
import net.sprvlln.stevesprimitivestart.item.SmallPebbleItem;
import net.sprvlln.stevesprimitivestart.item.SharpenedSmallRockItem;
import net.sprvlln.stevesprimitivestart.item.SharpenedFlintItem;
import net.sprvlln.stevesprimitivestart.item.SharpenedCobblestoneItem;
import net.sprvlln.stevesprimitivestart.item.RockAxeItem;
import net.sprvlln.stevesprimitivestart.item.RawIronChunkItem;
import net.sprvlln.stevesprimitivestart.item.PrimitiveArrowItem;
import net.sprvlln.stevesprimitivestart.item.PlantFiberItem;
import net.sprvlln.stevesprimitivestart.item.MishandledWoodPlankItem;
import net.sprvlln.stevesprimitivestart.item.GreenLeafItem;
import net.sprvlln.stevesprimitivestart.item.GravelShardItem;
import net.sprvlln.stevesprimitivestart.item.GravelChunkItem;
import net.sprvlln.stevesprimitivestart.item.FlintShovelItem;
import net.sprvlln.stevesprimitivestart.item.FlintShardItem;
import net.sprvlln.stevesprimitivestart.item.FlintPickaxeItem;
import net.sprvlln.stevesprimitivestart.item.FlintAxeItem;
import net.sprvlln.stevesprimitivestart.item.DirtChunkItem;
import net.sprvlln.stevesprimitivestart.item.CobblestoneShardItem;
import net.sprvlln.stevesprimitivestart.item.CobblestoneChunkItem;
import net.sprvlln.stevesprimitivestart.item.AshItem;
import net.sprvlln.stevesprimitivestart.StevesPrimitiveStartMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

public class StevesPrimitiveStartModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, StevesPrimitiveStartMod.MODID);
	public static final RegistryObject<Item> PLANT_FIBER = REGISTRY.register("plant_fiber", () -> new PlantFiberItem());
	public static final RegistryObject<Item> GREEN_LEAF = REGISTRY.register("green_leaf", () -> new GreenLeafItem());
	public static final RegistryObject<Item> PRIMITIVE_ARROW = REGISTRY.register("primitive_arrow", () -> new PrimitiveArrowItem());
	public static final RegistryObject<Item> FLINT_SHARD = REGISTRY.register("flint_shard", () -> new FlintShardItem());
	public static final RegistryObject<Item> COBBLESTONE_SHARD = REGISTRY.register("cobblestone_shard", () -> new CobblestoneShardItem());
	public static final RegistryObject<Item> COBBLESTONE_CHUNK = REGISTRY.register("cobblestone_chunk", () -> new CobblestoneChunkItem());
	public static final RegistryObject<Item> FLINT_PICKAXE = REGISTRY.register("flint_pickaxe", () -> new FlintPickaxeItem());
	public static final RegistryObject<Item> FLINT_AXE = REGISTRY.register("flint_axe", () -> new FlintAxeItem());
	public static final RegistryObject<Item> FLINT_SHOVEL = REGISTRY.register("flint_shovel", () -> new FlintShovelItem());
	public static final RegistryObject<Item> GRAVEL_SHARD = REGISTRY.register("gravel_shard", () -> new GravelShardItem());
	public static final RegistryObject<Item> GRAVEL_CHUNK = REGISTRY.register("gravel_chunk", () -> new GravelChunkItem());
	public static final RegistryObject<Item> MAKESHIFT_PLANKS = block(StevesPrimitiveStartModBlocks.MAKESHIFT_PLANKS, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> WOODEN_SPEAR = REGISTRY.register("wooden_spear", () -> new WoodenSpearItem());
	public static final RegistryObject<Item> PRIMITIVE_FURNACE = block(StevesPrimitiveStartModBlocks.PRIMITIVE_FURNACE, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> PRIMITIVE_GLASS = block(StevesPrimitiveStartModBlocks.PRIMITIVE_GLASS, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> GROUND_STICK_1 = block(StevesPrimitiveStartModBlocks.GROUND_STICK_1, null);
	public static final RegistryObject<Item> GROUND_STICK_2 = block(StevesPrimitiveStartModBlocks.GROUND_STICK_2, null);
	public static final RegistryObject<Item> GROUND_STICK_3 = block(StevesPrimitiveStartModBlocks.GROUND_STICK_3, null);
	public static final RegistryObject<Item> GROUND_STICK_4 = block(StevesPrimitiveStartModBlocks.GROUND_STICK_4, null);
	public static final RegistryObject<Item> SMALL_ROCK = REGISTRY.register("small_rock", () -> new SmallRockItem());
	public static final RegistryObject<Item> GROUND_ROCK_1 = block(StevesPrimitiveStartModBlocks.GROUND_ROCK_1, null);
	public static final RegistryObject<Item> GROUND_ROCK_2 = block(StevesPrimitiveStartModBlocks.GROUND_ROCK_2, null);
	public static final RegistryObject<Item> PRIMITIVE_FURNACE_BURNING = block(StevesPrimitiveStartModBlocks.PRIMITIVE_FURNACE_BURNING, null);
	public static final RegistryObject<Item> WICKER_THREAD = REGISTRY.register("wicker_thread", () -> new WickerThreadItem());
	public static final RegistryObject<Item> WICKER_SHEET = REGISTRY.register("wicker_sheet", () -> new WickerSheetItem());
	public static final RegistryObject<Item> WICKER_BLOCK = block(StevesPrimitiveStartModBlocks.WICKER_BLOCK, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> WICKER_BASKET = block(StevesPrimitiveStartModBlocks.WICKER_BASKET, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> ROCK_AXE = REGISTRY.register("rock_axe", () -> new RockAxeItem());
	public static final RegistryObject<Item> MISHANDLED_WOOD_LOG = block(StevesPrimitiveStartModBlocks.MISHANDLED_WOOD_LOG, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> MISHANDLED_WOOD_PLANK = REGISTRY.register("mishandled_wood_plank", () -> new MishandledWoodPlankItem());
	public static final RegistryObject<Item> ASH = REGISTRY.register("ash", () -> new AshItem());
	public static final RegistryObject<Item> RAW_IRON_CHUNK = REGISTRY.register("raw_iron_chunk", () -> new RawIronChunkItem());
	public static final RegistryObject<Item> WICKER_DOOR = block(StevesPrimitiveStartModBlocks.WICKER_DOOR, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> WICKER_DOOR_OPEN = block(StevesPrimitiveStartModBlocks.WICKER_DOOR_OPEN, null);
	public static final RegistryObject<Item> MAKESHIFT_DOOR = block(StevesPrimitiveStartModBlocks.MAKESHIFT_DOOR, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> MAKESHIFT_DOOR_OPEN = block(StevesPrimitiveStartModBlocks.MAKESHIFT_DOOR_OPEN, null);
	public static final RegistryObject<Item> COBBLESTONE_BOULDER = block(StevesPrimitiveStartModBlocks.COBBLESTONE_BOULDER, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> STONE_BOULDER = block(StevesPrimitiveStartModBlocks.STONE_BOULDER, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> TINY_CLAY_BALL = REGISTRY.register("tiny_clay_ball", () -> new TinyClayBallItem());
	public static final RegistryObject<Item> SHARPENED_SMALL_ROCK = REGISTRY.register("sharpened_small_rock", () -> new SharpenedSmallRockItem());
	public static final RegistryObject<Item> WICKER_BED = block(StevesPrimitiveStartModBlocks.WICKER_BED, StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB);
	public static final RegistryObject<Item> SURVIVAL_GUIDE = REGISTRY.register("survival_guide", () -> new SurvivalGuideItem());
	public static final RegistryObject<Item> SHARPENED_FLINT = REGISTRY.register("sharpened_flint", () -> new SharpenedFlintItem());
	public static final RegistryObject<Item> SHARPENED_COBBLESTONE = REGISTRY.register("sharpened_cobblestone", () -> new SharpenedCobblestoneItem());
	public static final RegistryObject<Item> SMALL_PEBBLE = REGISTRY.register("small_pebble", () -> new SmallPebbleItem());
	public static final RegistryObject<Item> DIRT_CHUNK = REGISTRY.register("dirt_chunk", () -> new DirtChunkItem());
	public static final RegistryObject<Item> STONE_TIPPED_SPEAR = REGISTRY.register("stone_tipped_spear", () -> new StoneTippedSpearItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
