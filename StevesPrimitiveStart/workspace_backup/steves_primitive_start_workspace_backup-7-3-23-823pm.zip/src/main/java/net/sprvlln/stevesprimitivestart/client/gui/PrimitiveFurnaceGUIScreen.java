package net.sprvlln.stevesprimitivestart.client.gui;

import net.sprvlln.stevesprimitivestart.world.inventory.PrimitiveFurnaceGUIMenu;
import net.sprvlln.stevesprimitivestart.procedures.ReturnFurnaceCook6Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnFurnaceCook5Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnFurnaceCook4Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnFurnaceCook3Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnFurnaceCook2Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnFurnaceCook1Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnFurnaceCook0Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnBurnLeft6Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnBurnLeft5Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnBurnLeft4Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnBurnLeft3Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnBurnLeft2Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnBurnLeft1Procedure;
import net.sprvlln.stevesprimitivestart.procedures.ReturnBurnLeft0Procedure;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.Minecraft;

import java.util.HashMap;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;

public class PrimitiveFurnaceGUIScreen extends AbstractContainerScreen<PrimitiveFurnaceGUIMenu> {
	private final static HashMap<String, Object> guistate = PrimitiveFurnaceGUIMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;

	public PrimitiveFurnaceGUIScreen(PrimitiveFurnaceGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	private static final ResourceLocation texture = new ResourceLocation("steves_primitive_start:textures/screens/primitive_furnace_gui.png");

	@Override
	public void render(PoseStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void renderBg(PoseStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShaderTexture(0, texture);
		this.blit(ms, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		if (ReturnFurnaceCook0Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_cook_0.png"));
			this.blit(ms, this.leftPos + 105, this.topPos + 43, 0, 0, 24, 17, 24, 17);
		}
		if (ReturnFurnaceCook1Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_cook_1.png"));
			this.blit(ms, this.leftPos + 105, this.topPos + 43, 0, 0, 24, 17, 24, 17);
		}
		if (ReturnFurnaceCook2Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_cook_2.png"));
			this.blit(ms, this.leftPos + 105, this.topPos + 43, 0, 0, 24, 17, 24, 17);
		}
		if (ReturnFurnaceCook3Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_cook_3.png"));
			this.blit(ms, this.leftPos + 105, this.topPos + 43, 0, 0, 24, 17, 24, 17);
		}
		if (ReturnFurnaceCook4Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_cook_4.png"));
			this.blit(ms, this.leftPos + 105, this.topPos + 43, 0, 0, 24, 17, 24, 17);
		}
		if (ReturnFurnaceCook5Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_cook_5.png"));
			this.blit(ms, this.leftPos + 105, this.topPos + 43, 0, 0, 24, 17, 24, 17);
		}
		if (ReturnFurnaceCook6Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_cook_6.png"));
			this.blit(ms, this.leftPos + 105, this.topPos + 43, 0, 0, 24, 17, 24, 17);
		}
		if (ReturnBurnLeft0Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_smelt_0.png"));
			this.blit(ms, this.leftPos + 78, this.topPos + 43, 0, 0, 16, 16, 16, 16);
		}
		if (ReturnBurnLeft1Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_smelt_1.png"));
			this.blit(ms, this.leftPos + 78, this.topPos + 43, 0, 0, 16, 16, 16, 16);
		}
		if (ReturnBurnLeft2Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_smelt_2.png"));
			this.blit(ms, this.leftPos + 78, this.topPos + 43, 0, 0, 16, 16, 16, 16);
		}
		if (ReturnBurnLeft3Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_smelt_3.png"));
			this.blit(ms, this.leftPos + 78, this.topPos + 43, 0, 0, 16, 16, 16, 16);
		}
		if (ReturnBurnLeft4Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_smelt_4.png"));
			this.blit(ms, this.leftPos + 78, this.topPos + 43, 0, 0, 16, 16, 16, 16);
		}
		if (ReturnBurnLeft5Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_smelt_5.png"));
			this.blit(ms, this.leftPos + 78, this.topPos + 43, 0, 0, 16, 16, 16, 16);
		}
		if (ReturnBurnLeft6Procedure.execute(world, x, y, z)) {
			RenderSystem.setShaderTexture(0, new ResourceLocation("steves_primitive_start:textures/screens/furnace_smelt_6.png"));
			this.blit(ms, this.leftPos + 78, this.topPos + 43, 0, 0, 16, 16, 16, 16);
		}
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
	}

	@Override
	protected void renderLabels(PoseStack poseStack, int mouseX, int mouseY) {
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardHandler.setSendRepeatsToGui(false);
	}

	@Override
	public void init() {
		super.init();
		this.minecraft.keyboardHandler.setSendRepeatsToGui(true);
	}
}
