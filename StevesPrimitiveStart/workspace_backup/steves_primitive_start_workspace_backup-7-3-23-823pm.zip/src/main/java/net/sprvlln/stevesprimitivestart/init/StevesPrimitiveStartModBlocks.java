
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesprimitivestart.init;

import net.sprvlln.stevesprimitivestart.block.WickerDoorOpenBlock;
import net.sprvlln.stevesprimitivestart.block.WickerDoorBlock;
import net.sprvlln.stevesprimitivestart.block.WickerBlockBlock;
import net.sprvlln.stevesprimitivestart.block.WickerBedBlock;
import net.sprvlln.stevesprimitivestart.block.WickerBasketBlock;
import net.sprvlln.stevesprimitivestart.block.StoneBoulderBlock;
import net.sprvlln.stevesprimitivestart.block.PrimitiveGlassBlock;
import net.sprvlln.stevesprimitivestart.block.PrimitiveFurnaceBurningBlock;
import net.sprvlln.stevesprimitivestart.block.PrimitiveFurnaceBlock;
import net.sprvlln.stevesprimitivestart.block.MishandledWoodLogBlock;
import net.sprvlln.stevesprimitivestart.block.MakeshiftPlanksBlock;
import net.sprvlln.stevesprimitivestart.block.MakeshiftDoorOpenBlock;
import net.sprvlln.stevesprimitivestart.block.MakeshiftDoorBlock;
import net.sprvlln.stevesprimitivestart.block.GroundStick4Block;
import net.sprvlln.stevesprimitivestart.block.GroundStick3Block;
import net.sprvlln.stevesprimitivestart.block.GroundStick2Block;
import net.sprvlln.stevesprimitivestart.block.GroundStick1Block;
import net.sprvlln.stevesprimitivestart.block.GroundRock2Block;
import net.sprvlln.stevesprimitivestart.block.GroundRock1Block;
import net.sprvlln.stevesprimitivestart.block.CobblestoneBoulderBlock;
import net.sprvlln.stevesprimitivestart.StevesPrimitiveStartMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

public class StevesPrimitiveStartModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, StevesPrimitiveStartMod.MODID);
	public static final RegistryObject<Block> MAKESHIFT_PLANKS = REGISTRY.register("makeshift_planks", () -> new MakeshiftPlanksBlock());
	public static final RegistryObject<Block> PRIMITIVE_FURNACE = REGISTRY.register("primitive_furnace", () -> new PrimitiveFurnaceBlock());
	public static final RegistryObject<Block> PRIMITIVE_GLASS = REGISTRY.register("primitive_glass", () -> new PrimitiveGlassBlock());
	public static final RegistryObject<Block> GROUND_STICK_1 = REGISTRY.register("ground_stick_1", () -> new GroundStick1Block());
	public static final RegistryObject<Block> GROUND_STICK_2 = REGISTRY.register("ground_stick_2", () -> new GroundStick2Block());
	public static final RegistryObject<Block> GROUND_STICK_3 = REGISTRY.register("ground_stick_3", () -> new GroundStick3Block());
	public static final RegistryObject<Block> GROUND_STICK_4 = REGISTRY.register("ground_stick_4", () -> new GroundStick4Block());
	public static final RegistryObject<Block> GROUND_ROCK_1 = REGISTRY.register("ground_rock_1", () -> new GroundRock1Block());
	public static final RegistryObject<Block> GROUND_ROCK_2 = REGISTRY.register("ground_rock_2", () -> new GroundRock2Block());
	public static final RegistryObject<Block> PRIMITIVE_FURNACE_BURNING = REGISTRY.register("primitive_furnace_burning", () -> new PrimitiveFurnaceBurningBlock());
	public static final RegistryObject<Block> WICKER_BLOCK = REGISTRY.register("wicker_block", () -> new WickerBlockBlock());
	public static final RegistryObject<Block> WICKER_BASKET = REGISTRY.register("wicker_basket", () -> new WickerBasketBlock());
	public static final RegistryObject<Block> MISHANDLED_WOOD_LOG = REGISTRY.register("mishandled_wood_log", () -> new MishandledWoodLogBlock());
	public static final RegistryObject<Block> WICKER_DOOR = REGISTRY.register("wicker_door", () -> new WickerDoorBlock());
	public static final RegistryObject<Block> WICKER_DOOR_OPEN = REGISTRY.register("wicker_door_open", () -> new WickerDoorOpenBlock());
	public static final RegistryObject<Block> MAKESHIFT_DOOR = REGISTRY.register("makeshift_door", () -> new MakeshiftDoorBlock());
	public static final RegistryObject<Block> MAKESHIFT_DOOR_OPEN = REGISTRY.register("makeshift_door_open", () -> new MakeshiftDoorOpenBlock());
	public static final RegistryObject<Block> COBBLESTONE_BOULDER = REGISTRY.register("cobblestone_boulder", () -> new CobblestoneBoulderBlock());
	public static final RegistryObject<Block> STONE_BOULDER = REGISTRY.register("stone_boulder", () -> new StoneBoulderBlock());
	public static final RegistryObject<Block> WICKER_BED = REGISTRY.register("wicker_bed", () -> new WickerBedBlock());
}
