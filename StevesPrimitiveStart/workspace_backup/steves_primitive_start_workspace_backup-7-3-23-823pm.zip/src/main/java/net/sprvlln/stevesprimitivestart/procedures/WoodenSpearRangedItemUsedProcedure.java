package net.sprvlln.stevesprimitivestart.procedures;

import net.minecraft.world.item.ItemStack;

public class WoodenSpearRangedItemUsedProcedure {
	public static void execute(ItemStack itemstack) {
		(itemstack).shrink(1);
	}
}
