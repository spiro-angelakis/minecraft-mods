package net.sprvlln.stevesprimitivestart.procedures;

import net.sprvlln.stevesprimitivestart.network.StevesPrimitiveStartModVariables;
import net.sprvlln.stevesprimitivestart.init.StevesPrimitiveStartModItems;

import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.PlayerEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class GivePlayerSurvivalGuideOnJoinWorldProcedure {
	@SubscribeEvent
	public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (!(entity.getCapability(StevesPrimitiveStartModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new StevesPrimitiveStartModVariables.PlayerVariables())).givenGuide) {
			if (entity instanceof Player _player) {
				ItemStack _setstack = new ItemStack(StevesPrimitiveStartModItems.SURVIVAL_GUIDE.get());
				_setstack.setCount(1);
				ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
			}
			{
				boolean _setval = true;
				entity.getCapability(StevesPrimitiveStartModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.givenGuide = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
