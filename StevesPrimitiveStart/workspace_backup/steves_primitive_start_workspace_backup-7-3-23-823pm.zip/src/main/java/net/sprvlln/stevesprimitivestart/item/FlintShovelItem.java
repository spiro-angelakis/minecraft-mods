
package net.sprvlln.stevesprimitivestart.item;

import net.sprvlln.stevesprimitivestart.init.StevesPrimitiveStartModTabs;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class FlintShovelItem extends ShovelItem {
	public FlintShovelItem() {
		super(new Tier() {
			public int getUses() {
				return 20;
			}

			public float getSpeed() {
				return 1.5f;
			}

			public float getAttackDamageBonus() {
				return -0.5f;
			}

			public int getLevel() {
				return 0;
			}

			public int getEnchantmentValue() {
				return 0;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(Items.FLINT));
			}
		}, 1, -3f, new Item.Properties().tab(StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB));
	}
}
