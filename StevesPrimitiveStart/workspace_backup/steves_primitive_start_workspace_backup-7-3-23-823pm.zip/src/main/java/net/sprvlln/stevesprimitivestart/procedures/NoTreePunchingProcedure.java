package net.sprvlln.stevesprimitivestart.procedures;

import net.sprvlln.stevesprimitivestart.init.StevesPrimitiveStartModBlocks;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.client.Minecraft;

public class NoTreePunchingProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return false;
		DamageSource Punching = new DamageSource("generic");
		boolean hasAxe = false;
		boolean bareHand = false;
		boolean doItemDamage = false;
		boolean doDamage = false;
		boolean doReturn = false;
		doItemDamage = false;
		doDamage = false;
		doReturn = false;
		if (new Object() {
			public boolean checkGamemode(Entity _ent) {
				if (_ent instanceof ServerPlayer _serverPlayer) {
					return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.SURVIVAL;
				} else if (_ent.level.isClientSide() && _ent instanceof Player _player) {
					return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null && Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()).getGameMode() == GameType.SURVIVAL;
				}
				return false;
			}
		}.checkGamemode(entity)) {
			hasAxe = false;
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() instanceof AxeItem) {
				hasAxe = true;
			} else if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ItemStack.EMPTY.getItem()) {
				bareHand = true;
			} else {
				bareHand = false;
			}
			if (hasAxe == false) {
				if ((world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:logs"))) || (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:planks")))
						|| (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:dead_logs")))
						|| (world.getBlockState(new BlockPos(x, y, z))).getBlock() == StevesPrimitiveStartModBlocks.MISHANDLED_WOOD_LOG.get()) {
					if (bareHand == false) {
						if (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).isDamageableItem() == true) {
							doItemDamage = true;
						} else {
							doReturn = true;
						}
					} else {
						doDamage = true;
						doReturn = true;
					}
				}
			}
		}
		if (Mth.nextInt(RandomSource.create(), 1, 5) == 1) {
			if (doItemDamage) {
				{
					ItemStack _ist = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
					if (_ist.hurt(1, RandomSource.create(), null)) {
						_ist.shrink(1);
						_ist.setDamageValue(0);
					}
				}
			}
			if (doDamage) {
				if (entity instanceof LivingEntity _entity)
					_entity.hurt(new DamageSource("tree").bypassArmor(), 3);
			}
		}
		if (doReturn) {
			return false;
		}
		return true;
	}
}
