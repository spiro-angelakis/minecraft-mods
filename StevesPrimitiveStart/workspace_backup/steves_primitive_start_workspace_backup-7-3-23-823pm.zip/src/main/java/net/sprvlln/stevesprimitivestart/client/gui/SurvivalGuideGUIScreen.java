package net.sprvlln.stevesprimitivestart.client.gui;

import net.sprvlln.stevesprimitivestart.world.inventory.SurvivalGuideGUIMenu;
import net.sprvlln.stevesprimitivestart.network.SurvivalGuideGUIButtonMessage;
import net.sprvlln.stevesprimitivestart.StevesPrimitiveStartMod;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.Minecraft;

import java.util.HashMap;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;

public class SurvivalGuideGUIScreen extends AbstractContainerScreen<SurvivalGuideGUIMenu> {
	private final static HashMap<String, Object> guistate = SurvivalGuideGUIMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Button button_show_primitive_furnace_recipes;

	public SurvivalGuideGUIScreen(SurvivalGuideGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 224;
		this.imageHeight = 200;
	}

	private static final ResourceLocation texture = new ResourceLocation("steves_primitive_start:textures/screens/survival_guide_gui.png");

	@Override
	public void render(PoseStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void renderBg(PoseStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShaderTexture(0, texture);
		this.blit(ms, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
	}

	@Override
	protected void renderLabels(PoseStack poseStack, int mouseX, int mouseY) {
		this.font.draw(poseStack, Component.translatable("gui.steves_primitive_start.survival_guide_gui.label_survival_guide"), 12, 6, -16777216);
		this.font.draw(poseStack, Component.translatable("gui.steves_primitive_start.survival_guide_gui.label_find_rocks_and_sticks_by_foragin"), 12, 24, -12829636);
		this.font.draw(poseStack, Component.translatable("gui.steves_primitive_start.survival_guide_gui.label_hit_small_rocks_on_stone_to_shar"), 12, 42, -12829636);
		this.font.draw(poseStack, Component.translatable("gui.steves_primitive_start.survival_guide_gui.label_rock_axe_can_be_crafted_in_inven"), 12, 60, -12829636);
		this.font.draw(poseStack, Component.translatable("gui.steves_primitive_start.survival_guide_gui.label_attempt_to_get_wood_and_crafting"), 12, 78, -12829636);
		this.font.draw(poseStack, Component.translatable("gui.steves_primitive_start.survival_guide_gui.label_flint_tools_are_useful"), 12, 96, -12829636);
		this.font.draw(poseStack, Component.translatable("gui.steves_primitive_start.survival_guide_gui.label_clay_blocks_on_campfire_makes_br"), 12, 114, -12829636);
		this.font.draw(poseStack, Component.translatable("gui.steves_primitive_start.survival_guide_gui.label_smelt_boulders_in_a_primitive_fu"), 12, 132, -12829636);
		this.font.draw(poseStack, Component.translatable("gui.steves_primitive_start.survival_guide_gui.label_dont_punch_trees_or_hard_ground"), 30, 150, -10092544);
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardHandler.setSendRepeatsToGui(false);
	}

	@Override
	public void init() {
		super.init();
		this.minecraft.keyboardHandler.setSendRepeatsToGui(true);
		button_show_primitive_furnace_recipes = new Button(this.leftPos + 21, this.topPos + 168, 181, 20, Component.translatable("gui.steves_primitive_start.survival_guide_gui.button_show_primitive_furnace_recipes"), e -> {
			if (true) {
				StevesPrimitiveStartMod.PACKET_HANDLER.sendToServer(new SurvivalGuideGUIButtonMessage(0, x, y, z));
				SurvivalGuideGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		});
		guistate.put("button:button_show_primitive_furnace_recipes", button_show_primitive_furnace_recipes);
		this.addRenderableWidget(button_show_primitive_furnace_recipes);
	}
}
