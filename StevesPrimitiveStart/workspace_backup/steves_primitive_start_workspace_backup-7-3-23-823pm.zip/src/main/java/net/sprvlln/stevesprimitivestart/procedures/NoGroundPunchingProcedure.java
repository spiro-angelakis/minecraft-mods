package net.sprvlln.stevesprimitivestart.procedures;

import net.sprvlln.stevesprimitivestart.init.StevesPrimitiveStartModItems;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.common.TierSortingRegistry;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.client.Minecraft;

import java.util.Map;

public class NoGroundPunchingProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return false;
		DamageSource punching = new DamageSource("generic");
		boolean hasAxe = false;
		boolean bareHand = false;
		boolean hitGround = false;
		boolean bigDamage = false;
		boolean doReturn = false;
		hitGround = false;
		bigDamage = false;
		doReturn = false;
		bareHand = true;
		if (!world.isClientSide()) {
			if ((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.STONE) {
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == StevesPrimitiveStartModItems.SMALL_ROCK.get()) {
					bareHand = false;
					if (Mth.nextInt(RandomSource.create(), 1, 20) == 1) {
						if (entity instanceof Player _player) {
							ItemStack _stktoremove = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
							_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
						}
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.SCRAPE, (entity.getX()), (entity.getY()), (entity.getZ()), Mth.nextInt(RandomSource.create(), 1, 6), 0, 0, 0, 0.5);
						if (world instanceof Level _level && !_level.isClientSide()) {
							ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(StevesPrimitiveStartModItems.SHARPENED_SMALL_ROCK.get()));
							entityToSpawn.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn);
						}
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1, false);
							}
						}
						if (Mth.nextInt(RandomSource.create(), 1, 5) == 1) {
							{
								BlockPos _bp = new BlockPos(x, y, z);
								BlockState _bs = Blocks.COBBLESTONE.defaultBlockState();
								BlockState _bso = world.getBlockState(_bp);
								for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
									Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
									if (_property != null && _bs.getValue(_property) != null)
										try {
											_bs = _bs.setValue(_property, (Comparable) entry.getValue());
										} catch (Exception e) {
										}
								}
								world.setBlock(_bp, _bs, 3);
							}
						}
					}
				}
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == StevesPrimitiveStartModItems.SHARPENED_SMALL_ROCK.get()) {
					bareHand = false;
					if (Mth.nextInt(RandomSource.create(), 1, 20) == 1) {
						if (entity instanceof Player _player) {
							ItemStack _stktoremove = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
							_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
						}
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.SCRAPE, (entity.getX()), (entity.getY()), (entity.getZ()), Mth.nextInt(RandomSource.create(), 1, 6), 0, 0, 0, 0.5);
						if (Mth.nextInt(RandomSource.create(), 1, 4) == 1) {
							if (world instanceof Level _level && !_level.isClientSide()) {
								ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(StevesPrimitiveStartModItems.COBBLESTONE_SHARD.get()));
								entityToSpawn.setPickUpDelay(10);
								_level.addFreshEntity(entityToSpawn);
							}
						} else {
							for (int index0 = 0; index0 < Mth.nextInt(RandomSource.create(), 2, 3); index0++) {
								if (world instanceof Level _level && !_level.isClientSide()) {
									ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(StevesPrimitiveStartModItems.SMALL_PEBBLE.get()));
									entityToSpawn.setPickUpDelay(10);
									_level.addFreshEntity(entityToSpawn);
								}
							}
						}
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1, false);
							}
						}
						if (Mth.nextInt(RandomSource.create(), 1, 5) == 1) {
							{
								BlockPos _bp = new BlockPos(x, y, z);
								BlockState _bs = Blocks.COBBLESTONE.defaultBlockState();
								BlockState _bso = world.getBlockState(_bp);
								for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
									Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
									if (_property != null && _bs.getValue(_property) != null)
										try {
											_bs = _bs.setValue(_property, (Comparable) entry.getValue());
										} catch (Exception e) {
										}
								}
								world.setBlock(_bp, _bs, 3);
							}
						}
					}
				}
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.FLINT) {
					bareHand = false;
					if (Mth.nextInt(RandomSource.create(), 1, 20) == 1) {
						if (entity instanceof Player _player) {
							ItemStack _stktoremove = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
							_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
						}
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.SCRAPE, (entity.getX()), (entity.getY()), (entity.getZ()), Mth.nextInt(RandomSource.create(), 1, 6), 0, 0, 0, 0.5);
						if (world instanceof Level _level && !_level.isClientSide()) {
							ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(StevesPrimitiveStartModItems.SHARPENED_FLINT.get()));
							entityToSpawn.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn);
						}
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1, false);
							}
						}
						if (Mth.nextInt(RandomSource.create(), 1, 5) == 1) {
							{
								BlockPos _bp = new BlockPos(x, y, z);
								BlockState _bs = Blocks.COBBLESTONE.defaultBlockState();
								BlockState _bso = world.getBlockState(_bp);
								for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
									Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
									if (_property != null && _bs.getValue(_property) != null)
										try {
											_bs = _bs.setValue(_property, (Comparable) entry.getValue());
										} catch (Exception e) {
										}
								}
								world.setBlock(_bp, _bs, 3);
							}
						}
					}
				}
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == StevesPrimitiveStartModItems.SHARPENED_FLINT.get()) {
					bareHand = false;
					if (Mth.nextInt(RandomSource.create(), 1, 20) == 1) {
						if (entity instanceof Player _player) {
							ItemStack _stktoremove = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
							_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
						}
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.SCRAPE, (entity.getX()), (entity.getY()), (entity.getZ()), Mth.nextInt(RandomSource.create(), 1, 6), 0, 0, 0, 0.5);
						for (int index1 = 0; index1 < Mth.nextInt(RandomSource.create(), 1, 4); index1++) {
							if (world instanceof Level _level && !_level.isClientSide()) {
								ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(StevesPrimitiveStartModItems.FLINT_SHARD.get()));
								entityToSpawn.setPickUpDelay(10);
								_level.addFreshEntity(entityToSpawn);
							}
						}
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1, false);
							}
						}
						if (Mth.nextInt(RandomSource.create(), 1, 5) == 1) {
							{
								BlockPos _bp = new BlockPos(x, y, z);
								BlockState _bs = Blocks.COBBLESTONE.defaultBlockState();
								BlockState _bso = world.getBlockState(_bp);
								for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
									Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
									if (_property != null && _bs.getValue(_property) != null)
										try {
											_bs = _bs.setValue(_property, (Comparable) entry.getValue());
										} catch (Exception e) {
										}
								}
								world.setBlock(_bp, _bs, 3);
							}
						}
					}
				}
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.COBBLESTONE.asItem()) {
					bareHand = false;
					if (Mth.nextInt(RandomSource.create(), 1, 20) == 1) {
						if (entity instanceof Player _player) {
							ItemStack _stktoremove = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
							_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
						}
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.SCRAPE, (entity.getX()), (entity.getY()), (entity.getZ()), Mth.nextInt(RandomSource.create(), 1, 6), 0, 0, 0, 0.5);
						if (world instanceof Level _level && !_level.isClientSide()) {
							ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(StevesPrimitiveStartModItems.SHARPENED_COBBLESTONE.get()));
							entityToSpawn.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn);
						}
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1, false);
							}
						}
						if (Mth.nextInt(RandomSource.create(), 1, 5) == 1) {
							{
								BlockPos _bp = new BlockPos(x, y, z);
								BlockState _bs = Blocks.COBBLESTONE.defaultBlockState();
								BlockState _bso = world.getBlockState(_bp);
								for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
									Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
									if (_property != null && _bs.getValue(_property) != null)
										try {
											_bs = _bs.setValue(_property, (Comparable) entry.getValue());
										} catch (Exception e) {
										}
								}
								world.setBlock(_bp, _bs, 3);
							}
						}
					}
				}
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == StevesPrimitiveStartModItems.SHARPENED_COBBLESTONE.get()) {
					bareHand = false;
					if (Mth.nextInt(RandomSource.create(), 1, 20) == 1) {
						if (entity instanceof Player _player) {
							ItemStack _stktoremove = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
							_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
						}
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.SCRAPE, (entity.getX()), (entity.getY()), (entity.getZ()), Mth.nextInt(RandomSource.create(), 1, 6), 0, 0, 0, 0.5);
						for (int index2 = 0; index2 < Mth.nextInt(RandomSource.create(), 1, 4); index2++) {
							if (world instanceof Level _level && !_level.isClientSide()) {
								ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(StevesPrimitiveStartModItems.COBBLESTONE_CHUNK.get()));
								entityToSpawn.setPickUpDelay(10);
								_level.addFreshEntity(entityToSpawn);
							}
						}
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1, false);
							}
						}
						if (Mth.nextInt(RandomSource.create(), 1, 5) == 1) {
							{
								BlockPos _bp = new BlockPos(x, y, z);
								BlockState _bs = Blocks.COBBLESTONE.defaultBlockState();
								BlockState _bso = world.getBlockState(_bp);
								for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
									Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
									if (_property != null && _bs.getValue(_property) != null)
										try {
											_bs = _bs.setValue(_property, (Comparable) entry.getValue());
										} catch (Exception e) {
										}
								}
								world.setBlock(_bp, _bs, 3);
							}
						}
					}
				}
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == StevesPrimitiveStartModItems.COBBLESTONE_CHUNK.get()) {
					bareHand = false;
					if (Mth.nextInt(RandomSource.create(), 1, 20) == 1) {
						if (entity instanceof Player _player) {
							ItemStack _stktoremove = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
							_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
						}
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.SCRAPE, (entity.getX()), (entity.getY()), (entity.getZ()), Mth.nextInt(RandomSource.create(), 1, 6), 0, 0, 0, 0.5);
						for (int index3 = 0; index3 < Mth.nextInt(RandomSource.create(), 1, 4); index3++) {
							if (world instanceof Level _level && !_level.isClientSide()) {
								ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(StevesPrimitiveStartModItems.COBBLESTONE_SHARD.get()));
								entityToSpawn.setPickUpDelay(10);
								_level.addFreshEntity(entityToSpawn);
							}
						}
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1);
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.item.break")), SoundSource.PLAYERS, 1, 1, false);
							}
						}
						if (Mth.nextInt(RandomSource.create(), 1, 5) == 1) {
							{
								BlockPos _bp = new BlockPos(x, y, z);
								BlockState _bs = Blocks.COBBLESTONE.defaultBlockState();
								BlockState _bso = world.getBlockState(_bp);
								for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
									Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
									if (_property != null && _bs.getValue(_property) != null)
										try {
											_bs = _bs.setValue(_property, (Comparable) entry.getValue());
										} catch (Exception e) {
										}
								}
								world.setBlock(_bp, _bs, 3);
							}
						}
					}
				}
			}
		}
		if (new Object() {
			public boolean checkGamemode(Entity _ent) {
				if (_ent instanceof ServerPlayer _serverPlayer) {
					return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.SURVIVAL;
				} else if (_ent.level.isClientSide() && _ent instanceof Player _player) {
					return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null && Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()).getGameMode() == GameType.SURVIVAL;
				}
				return false;
			}
		}.checkGamemode(entity)) {
			hasAxe = false;
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ItemStack.EMPTY.getItem()) {
				bareHand = true;
			} else {
				bareHand = false;
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() instanceof AxeItem
						|| (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() instanceof HoeItem
						|| (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() instanceof PickaxeItem
						|| (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() instanceof ShovelItem) {
					bareHand = false;
					hasAxe = true;
				} else {
					if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(new ResourceLocation("forge:paxel")))) {
						hasAxe = true;
						bareHand = false;
					}
				}
			}
			if (bareHand == true) {
				if ((world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:dirt")))) {
					if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.GRASS_BLOCK)) {
						if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.PODZOL)) {
							if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.DIRT_PATH)) {
								if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SAND)) {
									if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.COARSE_DIRT)) {
										if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SNOW)) {
											if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SNOW_BLOCK)) {
												if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.POWDER_SNOW)) {
													if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.CLAY)) {
														if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.MOSS_BLOCK)) {
															if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.MOSS_CARPET)) {
																hitGround = true;
																doReturn = true;
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				} else if ((world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:ice"))) || (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:impermeable")))
						|| (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:stone_bricks")))
						|| (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:overworld_carver_replaceables")))
						|| (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:base_stone_overworld")))
						|| (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:base_stone_nether"))) || (world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.COBBLESTONE
						|| (world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.MOSSY_COBBLESTONE) {
					if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.GRASS_BLOCK)) {
						if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.PODZOL)) {
							if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.DIRT_PATH)) {
								if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SAND)) {
									if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.COARSE_DIRT)) {
										if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SNOW)) {
											if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SNOW_BLOCK)) {
												if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.POWDER_SNOW)) {
													if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.CLAY)) {
														if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.MOSS_BLOCK)) {
															if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.MOSS_CARPET)) {
																hitGround = true;
																bigDamage = true;
																doReturn = true;
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				} else if (new Object() {
					public int getHarvestLevel(BlockState _bs) {
						return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag() != null && _bs.is(t.getTag())).map(Tier::getLevel).findFirst().orElse(0);
					}
				}.getHarvestLevel(world.getBlockState(new BlockPos(x, y, z))) > 0) {
					hitGround = true;
					doReturn = true;
				}
			} else {
				if (hasAxe == false) {
					if ((world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:dirt")))) {
						if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.GRASS_BLOCK)) {
							if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.PODZOL)) {
								if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.DIRT_PATH)) {
									if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SAND)) {
										if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.COARSE_DIRT)) {
											if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SNOW)) {
												if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SNOW_BLOCK)) {
													if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.POWDER_SNOW)) {
														if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.CLAY)) {
															if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.MOSS_BLOCK)) {
																if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.MOSS_CARPET)) {
																	doReturn = true;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					} else if ((world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:ice")))
							|| (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:impermeable")))
							|| (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:stone_bricks")))
							|| (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:overworld_carver_replaceables")))
							|| (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:base_stone_overworld")))
							|| (world.getBlockState(new BlockPos(x, y, z))).is(BlockTags.create(new ResourceLocation("minecraft:base_stone_nether"))) || (world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.COBBLESTONE
							|| (world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.MOSSY_COBBLESTONE) {
						if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.GRASS_BLOCK)) {
							if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.PODZOL)) {
								if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.DIRT_PATH)) {
									if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SAND)) {
										if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.COARSE_DIRT)) {
											if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SNOW)) {
												if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.SNOW_BLOCK)) {
													if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.POWDER_SNOW)) {
														if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.CLAY)) {
															if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.MOSS_BLOCK)) {
																if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.MOSS_CARPET)) {
																	doReturn = true;
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					} else if (new Object() {
						public int getHarvestLevel(BlockState _bs) {
							return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag() != null && _bs.is(t.getTag())).map(Tier::getLevel).findFirst().orElse(0);
						}
					}.getHarvestLevel(world.getBlockState(new BlockPos(x, y, z))) > 0) {
						doReturn = true;
					}
				}
			}
		}
		if (hitGround) {
			if (Mth.nextInt(RandomSource.create(), 1, 5) == 1) {
				if (bigDamage) {
					if (entity instanceof LivingEntity _entity)
						_entity.hurt(new DamageSource("hand").bypassArmor(), 1);
				} else {
					if (entity instanceof LivingEntity _entity)
						_entity.hurt(new DamageSource("hand").bypassArmor(), 3);
				}
			}
		}
		if (doReturn) {
			return false;
		}
		return true;
	}
}
