
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sprvlln.stevesprimitivestart.init;

import net.sprvlln.stevesprimitivestart.world.features.plants.GroundStick4Feature;
import net.sprvlln.stevesprimitivestart.world.features.plants.GroundStick3Feature;
import net.sprvlln.stevesprimitivestart.world.features.plants.GroundStick2Feature;
import net.sprvlln.stevesprimitivestart.world.features.plants.GroundStick1Feature;
import net.sprvlln.stevesprimitivestart.world.features.plants.GroundRock2Feature;
import net.sprvlln.stevesprimitivestart.world.features.plants.GroundRock1Feature;
import net.sprvlln.stevesprimitivestart.StevesPrimitiveStartMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

@Mod.EventBusSubscriber
public class StevesPrimitiveStartModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, StevesPrimitiveStartMod.MODID);
	public static final RegistryObject<Feature<?>> GROUND_STICK_1 = REGISTRY.register("ground_stick_1", GroundStick1Feature::feature);
	public static final RegistryObject<Feature<?>> GROUND_STICK_2 = REGISTRY.register("ground_stick_2", GroundStick2Feature::feature);
	public static final RegistryObject<Feature<?>> GROUND_STICK_3 = REGISTRY.register("ground_stick_3", GroundStick3Feature::feature);
	public static final RegistryObject<Feature<?>> GROUND_STICK_4 = REGISTRY.register("ground_stick_4", GroundStick4Feature::feature);
	public static final RegistryObject<Feature<?>> GROUND_ROCK_1 = REGISTRY.register("ground_rock_1", GroundRock1Feature::feature);
	public static final RegistryObject<Feature<?>> GROUND_ROCK_2 = REGISTRY.register("ground_rock_2", GroundRock2Feature::feature);
}
