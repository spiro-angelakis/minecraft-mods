
package net.sprvlln.stevesprimitivestart.item;

import net.sprvlln.stevesprimitivestart.init.StevesPrimitiveStartModTabs;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;

public class RockAxeItem extends AxeItem {
	public RockAxeItem() {
		super(new Tier() {
			public int getUses() {
				return 10;
			}

			public float getSpeed() {
				return 1f;
			}

			public float getAttackDamageBonus() {
				return 1f;
			}

			public int getLevel() {
				return 0;
			}

			public int getEnchantmentValue() {
				return 0;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of();
			}
		}, 1, -3f, new Item.Properties().tab(StevesPrimitiveStartModTabs.TAB_STEVES_PRIMITIVE_START_CREATIVE_TAB));
	}
}
